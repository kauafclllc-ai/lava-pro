/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0B0D14',
        panel: '#141827',
        card: '#1B2233',
        brand: '#7547F5',
        'brand-light': '#9B7BFF',
        tech: '#398BFF',
        ok: '#20C997',
        warn: '#FFAA42',
        bad: '#F05260',
        txt: '#F7F8FC',
        mute: '#A8B0C2',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      boxShadow: {
        soft: '0 6px 20px rgba(0,0,0,0.28)',
      },
      keyframes: {
        rise: { '0%': { opacity: '0', transform: 'translateY(8px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        sheet: { '0%': { transform: 'translateY(100%)' }, '100%': { transform: 'translateY(0)' } },
      },
      animation: {
        rise: 'rise .25s ease-out both',
        sheet: 'sheet .22s ease-out both',
      },
    },
  },
  plugins: [],
};
