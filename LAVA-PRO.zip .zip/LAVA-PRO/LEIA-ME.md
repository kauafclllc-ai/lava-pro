# LAVA PRO — versão 1.0 (completa, ainda NÃO testada em celular)

App Android de gestão de lava-jato: Nova O.S. em 5 etapas, pátio, financeiro com caixa, estoque, funcionários,
relatórios (PDF/Excel), cupom (térmica Bluetooth LE / PDF), leitor de QR, modo offline com fila de envio.
O APK é gerado **na nuvem pelo GitHub** — você não compila nada no seu computador.

## Estado dos testes — leia antes de usar (sem enfeite)

| Parte | O que foi verificado | Resultado |
|---|---|---|
| Banco de dados (SQL, segurança, caixa, estoque, estorno, convites, relatórios) | 212 verificações automáticas em PostgreSQL 16 real | **212/212 passaram** |
| Lógica pura (cupom, ESC/POS, QR, dinheiro, placa, telefone) | testes unitários | **passaram** |
| Sintaxe e imports de todo o código do app | esbuild | **sem erros** |
| Build do app web (`vite build`) | **NÃO executado** (sem acesso ao npm neste ambiente) | **desconhecido** |
| Geração do APK | **NÃO executada** | **desconhecido** |
| Telas no celular, câmera, Bluetooth/impressora, envio offline→online | **NÃO testados** | **desconhecido** |

**Na prática:** o primeiro "Run workflow" no GitHub é o primeiro build de verdade. Pode falhar por algum erro de
tipo/importação que só o compilador real acusa. Se falhar, copie as últimas linhas do erro e me mande: é rápido de corrigir.
Depois que instalar, teste com calma (veja "Checklist de primeiro uso") antes de usar com clientes reais.

## Passo 1 — Banco de dados (Supabase)

1. No Supabase, abra **SQL Editor → New query**.
2. Abra `supabase/schema.sql`, copie **tudo**, cole e clique em **Run**. (uma vez só, em projeto vazio)
3. **Nova query** de novo: abra `supabase/migrations/002_fase2.sql`, copie **tudo**, cole e **Run**. (uma vez só, **depois** do passo 2)
4. Em **Project Settings → API** anote o **Project URL** e a **anon public key**. **Nunca** use a `service_role` no app.
5. **Authentication → Providers → Email**: para testes rápidos pode desligar "Confirm email". Em produção, mantenha ligado.
6. **Recuperar senha:** o app pede um código de 6 dígitos por e-mail. Em **Authentication → Email Templates → Reset password**,
   troque o conteúdo para mostrar o código, por exemplo: `Seu código para redefinir a senha: {{ .Token }}`.

## Passo 2 — Enviar o projeto ao GitHub (sem instalar nada)

1. Crie uma conta em github.com e um **repositório novo, privado**, chamado `lava-pro`.
2. Descompacte o zip no seu computador.
3. No repositório, clique em **Add file → Upload files** e arraste **todo o conteúdo da pasta `LAVA-PRO`** (inclusive a pasta `.github`, que pode estar oculta no Windows: em Explorador de Arquivos, aba **Exibir → Itens ocultos**).
4. Clique em **Commit changes**.
5. Confira se existe o arquivo `.github/workflows/android-build.yml` no repositório. Se não existir (o GitHub às vezes ignora a pasta oculta), crie-o: **Add file → Create new file**, digite o nome `.github/workflows/android-build.yml`, cole o conteúdo do arquivo e faça o commit.

## Passo 3 — Cadastrar as chaves (Secrets)

No repositório: **Settings → Secrets and variables → Actions → New repository secret**. Crie:

| Nome (exatamente assim) | Valor |
|---|---|
| `VITE_SUPABASE_URL` | Project URL do Supabase |
| `VITE_SUPABASE_ANON_KEY` | anon public key |
| `VITE_PUBLIC_BASE_URL` | *(opcional agora, veja o Passo 6)* |

## Passo 4 — Gerar o APK

1. Aba **Actions** → **Android APK (debug)** → **Run workflow** → **Run workflow**.
2. Aguarde de 8 a 15 minutos (a primeira vez demora mais).
3. Se aparecer um ✅ verde, abra a execução e, no fim da página, em **Artifacts**, baixe **LAVA-PRO-debug-apk**. É um zip com o `LAVA-PRO-debug.apk`.
4. Se aparecer ❌ vermelho: abra a execução, clique na etapa que falhou e copie as últimas linhas do erro.

## Passo 5 — Instalar no celular

1. Passe o `.apk` para o celular (WhatsApp, e-mail, Drive ou cabo).
2. Toque no arquivo. O Android vai pedir para permitir **instalar apps de fontes desconhecidas** para o app que você usou para abrir o arquivo. Permita.
3. Abra o **LAVA PRO**, toque em **Criar uma conta**, entre e cadastre o nome do seu lava-jato (você vira o **Administrador**).
4. **Funcionários:** em Mais → Funcionários → **+**, gere um **código de convite**. O funcionário instala o app, cria a conta e usa
   "Tenho um código de convite". O código vale 7 dias e só funciona uma vez.
5. Em **Mais → Serviços** cadastre seus serviços; em **Estoque** os produtos (e vincule o consumo em cada serviço).

Este é um APK de **teste (debug)**, ótimo para usar e validar. Para publicar na Play Store será preciso um APK/AAB assinado com uma chave sua, o que fica para uma fase posterior.

## Passo 6 — QR Code funcionando (opcional, mas recomendado)

O QR Code aponta para uma página pública do app, que precisa estar hospedada na internet.

1. No resultado do build (Passo 4), baixe também o artefato **LAVA-PRO-web** e descompacte.
2. Acesse **app.netlify.com/drop** e arraste a pasta descompactada. Você recebe um endereço como `https://nome-aleatorio.netlify.app`.
3. Volte aos Secrets e preencha `VITE_PUBLIC_BASE_URL` com esse endereço, **sem barra no final**.
4. Rode o workflow de novo e instale o novo APK. A partir daí o QR Code aparece na O.S.

Enquanto isso não for feito, o app funciona normalmente; só o QR Code mostra um aviso.

---

## Perfis de acesso

| Perfil | Pode |
|---|---|
| Administrador | tudo |
| Gerente | operação, serviços, despesas, equipe |
| Atendente | clientes, veículos, O.S., pagamentos |
| Lavador | ver e iniciar/concluir apenas as O.S. atribuídas a ele |

Valores, descontos, status de pagamento e identificadores de uma O.S. **só mudam pelo servidor**, nunca por edição direta. Isso impede fraude por quem tenha acesso ao app.

## Testar o banco no seu computador (opcional, técnico)

`supabase/tests/` tem um simulador mínimo do Supabase e a suíte de segurança. Num PostgreSQL comum e vazio: rode `supabase_shim.sql`, depois `../schema.sql`, depois `security_test.sql`. O resumo mostra quantas verificações passaram.

## Estrutura

```
LAVA-PRO/
  .github/workflows/android-build.yml   build do APK na nuvem
  assets/                               ícone e splash (usados no build)
  src/                                  código do aplicativo (React + TypeScript)
  supabase/schema.sql                   banco de dados
  supabase/tests/                       testes de segurança do banco
  capacitor.config.ts                   configuração Android (id br.com.lavapro.app)
  .env.example                          modelo das variáveis
```

Identificador do app: `br.com.lavapro.app`. Mude em `capacitor.config.ts` **antes** do primeiro build, se quiser outro.


## Checklist de primeiro uso (faça antes de usar com clientes)

1. Criar conta, estabelecimento, 1 serviço e 1 produto.
2. Abrir caixa (Financeiro) → criar uma O.S. com foto → avançar status até "Aguardando pagamento" → registrar pagamento → ver baixa no estoque.
3. Mais → Configurações → Impressora: procurar a impressora Bluetooth e imprimir o teste. Se não aparecer, use **Cupom → PDF**.
4. Ligar o **modo avião**, criar uma O.S.: ela deve aparecer em **Mais → Pendências** como "Aguardando envio". Desligar o modo avião e conferir se foi enviada.
5. Mais → Ler QR Code: apontar para o QR de uma O.S.
6. Fechar o caixa e conferir o valor.

## Limitações conhecidas (honestas)

- **Impressora:** só térmica **Bluetooth LE**. USB e Bluetooth "clássico" não são suportados; nesse caso use "Cupom → PDF" e o app da impressora (ex.: RawBT).
- **Offline:** O.S., pagamentos e mudanças de status ficam numa fila criptografada neste aparelho e são enviados quando a internet volta; a tela sempre diz "aguardando envio" até o servidor confirmar. **Fotos e estornos exigem internet.** A chave de criptografia fica no armazenamento do app (não é protegida por hardware).
- Relatórios e Excel usam a biblioteca `xlsx` apenas para **gerar** arquivos (nunca para abrir arquivos de terceiros).
- APK de **teste (debug)**. Para a Play Store será preciso assinar com uma chave sua (não faz parte desta entrega).
- Cancelar O.S. e estornar pagamento só para Gerente/Administrador; salário/comissão só o Administrador vê.

