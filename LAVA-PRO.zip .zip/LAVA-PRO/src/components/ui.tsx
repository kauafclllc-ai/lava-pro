import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, ArrowLeft, CloudOff, Droplets, Loader2, RefreshCw, Wifi, WifiOff, X } from 'lucide-react';
import { STATUS } from '../lib/format';
import { useOnline, useOutbox } from '../lib/hooks';
import type { OrderStatus } from '../lib/types';

export function LogoMark({ size = 40 }: { size?: number }) {
  return (
    <div
      className="flex items-center justify-center rounded-2xl shadow-soft"
      style={{ width: size, height: size, backgroundImage: 'linear-gradient(135deg,#7547F5,#398BFF)' }}
    >
      <Droplets size={size * 0.55} className="text-white" strokeWidth={2.2} />
    </div>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-mute">
      <Loader2 className="animate-spin text-brand-light" size={30} />
      {label && <span className="text-sm">{label}</span>}
    </div>
  );
}

export function SplashScreenView() {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-4 bg-ink">
      <LogoMark size={72} />
      <div className="text-xl font-bold tracking-wide">LAVA PRO</div>
      <Loader2 className="animate-spin text-brand-light" size={22} />
    </div>
  );
}

export function StatusChip({ status }: { status: OrderStatus }) {
  const s = STATUS[status];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold ${s.chip}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
      {s.label}
    </span>
  );
}

// Indicador de conexão + pendências de sincronização
export function ConnectionBadge() {
  const online = useOnline();
  const navigate = useNavigate();
  const { pending, problems, syncing } = useOutbox();
  const waiting = pending + problems;
  if (waiting > 0) {
    return (
      <button
        onClick={() => navigate('/pendencias')}
        className={`inline-flex min-h-[32px] items-center gap-1 rounded-full px-2.5 text-[11px] font-semibold ${
          problems > 0 ? 'bg-bad/15 text-bad' : 'bg-warn/15 text-warn'
        }`}
      >
        {syncing ? <RefreshCw size={12} className="animate-spin" /> : <CloudOff size={12} />}
        {waiting} pendente{waiting > 1 ? 's' : ''}
      </button>
    );
  }
  return online ? (
    <span className="inline-flex items-center gap-1 rounded-full bg-ok/15 px-2 py-1 text-[11px] font-semibold text-ok">
      <Wifi size={12} /> Online
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 rounded-full bg-warn/15 px-2 py-1 text-[11px] font-semibold text-warn">
      <WifiOff size={12} /> Offline
    </span>
  );
}

export function StaleBanner({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <div className="flex items-center gap-2 rounded-xl bg-warn/10 px-3 py-2 text-xs text-warn">
      <WifiOff size={14} /> Sem conexão: mostrando os últimos dados salvos neste aparelho.
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="card flex items-start gap-3 border-bad/30 p-4">
      <AlertTriangle className="mt-0.5 shrink-0 text-bad" size={20} />
      <div className="flex-1 text-sm">
        <p className="text-txt">{message}</p>
        {onRetry && (
          <button onClick={onRetry} className="mt-2 min-h-[44px] font-semibold text-brand-light">
            Tentar novamente
          </button>
        )}
      </div>
    </div>
  );
}

export function Notice({ tone = 'info', children }: { tone?: 'info' | 'ok' | 'warn' | 'bad'; children: ReactNode }) {
  const cls = { info: 'bg-panel text-mute', ok: 'bg-ok/10 text-ok', warn: 'bg-warn/10 text-warn', bad: 'bg-bad/10 text-bad' }[tone];
  return <p className={`rounded-xl px-4 py-3 text-sm ${cls}`}>{children}</p>;
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="card p-6 text-center text-sm text-mute">{children}</div>;
}

export function PageHeader({
  title,
  back,
  left,
  right,
}: {
  title: string;
  back?: boolean;
  left?: ReactNode;
  right?: ReactNode;
}) {
  const navigate = useNavigate();
  return (
    <header className="pt-safe sticky top-0 z-20 flex items-center gap-2 bg-ink/95 px-4 pb-3 backdrop-blur">
      {back && (
        <button onClick={() => navigate(-1)} aria-label="Voltar" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-card">
          <ArrowLeft size={22} />
        </button>
      )}
      {left}
      <h1 className="flex-1 truncate text-xl font-bold">{title}</h1>
      {right}
    </header>
  );
}

export function Sheet({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end bg-black/60" onClick={onClose}>
      <div
        className="pb-safe max-h-[88%] w-full animate-sheet overflow-y-auto rounded-t-3xl bg-panel px-4 pt-3"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-white/15" />
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-bold">{title}</h2>
          <button onClick={onClose} aria-label="Fechar" className="flex h-12 w-12 items-center justify-center rounded-full text-mute">
            <X size={22} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Label({ children }: { children: ReactNode }) {
  return <label className="mb-1.5 block text-sm font-medium text-mute">{children}</label>;
}

export function Field({
  label,
  value,
  onChange,
  placeholder,
  inputMode,
  type = 'text',
  required,
  autoCapitalize,
  readOnly,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  inputMode?: 'text' | 'numeric' | 'decimal' | 'tel' | 'email';
  type?: string;
  required?: boolean;
  autoCapitalize?: string;
  readOnly?: boolean;
}) {
  return (
    <div>
      <Label>{label}</Label>
      <input
        className="field"
        type={type}
        value={value}
        placeholder={placeholder}
        inputMode={inputMode}
        required={required}
        readOnly={readOnly}
        autoCapitalize={autoCapitalize}
        autoComplete="off"
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

export function Chips<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { key: T; label: string }[];
  value: T;
  onChange: (k: T) => void;
}) {
  return (
    <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
      {options.map((o) => (
        <button
          key={o.key}
          onClick={() => onChange(o.key)}
          className={`min-h-[44px] shrink-0 rounded-full border px-4 text-sm font-semibold transition active:scale-95 ${
            value === o.key ? 'border-brand-light bg-brand/20 text-brand-light' : 'border-white/10 bg-card text-mute'
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
