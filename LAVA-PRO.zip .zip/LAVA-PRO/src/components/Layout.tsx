import { useState, type ReactNode } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  CalendarPlus,
  CarFront,
  ClipboardPlus,
  Home,
  LayoutGrid,
  PackagePlus,
  Plus,
  Receipt,
  UserPlus,
  Wallet,
  Warehouse,
} from 'lucide-react';
import { Sheet } from './ui';
import { vibrate } from '../lib/format';
import { useAuth } from '../context/AuthContext';
import { can } from '../lib/perm';

const tabCls = ({ isActive }: { isActive: boolean }) =>
  `flex min-h-[56px] flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition ${
    isActive ? 'text-brand-light' : 'text-mute'
  }`;

// Telas cheias, sem a barra inferior
const FULL = ['/nova-os', '/scanner'];

export default function Layout() {
  const [quick, setQuick] = useState(false);
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { profile } = useAuth();
  const role = profile?.role;
  const hideChrome = FULL.includes(pathname);

  const go = (to: string) => {
    vibrate();
    setQuick(false);
    navigate(to);
  };

  const actions: { icon: ReactNode; label: string; to: string; show: boolean }[] = [
    { icon: <ClipboardPlus size={22} />, label: 'Nova ordem de serviço', to: '/nova-os', show: can(role, 'newOrder') },
    { icon: <UserPlus size={22} />, label: 'Cadastrar cliente', to: '/clientes?novo=1', show: can(role, 'customers') },
    { icon: <Warehouse size={22} />, label: 'Cadastrar veículo', to: '/veiculos?novo=1', show: can(role, 'vehicles') },
    { icon: <Receipt size={22} />, label: 'Registrar despesa', to: '/despesas?novo=1', show: can(role, 'expenses') },
    { icon: <PackagePlus size={22} />, label: 'Adicionar produto', to: '/estoque?novo=1', show: can(role, 'stockManage') },
    { icon: <CalendarPlus size={22} />, label: 'Novo agendamento', to: '/agendamentos?novo=1', show: can(role, 'appointments') },
  ];
  const visible = actions.filter((a) => a.show);

  return (
    <div className="mx-auto flex h-full max-w-xl flex-col">
      <main
        className="flex-1 overflow-y-auto overscroll-contain"
        style={{ paddingBottom: hideChrome ? 0 : 'calc(96px + var(--safe-bottom))' }}
      >
        <Outlet />
      </main>

      {!hideChrome && (
        <>
          {visible.length > 0 && (
            <button
              onClick={() => {
                vibrate();
                setQuick(true);
              }}
              aria-label="Ações rápidas"
              className="fixed right-4 z-30 flex h-14 w-14 items-center justify-center rounded-full text-white shadow-soft transition active:scale-95"
              style={{ bottom: 'calc(84px + var(--safe-bottom))', backgroundImage: 'linear-gradient(135deg,#7547F5,#398BFF)' }}
            >
              <Plus size={28} />
            </button>
          )}

          <nav
            className="fixed inset-x-0 bottom-0 z-40 mx-auto flex max-w-xl items-stretch border-t border-white/5 bg-panel/95 px-2 backdrop-blur"
            style={{ paddingBottom: 'var(--safe-bottom)' }}
          >
            <NavLink to="/" end className={tabCls}>
              <Home size={22} /> Início
            </NavLink>
            {can(role, 'newOrder') && (
              <NavLink to="/nova-os" className="flex flex-1 flex-col items-center justify-center" onClick={() => vibrate()}>
                <span
                  className="-mt-6 flex h-14 w-14 items-center justify-center rounded-2xl text-white shadow-soft transition active:scale-95"
                  style={{ backgroundImage: 'linear-gradient(135deg,#7547F5,#398BFF)' }}
                >
                  <ClipboardPlus size={26} />
                </span>
                <span className="mt-0.5 text-[11px] font-semibold text-brand-light">Nova O.S.</span>
              </NavLink>
            )}
            <NavLink to="/patio" className={tabCls}>
              <CarFront size={22} /> Pátio
            </NavLink>
            {can(role, 'finance') && (
              <NavLink to="/financeiro" className={tabCls}>
                <Wallet size={22} /> Financeiro
              </NavLink>
            )}
            <NavLink to="/mais" className={tabCls}>
              <LayoutGrid size={22} /> Mais
            </NavLink>
          </nav>
        </>
      )}

      <Sheet open={quick} title="Ação rápida" onClose={() => setQuick(false)}>
        <div className="grid gap-2 pb-2">
          {visible.map((a) => (
            <button
              key={a.label}
              onClick={() => go(a.to)}
              className="flex min-h-[56px] items-center gap-3 rounded-xl border border-white/5 bg-card px-4 text-left transition active:scale-[0.98]"
            >
              <span className="text-brand-light">{a.icon}</span>
              <span className="font-semibold">{a.label}</span>
            </button>
          ))}
        </div>
      </Sheet>
    </div>
  );
}
