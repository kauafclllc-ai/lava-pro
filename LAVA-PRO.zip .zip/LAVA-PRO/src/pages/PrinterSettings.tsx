import { useState } from 'react';
import { Bluetooth, Loader2, Printer } from 'lucide-react';
import { bluetoothAvailable, loadPrinter, pickPrinter, printBytes, savePrinter, type PrinterSettings as PS } from '../lib/printer';
import { buildTestPage } from '../lib/escpos';
import type { ReceiptFormat } from '../lib/receipt';
import { errMsg } from '../lib/api';
import { Chips, Notice, PageHeader } from '../components/ui';

export default function PrinterSettings() {
  const [s, setS] = useState<PS>(loadPrinter());
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null);
  const native = bluetoothAvailable();

  const setFormat = (f: ReceiptFormat) => {
    const n = { ...s, format: f };
    savePrinter(n);
    setS(n);
  };

  const pick = async () => {
    setBusy('pick');
    setMsg(null);
    try {
      setS(await pickPrinter());
      setMsg({ ok: true, t: 'Impressora salva. Faça um teste de impressão.' });
    } catch (e) {
      const m = errMsg(e);
      setMsg({ ok: false, t: /cancel|dismiss/i.test(m) ? 'Seleção cancelada.' : `Não foi possível configurar: ${m}` });
    }
    setBusy('');
  };

  const test = async () => {
    setBusy('test');
    setMsg(null);
    try {
      await printBytes(buildTestPage(s.format === '80' ? 48 : 32));
      setMsg({ ok: true, t: 'Teste enviado à impressora. Confira se o papel saiu corretamente.' });
    } catch (e) {
      setMsg({ ok: false, t: `Falha ao imprimir: ${errMsg(e)}` });
    }
    setBusy('');
  };

  return (
    <div className="animate-rise">
      <PageHeader title="Impressora e cupom" back />
      <div className="space-y-4 px-4 pb-4">
        <div className="card space-y-3 p-4">
          <h2 className="font-semibold">Formato do cupom</h2>
          <Chips value={s.format} onChange={setFormat} options={[{ key: '58', label: 'Térmica 58 mm' }, { key: '80', label: 'Térmica 80 mm' }, { key: 'A4', label: 'A4 (PDF)' }]} />
          <p className="text-xs text-mute">Em A4 o cupom sempre é gerado como PDF para compartilhar ou imprimir.</p>
        </div>

        <div className="card space-y-3 p-4">
          <h2 className="font-semibold">Impressora térmica Bluetooth</h2>
          {!native && <Notice tone="warn">A conexão Bluetooth só funciona no app instalado no celular Android.</Notice>}
          <p className="text-sm text-mute">{s.deviceName ? `Configurada: ${s.deviceName}` : 'Nenhuma impressora configurada.'}</p>
          <button className="btn-primary w-full" disabled={!native || !!busy} onClick={() => void pick()}>
            {busy === 'pick' ? <Loader2 className="animate-spin" size={20} /> : <Bluetooth size={20} />} Procurar impressora
          </button>
          <button className="btn-ghost w-full" disabled={!native || !s.deviceId || !!busy} onClick={() => void test()}>
            {busy === 'test' ? <Loader2 className="animate-spin" size={20} /> : <Printer size={20} />} Imprimir teste
          </button>
          {msg && <Notice tone={msg.ok ? 'ok' : 'bad'}>{msg.t}</Notice>}
        </div>

        <Notice>
          Limitações desta versão: só impressoras Bluetooth LE (BLE) são encontradas diretamente. Impressoras USB ou Bluetooth clássico não são suportadas — nesse caso use “Compartilhar PDF” na O.S. e envie ao app da sua impressora.
        </Notice>
      </div>
    </div>
  );
}
