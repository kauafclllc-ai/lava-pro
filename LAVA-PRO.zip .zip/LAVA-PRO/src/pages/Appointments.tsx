import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, Plus } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useLoad } from '../lib/useLoad';
import { errMsg, must } from '../lib/api';
import { digits, displayPlate, fmtDateTime, formatPhone, isValidPlate, normalizePlate, one, toLocalInput } from '../lib/format';
import { Chips, Empty, ErrorBox, Field, Label, PageHeader, Sheet, Spinner, StaleBanner } from '../components/ui';

interface Appt {
  id: string;
  customer_name: string;
  phone: string | null;
  plate: string | null;
  model: string | null;
  service_id: string | null;
  service: string;
  scheduled_at: string;
  notes: string | null;
  status: string;
}
const ST: Record<string, string> = { scheduled: 'Agendado', done: 'Concluído', cancelled: 'Cancelado', no_show: 'Não compareceu' };

export default function Appointments() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [filter, setFilter] = useState<'scheduled' | 'all'>('scheduled');
  const list = useLoad<Appt[]>('appointments', async () =>
    (must(await supabase.from('appointments').select('id, customer_name, phone, plate, model, service_id, scheduled_at, notes, status, services(name)').order('scheduled_at').limit(300)) as any[]).map((a) => ({ ...a, service: one<any>(a.services)?.name ?? '' })),
  );
  const [sheet, setSheet] = useState<Appt | 'new' | null>(null);
  const shown = (list.data ?? []).filter((a) => filter === 'all' || a.status === 'scheduled');

  const setStatus = async (a: Appt, status: string) => {
    try {
      must(await supabase.from('appointments').update({ status }).eq('id', a.id).select('id').single());
      setSheet(null);
      void list.reload();
    } catch (e) {
      window.alert(errMsg(e));
    }
  };

  const convert = (a: Appt) => {
    navigate('/nova-os', { state: { appointment: { id: a.id, customer_name: a.customer_name, phone: a.phone, plate: a.plate, model: a.model, service_id: a.service_id } } });
  };

  return (
    <div className="animate-rise">
      <PageHeader
        title="Agendamentos"
        back
        right={
          <button onClick={() => setSheet('new')} aria-label="Novo agendamento" className="flex h-12 w-12 items-center justify-center rounded-full bg-brand text-white">
            <Plus size={22} />
          </button>
        }
      />
      <div className="space-y-3 px-4 pb-4">
        <StaleBanner show={list.stale} />
        <Chips value={filter} onChange={setFilter} options={[{ key: 'scheduled', label: 'Próximos' }, { key: 'all', label: 'Todos' }]} />
        {list.error && <ErrorBox message={list.error} onRetry={() => void list.reload()} />}
        {list.loading && <Spinner />}
        {!list.loading && shown.length === 0 && !list.error && <Empty>Nenhum agendamento.</Empty>}
        <ul className="space-y-2">
          {shown.map((a) => (
            <li key={a.id}>
              <button onClick={() => setSheet(a)} className="card flex min-h-[64px] w-full items-center justify-between gap-2 px-4 py-3 text-left">
                <span>
                  <span className="block font-semibold">{a.customer_name}</span>
                  <span className="block text-xs text-mute">
                    {fmtDateTime(a.scheduled_at)}{a.plate && ` · ${displayPlate(a.plate)}`}{a.service && ` · ${a.service}`}
                  </span>
                </span>
                <span className="shrink-0 text-xs text-mute">{ST[a.status]}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
      {sheet && (
        <ApptSheet
          appt={sheet === 'new' ? null : sheet}
          establishmentId={profile!.establishment_id}
          onClose={() => setSheet(null)}
          onSaved={() => { setSheet(null); void list.reload(); }}
          onStatus={setStatus}
          onConvert={convert}
        />
      )}
    </div>
  );
}

function ApptSheet({ appt, establishmentId, onClose, onSaved, onStatus, onConvert }: {
  appt: Appt | null; establishmentId: string; onClose: () => void; onSaved: () => void;
  onStatus: (a: Appt, s: string) => void; onConvert: (a: Appt) => void;
}) {
  const services = useLoad<{ id: string; name: string }[]>('services-active', async () =>
    must(await supabase.from('services').select('id, name').eq('active', true).order('name')) as any[],
  );
  const [name, setName] = useState(appt?.customer_name ?? '');
  const [phone, setPhone] = useState(appt?.phone ? formatPhone(appt.phone) : '');
  const [plate, setPlate] = useState(appt?.plate ?? '');
  const [model, setModel] = useState(appt?.model ?? '');
  const [serviceId, setServiceId] = useState(appt?.service_id ?? '');
  const [when, setWhen] = useState(toLocalInput(appt ? new Date(appt.scheduled_at) : new Date(Date.now() + 3600000)));
  const [notes, setNotes] = useState(appt?.notes ?? '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const save = async () => {
    if (busy) return;
    if (name.trim().length < 2) return setError('Informe o nome do cliente.');
    if (plate && !isValidPlate(plate)) return setError('Placa inválida.');
    const d = new Date(when);
    if (isNaN(d.getTime())) return setError('Informe data e hora.');
    setBusy(true);
    setError('');
    try {
      const row = {
        customer_name: name.trim(), phone: digits(phone) || null, plate: plate ? normalizePlate(plate) : null,
        model: model.trim() || null, service_id: serviceId || null, scheduled_at: d.toISOString(), notes: notes.trim() || null,
      };
      if (appt) must(await supabase.from('appointments').update(row).eq('id', appt.id).select('id').single());
      else must(await supabase.from('appointments').insert({ ...row, establishment_id: establishmentId }).select('id').single());
      onSaved();
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };

  return (
    <Sheet open title={appt ? 'Agendamento' : 'Novo agendamento'} onClose={onClose}>
      <div className="space-y-4 pb-2">
        <Field label="Cliente *" value={name} onChange={setName} />
        <Field label="Telefone" value={phone} onChange={(v) => setPhone(formatPhone(v))} inputMode="tel" />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Placa" value={displayPlate(plate)} onChange={(v) => setPlate(normalizePlate(v))} autoCapitalize="characters" />
          <Field label="Modelo" value={model} onChange={setModel} />
        </div>
        <div>
          <Label>Serviço</Label>
          <select className="field" value={serviceId} onChange={(e) => setServiceId(e.target.value)}>
            <option value="">A definir</option>
            {(services.data ?? []).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
        <div>
          <Label>Data e hora *</Label>
          <input type="datetime-local" className="field" value={when} onChange={(e) => setWhen(e.target.value)} />
        </div>
        <Field label="Observações" value={notes} onChange={setNotes} />
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void save()}>
          {busy && <Loader2 className="animate-spin" size={20} />} Salvar
        </button>
        {appt && appt.status === 'scheduled' && (
          <div className="grid grid-cols-2 gap-3">
            <button className="btn-ghost col-span-2" onClick={() => onConvert(appt)}>Transformar em O.S.</button>
            <button className="btn-ghost" onClick={() => onStatus(appt, 'no_show')}>Não compareceu</button>
            <button className="btn-ghost text-bad" onClick={() => window.confirm('Cancelar agendamento?') && onStatus(appt, 'cancelled')}>Cancelar</button>
          </div>
        )}
      </div>
    </Sheet>
  );
}
