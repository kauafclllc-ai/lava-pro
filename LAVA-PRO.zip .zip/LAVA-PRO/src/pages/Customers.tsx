import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Loader2, Phone, Plus, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useLoad } from '../lib/useLoad';
import { errMsg, must } from '../lib/api';
import { brl, digits, displayPlate, formatPhone, fmtDateTime, one } from '../lib/format';
import type { Customer, OrderStatus } from '../lib/types';
import { Empty, ErrorBox, Field, PageHeader, Sheet, Spinner, StaleBanner, StatusChip } from '../components/ui';

interface HistoryRow {
  id: string;
  number: number;
  status: OrderStatus;
  total: number;
  created_at: string;
  plate: string;
  model: string;
}

export default function Customers() {
  const [params, setParams] = useSearchParams();
  const { profile } = useAuth();
  const list = useLoad<Customer[]>('customers', async () =>
    must(await supabase.from('customers').select('id, name, phone').order('name').limit(1000)) as Customer[],
  );
  const [q, setQ] = useState('');
  const [sheet, setSheet] = useState<Customer | 'new' | null>(params.get('novo') ? 'new' : null);

  const visible = useMemo(() => {
    const s = q.trim().toLowerCase();
    const d = digits(q);
    return (list.data ?? []).filter((c) => !s || c.name.toLowerCase().includes(s) || (d && (c.phone ?? '').includes(d)));
  }, [list.data, q]);

  const close = () => {
    setSheet(null);
    if (params.get('novo')) setParams({}, { replace: true });
  };

  return (
    <div className="animate-rise">
      <PageHeader
        title="Clientes"
        back
        right={
          <button onClick={() => setSheet('new')} aria-label="Novo cliente" className="flex h-12 w-12 items-center justify-center rounded-full bg-brand text-white">
            <Plus size={22} />
          </button>
        }
      />
      <div className="space-y-3 px-4 pb-4">
        <StaleBanner show={list.stale} />
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-mute" size={18} />
          <input className="field pl-11" placeholder="Buscar por nome ou telefone" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        {list.error && <ErrorBox message={list.error} onRetry={() => void list.reload()} />}
        {list.loading && <Spinner />}
        {!list.loading && visible.length === 0 && !list.error && <Empty>Nenhum cliente encontrado.</Empty>}
        <ul className="space-y-2">
          {visible.map((c) => (
            <li key={c.id}>
              <button onClick={() => setSheet(c)} className="card flex min-h-[60px] w-full items-center justify-between px-4 py-3 text-left transition active:scale-[0.98]">
                <span className="font-semibold">{c.name}</span>
                <span className="flex items-center gap-1 text-sm text-mute">
                  <Phone size={14} /> {c.phone ? formatPhone(c.phone) : '—'}
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>
      {sheet && (
        <CustomerSheet
          customer={sheet === 'new' ? null : sheet}
          establishmentId={profile!.establishment_id}
          onClose={close}
          onSaved={() => {
            close();
            void list.reload();
          }}
        />
      )}
    </div>
  );
}

function CustomerSheet({
  customer,
  establishmentId,
  onClose,
  onSaved,
}: {
  customer: Customer | null;
  establishmentId: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const navigate = useNavigate();
  const [name, setName] = useState(customer?.name ?? '');
  const [phone, setPhone] = useState(customer?.phone ? formatPhone(customer.phone) : '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [history, setHistory] = useState<HistoryRow[] | null>(null);
  const [vehicles, setVehicles] = useState<{ id: string; plate: string; model: string }[]>([]);

  useEffect(() => {
    if (!customer) return;
    void (async () => {
      const [o, v] = await Promise.all([
        supabase
          .from('orders')
          .select('id, number, status, total, created_at, vehicles(plate, model)')
          .eq('customer_id', customer.id)
          .order('created_at', { ascending: false })
          .limit(20),
        supabase.from('vehicles').select('id, plate, model').eq('customer_id', customer.id),
      ]);
      setHistory(
        ((o.data ?? []) as any[]).map((r) => {
          const ve = one<any>(r.vehicles);
          return { id: r.id, number: r.number, status: r.status, total: Number(r.total), created_at: r.created_at, plate: ve?.plate ?? '', model: ve?.model ?? '' };
        }),
      );
      setVehicles((v.data ?? []) as any[]);
    })();
  }, [customer]);

  const save = async () => {
    if (busy) return;
    if (name.trim().length < 2) {
      setError('Informe o nome do cliente.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const row = { name: name.trim(), phone: digits(phone) || null };
      if (customer) must(await supabase.from('customers').update(row).eq('id', customer.id).select('id').single());
      else must(await supabase.from('customers').insert({ ...row, establishment_id: establishmentId }).select('id').single());
      onSaved();
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };

  return (
    <Sheet open title={customer ? 'Cliente' : 'Novo cliente'} onClose={onClose}>
      <div className="space-y-4 pb-2">
        <Field label="Nome *" value={name} onChange={setName} placeholder="Nome completo" />
        <Field label="Telefone" value={phone} onChange={(v) => setPhone(formatPhone(v))} inputMode="tel" placeholder="(00) 00000-0000" />
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void save()}>
          {busy && <Loader2 className="animate-spin" size={20} />} Salvar
        </button>

        {customer && (
          <>
            {vehicles.length > 0 && (
              <div>
                <h3 className="mb-2 text-sm font-semibold text-mute">Veículos</h3>
                <div className="flex flex-wrap gap-2">
                  {vehicles.map((v) => (
                    <span key={v.id} className="rounded-full bg-card px-3 py-1.5 text-sm">
                      {displayPlate(v.plate)} · {v.model}
                    </span>
                  ))}
                </div>
              </div>
            )}
            <div>
              <h3 className="mb-2 text-sm font-semibold text-mute">Histórico</h3>
              {history === null && <Spinner />}
              {history && history.length === 0 && <p className="text-sm text-mute">Nenhuma O.S. deste cliente.</p>}
              <ul className="space-y-2">
                {(history ?? []).map((h) => (
                  <li key={h.id}>
                    <button onClick={() => navigate(`/os/${h.id}`)} className="card flex min-h-[56px] w-full items-center justify-between gap-2 px-3 py-2 text-left">
                      <span>
                        <span className="block text-sm font-semibold">
                          O.S. #{h.number} · {displayPlate(h.plate)}
                        </span>
                        <span className="block text-xs text-mute">
                          {fmtDateTime(h.created_at)} · {brl(h.total)}
                        </span>
                      </span>
                      <StatusChip status={h.status} />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </>
        )}
      </div>
    </Sheet>
  );
}
