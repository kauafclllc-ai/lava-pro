import { useState } from 'react';
import { FileSpreadsheet, FileText, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useLoad } from '../lib/useLoad';
import { errMsg, must } from '../lib/api';
import { PAY_LABEL, brl, daysAgoStart, monthStart, startOfToday } from '../lib/format';
import { exportReportPdf, exportReportXlsx, type Report } from '../lib/export';
import { Chips, Empty, ErrorBox, Notice, PageHeader, Spinner, StaleBanner } from '../components/ui';

type Period = 'today' | '7d' | 'month' | 'custom';

const fmt = (d: Date) => d.toLocaleDateString('pt-BR');
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export default function Reports() {
  const { establishmentName } = useAuth();
  const [period, setPeriod] = useState<Period>('today');
  const [from, setFrom] = useState(iso(daysAgoStart(30)));
  const [to, setTo] = useState(iso(startOfToday()));
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState('');

  const range = (): { a: Date; b: Date } => {
    const tomorrow = startOfToday();
    tomorrow.setDate(tomorrow.getDate() + 1);
    if (period === 'today') return { a: startOfToday(), b: tomorrow };
    if (period === '7d') return { a: daysAgoStart(6), b: tomorrow };
    if (period === 'month') return { a: monthStart(), b: tomorrow };
    const a = new Date(`${from}T00:00:00`);
    const b = new Date(`${to}T00:00:00`);
    b.setDate(b.getDate() + 1);
    return { a, b };
  };
  const { a, b } = range();
  const label = `${fmt(a)} a ${fmt(new Date(b.getTime() - 86400000))}`;
  const valid = !isNaN(a.getTime()) && !isNaN(b.getTime()) && b > a;

  const rep = useLoad<Report | null>(
    valid ? `report:${a.getTime()}:${b.getTime()}` : null,
    async () => (valid ? (must(await supabase.rpc('report_summary', { p_from: a.toISOString(), p_to: b.toISOString() })) as Report) : null),
    [a.getTime(), b.getTime()],
  );
  const r = rep.data;

  const run = async (kind: 'xlsx' | 'pdf') => {
    if (!r || busy) return;
    setBusy(kind);
    setMsg('');
    try {
      if (kind === 'xlsx') await exportReportXlsx(r, establishmentName, label);
      else await exportReportPdf(r, establishmentName, label);
      setMsg('Arquivo gerado. Escolha onde salvar ou compartilhar.');
    } catch (e) {
      setMsg(`Não foi possível exportar: ${errMsg(e)}`);
    }
    setBusy('');
  };

  const n = (x: unknown) => Number(x) || 0;

  return (
    <div className="animate-rise">
      <PageHeader title="Relatórios" back />
      <div className="space-y-3 px-4 pb-4">
        <Chips
          value={period}
          onChange={setPeriod}
          options={[{ key: 'today', label: 'Hoje' }, { key: '7d', label: '7 dias' }, { key: 'month', label: 'Este mês' }, { key: 'custom', label: 'Personalizado' }]}
        />
        {period === 'custom' && (
          <div className="grid grid-cols-2 gap-3">
            <input type="date" className="field" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="Data inicial" />
            <input type="date" className="field" value={to} onChange={(e) => setTo(e.target.value)} aria-label="Data final" />
          </div>
        )}
        {!valid && <Notice tone="warn">Período inválido.</Notice>}
        <p className="text-xs text-mute">{label}</p>
        <StaleBanner show={rep.stale} />
        {rep.error && <ErrorBox message={rep.error} onRetry={() => void rep.reload()} />}
        {rep.loading && <Spinner />}
        {r && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <Tile label="Veículos" value={String(n(r.orders))} />
              <Tile label="Faturamento" value={brl(r.billed)} />
              <Tile label="Recebido" value={brl(r.received)} tone="text-ok" />
              <Tile label="Despesas" value={brl(r.expenses)} tone="text-bad" />
              <Tile label="Lucro estimado" value={brl(n(r.received) - n(r.expenses))} />
              <Tile label="Ticket médio" value={brl(n(r.orders) ? n(r.billed) / n(r.orders) : 0)} />
            </div>
            <Section title="Recebimentos por forma" empty={r.by_method.length === 0}>
              {r.by_method.map((m) => <Row key={m.method} a={(PAY_LABEL as Record<string, string>)[m.method] ?? m.method} b={brl(m.amount)} />)}
            </Section>
            <Section title="Serviços mais vendidos" empty={r.top_services.length === 0}>
              {r.top_services.map((s) => <Row key={s.name} a={`${s.name} (${s.qty}x)`} b={brl(s.amount)} />)}
            </Section>
            <Section title="Funcionários" empty={r.employees.length === 0}>
              {r.employees.map((e) => <Row key={e.id} a={`${e.name} · ${e.orders} O.S.`} b={n(e.commission_pct) ? `${brl(e.commission)} (${e.commission_pct}%)` : brl(e.billed)} />)}
            </Section>
            <Section title="Produtos consumidos" empty={r.products.length === 0}>
              {r.products.map((p) => <Row key={p.name} a={p.name} b={`${p.qty} ${p.unit}`} />)}
            </Section>
            <div className="grid grid-cols-2 gap-3">
              <button className="btn-ghost" disabled={!!busy} onClick={() => void run('pdf')}>
                {busy === 'pdf' ? <Loader2 className="animate-spin" size={18} /> : <FileText size={18} />} PDF
              </button>
              <button className="btn-ghost" disabled={!!busy} onClick={() => void run('xlsx')}>
                {busy === 'xlsx' ? <Loader2 className="animate-spin" size={18} /> : <FileSpreadsheet size={18} />} Excel
              </button>
            </div>
            {msg && <Notice>{msg}</Notice>}
          </>
        )}
      </div>
    </div>
  );
}

const Tile = ({ label, value, tone = '' }: { label: string; value: string; tone?: string }) => (
  <div className="card p-4">
    <div className="text-xs text-mute">{label}</div>
    <div className={`text-xl font-extrabold ${tone}`}>{value}</div>
  </div>
);
const Row = ({ a, b }: { a: string; b: string }) => (
  <li className="flex justify-between gap-2 py-1.5 text-sm">
    <span>{a}</span>
    <b className="shrink-0">{b}</b>
  </li>
);
const Section = ({ title, empty, children }: { title: string; empty: boolean; children: React.ReactNode }) => (
  <div className="card p-4">
    <h3 className="mb-1 font-semibold">{title}</h3>
    {empty ? <Empty>Sem dados no período.</Empty> : <ul className="divide-y divide-white/5">{children}</ul>}
  </div>
);
