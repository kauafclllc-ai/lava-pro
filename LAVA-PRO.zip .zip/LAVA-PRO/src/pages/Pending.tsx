import { RefreshCw, Trash2 } from 'lucide-react';
import { discardOp, retryOp, runSync } from '../lib/outbox';
import { useOnline, useOutbox } from '../lib/hooks';
import { fmtDateTime } from '../lib/format';
import { Empty, Notice, PageHeader } from '../components/ui';

const STATE: Record<string, { t: string; c: string }> = {
  pending: { t: 'Aguardando envio', c: 'text-warn' },
  failed: { t: 'Falhou', c: 'text-bad' },
  conflict: { t: 'Conflito', c: 'text-bad' },
};

export default function Pending() {
  const { ops, syncing } = useOutbox();
  const online = useOnline();

  return (
    <div className="animate-rise">
      <PageHeader
        title="Pendências de envio"
        back
        right={
          <button onClick={() => void runSync()} disabled={!online || syncing} aria-label="Enviar agora" className="flex h-12 w-12 items-center justify-center rounded-full bg-brand text-white disabled:opacity-40">
            <RefreshCw size={20} className={syncing ? 'animate-spin' : ''} />
          </button>
        }
      />
      <div className="space-y-3 px-4 pb-4">
        <Notice>Estas operações foram feitas sem confirmação do servidor. Só são consideradas salvas depois de enviadas com sucesso.</Notice>
        {!online && <Notice tone="warn">Sem internet. O envio é retomado automaticamente quando a conexão voltar.</Notice>}
        {ops.length === 0 && <Empty>Nada pendente. Tudo foi enviado ao servidor.</Empty>}
        <ul className="space-y-2">
          {ops.map((o) => (
            <li key={o.id} className="card space-y-2 p-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold">{o.label}</span>
                <span className={`text-xs font-semibold ${STATE[o.state].c}`}>{STATE[o.state].t}</span>
              </div>
              <div className="text-xs text-mute">Criada em {fmtDateTime(new Date(o.createdAt).toISOString())} · tentativas: {o.attempts}</div>
              {o.error && <p className="rounded-lg bg-bad/10 px-3 py-2 text-xs text-bad">{o.error}</p>}
              <div className="grid grid-cols-2 gap-2">
                <button className="btn-ghost" disabled={!online} onClick={() => void retryOp(o.id)}>Tentar de novo</button>
                <button
                  className="btn-ghost text-bad"
                  onClick={() => window.confirm('Descartar esta operação? Ela NÃO será enviada ao servidor.') && void discardOp(o.id)}
                >
                  <Trash2 size={16} /> Descartar
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
