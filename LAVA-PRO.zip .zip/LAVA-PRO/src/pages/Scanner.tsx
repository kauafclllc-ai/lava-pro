import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, Search } from 'lucide-react';
import jsQR from 'jsqr';
import { supabase } from '../lib/supabase';
import { Field, Notice, PageHeader } from '../components/ui';
import { vibrate } from '../lib/format';

const UUID = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

export default function Scanner() {
  const navigate = useNavigate();
  const video = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState('');
  const [hint, setHint] = useState('');
  const [num, setNum] = useState('');

  useEffect(() => {
    let stream: MediaStream | null = null;
    let raf = 0;
    let stopped = false;
    const canvas = document.createElement('canvas');

    const openByToken = async (token: string) => {
      const { data } = await supabase.from('orders').select('id').or(`public_token.eq.${token},id.eq.${token}`).limit(1);
      if (data && data.length > 0) navigate(`/os/${(data[0] as any).id}`, { replace: true });
      else {
        stopped = false;
        setHint('O.S. não encontrada neste estabelecimento.');
        raf = requestAnimationFrame(tick);
      }
    };

    const tick = () => {
      const v = video.current;
      if (stopped || !v) return;
      if (v.readyState === v.HAVE_ENOUGH_DATA && v.videoWidth > 0) {
        canvas.width = v.videoWidth;
        canvas.height = v.videoHeight;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (ctx) {
          ctx.drawImage(v, 0, 0);
          const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(img.data, img.width, img.height, { inversionAttempts: 'dontInvert' });
          if (code?.data) {
            const m = code.data.match(UUID);
            if (m) {
              stopped = true;
              vibrate(30);
              void openByToken(m[0].toLowerCase());
              return;
            }
            setHint('QR Code lido, mas não é de uma O.S. do LAVA PRO.');
          }
        }
      }
      raf = requestAnimationFrame(tick);
    };

    void (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
        if (stopped) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        if (video.current) {
          video.current.srcObject = stream;
          await video.current.play();
        }
        raf = requestAnimationFrame(tick);
      } catch (e) {
        const n = (e as any)?.name;
        setError(
          n === 'NotAllowedError' || n === 'SecurityError'
            ? 'Permissão da câmera negada. Abra as configurações do Android > Apps > LAVA PRO > Permissões e ative a câmera. Enquanto isso, busque pelo número da O.S. abaixo.'
            : 'Não foi possível abrir a câmera neste aparelho. Busque pelo número da O.S. abaixo.',
        );
      }
    })();

    return () => {
      stopped = true;
      cancelAnimationFrame(raf);
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, [navigate]);

  const search = async () => {
    const n = parseInt(num.replace(/\D/g, ''), 10);
    if (!n) return setHint('Informe o número da O.S.');
    const { data, error: err } = await supabase.from('orders').select('id').eq('number', n).limit(1);
    if (err) return setHint('Não foi possível buscar agora. Verifique a conexão.');
    if (!data || data.length === 0) return setHint('O.S. não encontrada.');
    navigate(`/os/${(data[0] as any).id}`);
  };

  return (
    <div className="animate-rise">
      <PageHeader title="Ler QR Code" back />
      <div className="space-y-4 px-4 pb-4">
        {error ? (
          <Notice tone="warn">{error}</Notice>
        ) : (
          <div className="relative overflow-hidden rounded-2xl bg-black">
            <video ref={video} playsInline muted className="aspect-square w-full object-cover" />
            <div className="pointer-events-none absolute inset-8 rounded-2xl border-2 border-brand-light/80" />
            <Camera className="absolute right-3 top-3 text-white/60" size={20} />
          </div>
        )}
        <p className="text-center text-sm text-mute">Aponte para o QR Code do cupom da O.S.</p>
        <div className="card space-y-3 p-4">
          <Field label="Ou digite o número da O.S." value={num} onChange={setNum} inputMode="numeric" placeholder="Ex.: 125" />
          <button className="btn-primary w-full" onClick={() => void search()}>
            <Search size={20} /> Buscar
          </button>
        </div>
        {hint && <Notice>{hint}</Notice>}
      </div>
    </div>
  );
}
