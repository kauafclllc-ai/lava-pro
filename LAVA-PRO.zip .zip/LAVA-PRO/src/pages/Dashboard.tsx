import { type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, Bell, Car, CheckCircle2, ChevronRight, CircleDollarSign, Clock, PackageCheck, Play, TrendingDown, TrendingUp, Wallet } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { brl, daysAgoStart, displayPlate, fmtTime, one, startOfToday } from '../lib/format';
import type { OrderStatus } from '../lib/types';
import { useLoad } from '../lib/useLoad';
import { can } from '../lib/perm';
import { ConnectionBadge, ErrorBox, LogoMark, Spinner, StaleBanner, StatusChip } from '../components/ui';

interface RecentOrder {
  id: string;
  number: number;
  status: OrderStatus;
  total: number;
  created_at: string;
  plate: string;
  model: string;
}

interface Data {
  counts: Record<string, number>;
  open: number;
  deliveredToday: number;
  revenueToday: number;
  expensesToday: number;
  pending: number;
  week: { label: string; value: number }[];
  recent: RecentOrder[];
  top: { name: string; qty: number }[];
  lowStock: { name: string; qty: number; unit: string }[];
  unread: number;
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { profile, establishmentName, session } = useAuth();
  const uid = session?.user.id ?? '';
  const isWasher = profile?.role === 'washer';
  const finance = can(profile?.role, 'finance');
  const stockView = can(profile?.role, 'stock');
  const res = useLoad<Data>('dashboard', async () => {
    const today = startOfToday().toISOString();
    const weekStart = daysAgoStart(6).toISOString();
    const monthStart = daysAgoStart(29).toISOString();

    const results = await Promise.all([
      supabase.from('orders').select('status').not('status', 'in', '(delivered,cancelled)'),
      supabase.from('orders').select('id', { count: 'exact', head: true }).eq('status', 'delivered').gte('delivered_at', today),
      supabase.from('orders').select('total, created_at').neq('status', 'cancelled').gte('created_at', weekStart),
      supabase.from('orders').select('total').eq('payment_status', 'pending').neq('status', 'cancelled'),
      supabase.from('expenses').select('amount').gte('created_at', today),
      supabase
        .from('orders')
        .select('id, number, status, total, created_at, vehicles(plate, model)')
        .order('created_at', { ascending: false })
        .limit(5),
      supabase
        .from('order_items')
        .select('name, quantity, orders!inner(status, created_at)')
        .neq('orders.status', 'cancelled')
        .gte('orders.created_at', monthStart),
      stockView ? supabase.from('products').select('name, qty, min_qty, unit').eq('active', true) : Promise.resolve({ data: [], error: null }),
      stockView ? supabase.from('notifications').select('read_by').order('created_at', { ascending: false }).limit(50) : Promise.resolve({ data: [], error: null }),
    ]);

    const failed = results.find((r) => r.error);
    if (failed?.error) throw failed.error;
    const [open, deliv, week, pend, exp, recent, items, prods, notifs] = results as any[];

    const counts: Record<string, number> = {};
    for (const o of open.data ?? []) counts[o.status] = (counts[o.status] ?? 0) + 1;

    const weekArr: { label: string; value: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const day = daysAgoStart(i);
      const key = day.toDateString();
      const value = (week.data ?? [])
        .filter((o: any) => new Date(o.created_at).toDateString() === key)
        .reduce((s: number, o: any) => s + Number(o.total), 0);
      weekArr.push({ label: day.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', ''), value });
    }

    const topMap = new Map<string, number>();
    for (const it of items.data ?? []) topMap.set(it.name, (topMap.get(it.name) ?? 0) + Number(it.quantity));
    const top = [...topMap.entries()]
      .map(([name, qty]) => ({ name, qty }))
      .sort((a, b) => b.qty - a.qty)
      .slice(0, 5);

    return {
      counts,
      open: (open.data ?? []).length,
      deliveredToday: deliv.count ?? 0,
      revenueToday: weekArr[6].value,
      expensesToday: (exp.data ?? []).reduce((s: number, e: any) => s + Number(e.amount), 0),
      pending: (pend.data ?? []).reduce((s: number, o: any) => s + Number(o.total), 0),
      week: weekArr,
      recent: (recent.data ?? []).map((o: any) => {
        const v = one<any>(o.vehicles);
        return {
          id: o.id,
          number: o.number,
          status: o.status,
          total: Number(o.total),
          created_at: o.created_at,
          plate: v?.plate ?? '',
          model: v?.model ?? '',
        };
      }),
      top,
      lowStock: (prods.data ?? [])
        .filter((p: any) => Number(p.qty) <= Number(p.min_qty))
        .map((p: any) => ({ name: p.name, qty: Number(p.qty), unit: p.unit })),
      unread: (notifs.data ?? []).filter((n: any) => !(n.read_by ?? []).includes(uid)).length,
    };
  });
  const data = res.data;
  const error = res.error;
  const loading = res.loading;
  const load = res.reload;

  const initial = (profile?.full_name ?? '?').trim().charAt(0).toUpperCase();

  return (
    <div className="animate-rise">
      <header className="pt-safe flex items-center gap-3 px-4 pb-3">
        <LogoMark size={40} />
        <div className="min-w-0 flex-1">
          <div className="text-sm font-extrabold tracking-wide">LAVA PRO</div>
          <div className="truncate text-xs text-mute">{establishmentName}</div>
        </div>
        <ConnectionBadge />
        {stockView && (
          <button onClick={() => navigate('/notificacoes')} aria-label="Notificações" className="relative flex h-12 w-12 items-center justify-center rounded-full bg-card">
            <Bell size={20} />
            {(data?.unread ?? 0) > 0 && (
              <span className="absolute right-1 top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-bad px-1 text-[10px] font-bold text-white">{data!.unread}</span>
            )}
          </button>
        )}
        <button
          onClick={() => navigate('/mais')}
          aria-label="Minha conta"
          className="flex h-12 w-12 items-center justify-center rounded-full bg-card text-base font-bold text-brand-light"
        >
          {initial}
        </button>
      </header>

      <div className="space-y-5 px-4 pb-4">
        <StaleBanner show={res.stale} />
        {error && <ErrorBox message={error} onRetry={() => void load()} />}
        {loading && !data && <Spinner label="Carregando painel..." />}

        {data && (
          <>
            <section>
              <h2 className="mb-2 text-sm font-semibold text-mute">Pátio agora</h2>
              <div className="grid grid-cols-2 gap-3">
                <StatCard icon={<Car size={20} />} label="Veículos no pátio" value={data.open} tone="text-brand-light" onClick={() => navigate('/patio')} />
                <StatCard icon={<Clock size={20} />} label="Aguardando início" value={data.counts.waiting ?? 0} tone="text-slate-300" onClick={() => navigate('/patio?status=waiting')} />
                <StatCard icon={<Play size={20} />} label="Em execução" value={data.counts.in_progress ?? 0} tone="text-tech" onClick={() => navigate('/patio?status=in_progress')} />
                <StatCard icon={<CheckCircle2 size={20} />} label="Concluídos" value={data.counts.done ?? 0} tone="text-ok" onClick={() => navigate('/patio?status=done')} />
                <StatCard icon={<CircleDollarSign size={20} />} label="Aguardando pagamento" value={data.counts.awaiting_payment ?? 0} tone="text-warn" onClick={() => navigate('/patio?status=awaiting_payment')} />
                <StatCard icon={<PackageCheck size={20} />} label="Entregues hoje" value={data.deliveredToday} tone="text-mute" onClick={() => navigate('/patio?status=delivered')} />
              </div>
            </section>

            {data.lowStock.length > 0 && (
              <button onClick={() => navigate('/estoque')} className="card flex w-full items-start gap-3 border-warn/30 p-4 text-left">
                <AlertTriangle className="mt-0.5 shrink-0 text-warn" size={20} />
                <span className="text-sm">
                  <b>Estoque baixo:</b> {data.lowStock.slice(0, 4).map((p) => `${p.name} (${p.qty} ${p.unit})`).join(', ')}{data.lowStock.length > 4 && ` e mais ${data.lowStock.length - 4}`}
                </span>
              </button>
            )}

            {finance && (<>
            <section>
              <h2 className="mb-2 text-sm font-semibold text-mute">Financeiro de hoje</h2>
              <div className="grid grid-cols-2 gap-3">
                <MoneyCard icon={<TrendingUp size={18} />} label="Faturamento" value={brl(data.revenueToday)} tone="text-ok" onClick={() => navigate('/financeiro')} />
                <MoneyCard icon={<TrendingDown size={18} />} label="Despesas" value={brl(data.expensesToday)} tone="text-bad" onClick={() => navigate('/financeiro')} />
                <MoneyCard
                  icon={<Wallet size={18} />}
                  label="Lucro operacional estimado"
                  value={brl(data.revenueToday - data.expensesToday)}
                  tone="text-brand-light"
                  onClick={() => navigate('/financeiro')}
                />
                <MoneyCard icon={<CircleDollarSign size={18} />} label="Valores pendentes" value={brl(data.pending)} tone="text-warn" onClick={() => navigate('/financeiro')} />
              </div>
            </section>

            <section className="card p-4">
              <h2 className="mb-3 text-sm font-semibold">Faturamento — últimos 7 dias</h2>
              <WeekChart week={data.week} />
            </section>
            </>)}

            {finance && <section className="card p-4">
              <h2 className="mb-3 text-sm font-semibold">Serviços mais vendidos (30 dias)</h2>
              {data.top.length === 0 ? (
                <p className="text-sm text-mute">Ainda não há vendas registradas.</p>
              ) : (
                <ul className="space-y-3">
                  {data.top.map((t, i) => (
                    <li key={t.name} className="flex items-center gap-3">
                      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-panel text-sm font-bold text-brand-light">{i + 1}</span>
                      <span className="flex-1 truncate">{t.name}</span>
                      <span className="text-sm font-semibold text-mute">{t.qty}x</span>
                    </li>
                  ))}
                </ul>
              )}
            </section>}

            <section>
              <h2 className="mb-2 text-sm font-semibold text-mute">{isWasher ? 'Minhas tarefas' : 'Últimas ordens'}</h2>
              {data.recent.length === 0 ? (
                <div className="card p-4 text-sm text-mute">Nenhuma ordem de serviço ainda. Toque em Nova O.S. para começar.</div>
              ) : (
                <ul className="space-y-2">
                  {data.recent.map((o) => (
                    <li key={o.id}>
                      <button
                        onClick={() => navigate(`/os/${o.id}`)}
                        className="card flex min-h-[64px] w-full items-center gap-3 px-4 py-3 text-left transition active:scale-[0.98]"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold tracking-wider">{displayPlate(o.plate)}</span>
                            <span className="text-xs text-mute">O.S. #{o.number}</span>
                          </div>
                          <div className="truncate text-sm text-mute">
                            {o.model} · {fmtTime(o.created_at)} · {brl(o.total)}
                          </div>
                        </div>
                        <StatusChip status={o.status} />
                        <ChevronRight size={18} className="text-mute" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, tone, onClick }: { icon: ReactNode; label: string; value: number; tone: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="card min-h-[88px] p-3.5 text-left transition active:scale-[0.97]">
      <div className={`mb-1 flex items-center gap-2 ${tone}`}>{icon}</div>
      <div className="text-2xl font-extrabold">{value}</div>
      <div className="text-xs text-mute">{label}</div>
    </button>
  );
}

function MoneyCard({ icon, label, value, tone, onClick }: { icon: ReactNode; label: string; value: string; tone: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="card min-h-[88px] p-3.5 text-left transition active:scale-[0.97]">
      <div className={`mb-1 flex items-center gap-2 text-xs font-semibold ${tone}`}>
        {icon}
        <span className="text-mute">{label}</span>
      </div>
      <div className="text-lg font-extrabold">{value}</div>
    </button>
  );
}

function WeekChart({ week }: { week: { label: string; value: number }[] }) {
  const max = Math.max(...week.map((w) => w.value), 1);
  const H = 90;
  const bw = 28;
  const gap = 12;
  const width = week.length * bw + (week.length - 1) * gap;
  return (
    <div>
      <svg viewBox={`0 0 ${width} ${H + 22}`} className="w-full" role="img" aria-label="Gráfico de faturamento dos últimos 7 dias">
        <defs>
          <linearGradient id="bar" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#9B7BFF" />
            <stop offset="100%" stopColor="#398BFF" />
          </linearGradient>
        </defs>
        {week.map((w, i) => {
          const h = Math.max(w.value > 0 ? 4 : 2, (w.value / max) * H);
          const x = i * (bw + gap);
          return (
            <g key={i}>
              <rect x={x} y={H - h} width={bw} height={h} rx={6} fill={w.value > 0 ? 'url(#bar)' : '#2A3248'} />
              <text x={x + bw / 2} y={H + 15} textAnchor="middle" fontSize="10" fill="#A8B0C2">
                {w.label}
              </text>
            </g>
          );
        })}
      </svg>
      <div className="mt-1 text-right text-xs text-mute">Maior dia: {brl(max === 1 && week.every((w) => w.value === 0) ? 0 : max)}</div>
    </div>
  );
}
