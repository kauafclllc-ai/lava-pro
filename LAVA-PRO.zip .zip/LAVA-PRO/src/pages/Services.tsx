import { useEffect, useState } from 'react';
import { Loader2, Plus } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useLoad } from '../lib/useLoad';
import { errMsg, must } from '../lib/api';
import { brl, parseMoney } from '../lib/format';
import { can } from '../lib/perm';
import { Empty, ErrorBox, Field, Label, Notice, PageHeader, Sheet, Spinner, StaleBanner } from '../components/ui';

interface Svc {
  id: string;
  name: string;
  price: number;
  active: boolean;
}
interface Prod {
  id: string;
  name: string;
  unit: string;
}

export default function Services() {
  const { profile } = useAuth();
  const manage = can(profile?.role, 'servicesManage');
  const list = useLoad<Svc[]>('services-all', async () =>
    (must(await supabase.from('services').select('id, name, price, active').order('name')) as any[]).map((s) => ({ ...s, price: Number(s.price) })),
  );
  const [sheet, setSheet] = useState<Svc | 'new' | null>(null);

  return (
    <div className="animate-rise">
      <PageHeader
        title="Serviços"
        back
        right={
          manage && (
            <button onClick={() => setSheet('new')} aria-label="Novo serviço" className="flex h-12 w-12 items-center justify-center rounded-full bg-brand text-white">
              <Plus size={22} />
            </button>
          )
        }
      />
      <div className="space-y-3 px-4 pb-4">
        <StaleBanner show={list.stale} />
        {!manage && <Notice>Somente gerente ou administrador pode alterar serviços.</Notice>}
        {list.error && <ErrorBox message={list.error} onRetry={() => void list.reload()} />}
        {list.loading && <Spinner />}
        {!list.loading && (list.data ?? []).length === 0 && !list.error && <Empty>Nenhum serviço cadastrado.</Empty>}
        <ul className="space-y-2">
          {(list.data ?? []).map((s) => (
            <li key={s.id}>
              <button
                disabled={!manage}
                onClick={() => setSheet(s)}
                className={`card flex min-h-[60px] w-full items-center justify-between px-4 py-3 text-left ${s.active ? '' : 'opacity-50'}`}
              >
                <span className="font-semibold">
                  {s.name}
                  {!s.active && <span className="ml-2 text-xs text-mute">inativo</span>}
                </span>
                <span className="font-bold">{brl(s.price)}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
      {sheet && (
        <ServiceSheet
          service={sheet === 'new' ? null : sheet}
          establishmentId={profile!.establishment_id}
          onClose={() => setSheet(null)}
          onSaved={() => {
            setSheet(null);
            void list.reload();
          }}
        />
      )}
    </div>
  );
}

function ServiceSheet({
  service,
  establishmentId,
  onClose,
  onSaved,
}: {
  service: Svc | null;
  establishmentId: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState(service?.name ?? '');
  const [price, setPrice] = useState(service ? String(service.price).replace('.', ',') : '');
  const [active, setActive] = useState(service?.active ?? true);
  const [products, setProducts] = useState<Prod[]>([]);
  const [uses, setUses] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    void (async () => {
      const [p, sp] = await Promise.all([
        supabase.from('products').select('id, name, unit').eq('active', true).order('name'),
        service ? supabase.from('service_products').select('product_id, qty').eq('service_id', service.id) : Promise.resolve({ data: [] as any[] }),
      ]);
      setProducts((p.data ?? []) as Prod[]);
      const map: Record<string, string> = {};
      for (const r of (sp.data ?? []) as any[]) map[r.product_id] = String(Number(r.qty)).replace('.', ',');
      setUses(map);
      setLoading(false);
    })();
  }, [service]);

  const save = async () => {
    if (busy) return;
    const value = parseMoney(price);
    if (name.trim().length < 2) return setError('Informe o nome do serviço.');
    if (value <= 0) return setError('Informe um preço maior que zero.');
    setBusy(true);
    setError('');
    try {
      let id = service?.id;
      const row = { name: name.trim(), price: value, active };
      if (service) must(await supabase.from('services').update(row).eq('id', service.id).select('id').single());
      else id = (must(await supabase.from('services').insert({ ...row, establishment_id: establishmentId }).select('id').single()) as any).id;

      // Produtos consumidos por uso do serviço (baixa automática de estoque)
      must(await supabase.from('service_products').delete().eq('service_id', id as string).select('product_id'));
      const rows = Object.entries(uses)
        .map(([product_id, q]) => ({ product_id, qty: parseMoney(q) }))
        .filter((r) => r.qty > 0)
        .map((r) => ({ ...r, service_id: id, establishment_id: establishmentId }));
      if (rows.length > 0) must(await supabase.from('service_products').insert(rows).select('product_id'));
      onSaved();
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };

  return (
    <Sheet open title={service ? 'Editar serviço' : 'Novo serviço'} onClose={onClose}>
      <div className="space-y-4 pb-2">
        <Field label="Nome *" value={name} onChange={setName} placeholder="Ex.: Lavagem completa" />
        <Field label="Preço (R$) *" value={price} onChange={setPrice} inputMode="decimal" placeholder="0,00" />
        <label className="flex min-h-[48px] items-center gap-3">
          <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} className="h-6 w-6 accent-[#7547F5]" />
          <span>Serviço ativo (aparece na Nova O.S.)</span>
        </label>

        <div>
          <Label>Produtos consumidos por uso (baixa automática do estoque)</Label>
          {loading && <Spinner />}
          {!loading && products.length === 0 && <p className="text-sm text-mute">Cadastre produtos no Estoque para vincular aqui.</p>}
          <ul className="space-y-2">
            {products.map((p) => (
              <li key={p.id} className="flex items-center gap-3">
                <span className="flex-1 text-sm">{p.name}</span>
                <input
                  className="field !min-h-[44px] w-24 text-center"
                  inputMode="decimal"
                  placeholder="0"
                  value={uses[p.id] ?? ''}
                  onChange={(e) => setUses((u) => ({ ...u, [p.id]: e.target.value }))}
                />
                <span className="w-8 text-xs text-mute">{p.unit}</span>
              </li>
            ))}
          </ul>
        </div>

        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void save()}>
          {busy && <Loader2 className="animate-spin" size={20} />} Salvar
        </button>
      </div>
    </Sheet>
  );
}
