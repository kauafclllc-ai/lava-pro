import { useNavigate } from 'react-router-dom';
import {
  BarChart3,
  Bell,
  CalendarDays,
  CarFront,
  CloudOff,
  LogOut,
  Package,
  QrCode,
  Receipt,
  Settings,
  Sparkles,
  UserCog,
  Users,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ROLE_LABEL } from '../lib/format';
import { can, type Feature } from '../lib/perm';
import { useOutbox } from '../lib/hooks';
import { PageHeader } from '../components/ui';

const MODULES: { label: string; icon: LucideIcon; to: string; feature?: Feature }[] = [
  { label: 'Clientes', icon: Users, to: '/clientes', feature: 'customers' },
  { label: 'Veículos', icon: CarFront, to: '/veiculos', feature: 'vehicles' },
  { label: 'Serviços', icon: Sparkles, to: '/servicos', feature: 'services' },
  { label: 'Funcionários', icon: UserCog, to: '/funcionarios', feature: 'employees' },
  { label: 'Estoque', icon: Package, to: '/estoque', feature: 'stock' },
  { label: 'Despesas', icon: Receipt, to: '/despesas', feature: 'expenses' },
  { label: 'Relatórios', icon: BarChart3, to: '/relatorios', feature: 'reports' },
  { label: 'Agendamentos', icon: CalendarDays, to: '/agendamentos', feature: 'appointments' },
  { label: 'Notificações', icon: Bell, to: '/notificacoes', feature: 'notifications' },
  { label: 'Ler QR Code', icon: QrCode, to: '/scanner', feature: 'newOrder' },
  { label: 'Configurações', icon: Settings, to: '/configuracoes' },
];

export default function More() {
  const navigate = useNavigate();
  const { profile, establishmentName, session, signOut } = useAuth();
  const { pending, problems } = useOutbox();

  const logout = async () => {
    const waiting = pending + problems;
    const msg = waiting > 0
      ? `Há ${waiting} operação(ões) ainda não enviadas ao servidor. Elas ficam guardadas neste aparelho e serão enviadas quando você entrar de novo com esta conta. Deseja sair?`
      : 'Deseja sair da sua conta?';
    if (window.confirm(msg)) await signOut();
  };

  return (
    <div className="animate-rise">
      <PageHeader title="Mais" />
      <div className="space-y-4 px-4 pb-4">
        <div className="card p-4">
          <div className="text-lg font-bold">{profile?.full_name}</div>
          <div className="text-sm text-mute">{session?.user.email}</div>
          <div className="mt-2 flex flex-wrap gap-2 text-xs">
            <span className="rounded-full bg-brand/20 px-3 py-1 font-semibold text-brand-light">{ROLE_LABEL[profile?.role ?? ''] ?? profile?.role}</span>
            <span className="rounded-full bg-panel px-3 py-1 text-mute">{establishmentName}</span>
          </div>
        </div>

        {pending + problems > 0 && (
          <button onClick={() => navigate('/pendencias')} className="card flex min-h-[56px] w-full items-center gap-3 border-warn/30 p-4 text-left">
            <CloudOff className="text-warn" size={22} />
            <span className="flex-1">
              <span className="block font-semibold">Operações pendentes de envio</span>
              <span className="block text-xs text-mute">{pending} aguardando · {problems} com problema</span>
            </span>
          </button>
        )}

        <div className="grid grid-cols-2 gap-3">
          {MODULES.filter((m) => !m.feature || can(profile?.role, m.feature)).map(({ label, icon: Icon, to }) => (
            <button
              key={label}
              onClick={() => navigate(to)}
              className="card flex min-h-[76px] items-center gap-3 p-4 text-left transition active:scale-[0.97]"
            >
              <Icon size={22} className="shrink-0 text-brand-light" />
              <span className="font-semibold">{label}</span>
            </button>
          ))}
        </div>

        <button className="btn-ghost w-full text-bad" onClick={() => void logout()}>
          <LogOut size={20} /> Sair da conta
        </button>
        <p className="text-center text-xs text-mute">LAVA PRO · versão 1.0.0</p>
      </div>
    </div>
  );
}
