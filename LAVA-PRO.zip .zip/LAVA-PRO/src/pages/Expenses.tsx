import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Loader2, Plus, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useLoad } from '../lib/useLoad';
import { errMsg, must } from '../lib/api';
import { EXPENSE_LABEL, PAY_LABEL, brl, fmtDateTime, monthStart, parseMoney } from '../lib/format';
import { Empty, ErrorBox, Field, Label, PageHeader, Sheet, Spinner, StaleBanner } from '../components/ui';

interface Exp {
  id: string;
  description: string;
  category: string;
  amount: number;
  created_at: string;
}

export default function Expenses() {
  const [params, setParams] = useSearchParams();
  const { profile } = useAuth();
  const list = useLoad<Exp[]>('expenses', async () =>
    (must(await supabase.from('expenses').select('id, description, category, amount, created_at').gte('created_at', monthStart().toISOString()).order('created_at', { ascending: false }).limit(300)) as any[]).map((e) => ({ ...e, amount: Number(e.amount) })),
  );
  const [open, setOpen] = useState(!!params.get('novo'));
  const total = (list.data ?? []).reduce((s, e) => s + e.amount, 0);

  const close = () => {
    setOpen(false);
    if (params.get('novo')) setParams({}, { replace: true });
  };
  const remove = async (id: string) => {
    if (!window.confirm('Excluir esta despesa?')) return;
    try {
      must(await supabase.from('expenses').delete().eq('id', id).select('id'));
      void list.reload();
    } catch (e) {
      window.alert(errMsg(e));
    }
  };

  return (
    <div className="animate-rise">
      <PageHeader
        title="Despesas"
        back
        right={
          <button onClick={() => setOpen(true)} aria-label="Nova despesa" className="flex h-12 w-12 items-center justify-center rounded-full bg-brand text-white">
            <Plus size={22} />
          </button>
        }
      />
      <div className="space-y-3 px-4 pb-4">
        <StaleBanner show={list.stale} />
        <div className="card p-4">
          <div className="text-sm text-mute">Total no mês</div>
          <div className="text-3xl font-extrabold text-bad">{brl(total)}</div>
        </div>
        {list.error && <ErrorBox message={list.error} onRetry={() => void list.reload()} />}
        {list.loading && <Spinner />}
        {!list.loading && (list.data ?? []).length === 0 && !list.error && <Empty>Nenhuma despesa neste mês.</Empty>}
        <ul className="space-y-2">
          {(list.data ?? []).map((e) => (
            <li key={e.id} className="card flex items-center justify-between gap-2 px-4 py-3">
              <span>
                <span className="block font-semibold">{e.description}</span>
                <span className="block text-xs text-mute">{EXPENSE_LABEL[e.category] ?? e.category} · {fmtDateTime(e.created_at)}</span>
              </span>
              <span className="flex items-center gap-1">
                <b>{brl(e.amount)}</b>
                <button aria-label="Excluir despesa" onClick={() => void remove(e.id)} className="flex h-12 w-12 items-center justify-center text-bad"><Trash2 size={18} /></button>
              </span>
            </li>
          ))}
        </ul>
      </div>
      {open && <ExpenseSheet establishmentId={profile!.establishment_id} onClose={close} onSaved={() => { close(); void list.reload(); }} />}
    </div>
  );
}

function ExpenseSheet({ establishmentId, onClose, onSaved }: { establishmentId: string; onClose: () => void; onSaved: () => void }) {
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('products');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('cash');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const save = async () => {
    if (busy) return;
    const v = parseMoney(amount);
    if (description.trim().length < 2) return setError('Descreva a despesa.');
    if (v <= 0) return setError('Informe um valor maior que zero.');
    setBusy(true);
    setError('');
    try {
      must(await supabase.from('expenses').insert({ description: description.trim(), category, method, amount: v, establishment_id: establishmentId }).select('id').single());
      onSaved();
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };

  return (
    <Sheet open title="Nova despesa" onClose={onClose}>
      <div className="space-y-4 pb-2">
        <Field label="Descrição *" value={description} onChange={setDescription} placeholder="Ex.: Shampoo automotivo" />
        <Field label="Valor (R$) *" value={amount} onChange={setAmount} inputMode="decimal" placeholder="0,00" />
        <div>
          <Label>Categoria</Label>
          <select className="field" value={category} onChange={(e) => setCategory(e.target.value)}>
            {Object.entries(EXPENSE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </div>
        <div>
          <Label>Pago com (dinheiro do caixa desconta do saldo esperado)</Label>
          <select className="field" value={method} onChange={(e) => setMethod(e.target.value)}>
            {Object.entries(PAY_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </div>
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void save()}>
          {busy && <Loader2 className="animate-spin" size={20} />} Salvar
        </button>
      </div>
    </Sheet>
  );
}
