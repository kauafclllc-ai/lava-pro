import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CloudOff, Loader2, LogOut, Printer } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { errMsg, must } from '../lib/api';
import { digits, formatPhone } from '../lib/format';
import { useOutbox } from '../lib/hooks';
import { Field, Label, Notice, PageHeader } from '../components/ui';

export default function Settings() {
  const navigate = useNavigate();
  const { profile, establishment, refresh, signOut } = useAuth();
  const { pending, problems } = useOutbox();
  const isAdmin = profile?.role === 'admin';

  const [name, setName] = useState(profile?.full_name ?? '');
  const [phone, setPhone] = useState(profile?.phone ? formatPhone(profile.phone) : '');
  const [pMsg, setPMsg] = useState<{ ok: boolean; t: string } | null>(null);
  const [pBusy, setPBusy] = useState(false);

  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [wMsg, setWMsg] = useState<{ ok: boolean; t: string } | null>(null);
  const [wBusy, setWBusy] = useState(false);

  const [eName, setEName] = useState(establishment?.name ?? '');
  const [ePhone, setEPhone] = useState(establishment?.phone ? formatPhone(establishment.phone) : '');
  const [eAddr, setEAddr] = useState(establishment?.address ?? '');
  const [eDoc, setEDoc] = useState(establishment?.document ?? '');
  const [eFoot, setEFoot] = useState(establishment?.footer ?? '');
  const [eMsg, setEMsg] = useState<{ ok: boolean; t: string } | null>(null);
  const [eBusy, setEBusy] = useState(false);

  const saveProfile = async () => {
    if (pBusy) return;
    setPBusy(true);
    setPMsg(null);
    try {
      must(await supabase.rpc('update_my_profile', { p_name: name, p_phone: digits(phone) }));
      await refresh();
      setPMsg({ ok: true, t: 'Perfil atualizado.' });
    } catch (e) {
      setPMsg({ ok: false, t: errMsg(e) });
    }
    setPBusy(false);
  };

  const savePassword = async () => {
    if (wBusy) return;
    if (pw.length < 8) return setWMsg({ ok: false, t: 'A senha deve ter pelo menos 8 caracteres.' });
    if (pw !== pw2) return setWMsg({ ok: false, t: 'As senhas não conferem.' });
    setWBusy(true);
    setWMsg(null);
    const { error } = await supabase.auth.updateUser({ password: pw });
    if (error) setWMsg({ ok: false, t: errMsg(error) });
    else {
      setPw('');
      setPw2('');
      setWMsg({ ok: true, t: 'Senha alterada.' });
    }
    setWBusy(false);
  };

  const saveEstablishment = async () => {
    if (eBusy || !establishment) return;
    if (eName.trim().length < 2) return setEMsg({ ok: false, t: 'Informe o nome do estabelecimento.' });
    setEBusy(true);
    setEMsg(null);
    try {
      must(
        await supabase
          .from('establishments')
          .update({ name: eName.trim(), phone: digits(ePhone) || null, address: eAddr.trim() || null, document: eDoc.trim() || null, receipt_footer: eFoot.trim() || null })
          .eq('id', establishment.id)
          .select('id')
          .single(),
      );
      await refresh();
      setEMsg({ ok: true, t: 'Dados do estabelecimento atualizados.' });
    } catch (e) {
      setEMsg({ ok: false, t: errMsg(e) });
    }
    setEBusy(false);
  };

  const logout = async () => {
    const w = pending + problems;
    if (window.confirm(w > 0 ? `Há ${w} operação(ões) ainda não enviadas. Elas ficam guardadas neste aparelho. Deseja sair?` : 'Deseja sair da sua conta?')) await signOut();
  };

  const msg = (m: { ok: boolean; t: string } | null) => m && <Notice tone={m.ok ? 'ok' : 'bad'}>{m.t}</Notice>;

  return (
    <div className="animate-rise">
      <PageHeader title="Configurações" back />
      <div className="space-y-4 px-4 pb-4">
        <div className="card space-y-3 p-4">
          <h2 className="font-semibold">Meu perfil</h2>
          <Field label="Nome" value={name} onChange={setName} />
          <Field label="Telefone" value={phone} onChange={(v) => setPhone(formatPhone(v))} inputMode="tel" />
          {msg(pMsg)}
          <button className="btn-primary w-full" disabled={pBusy} onClick={() => void saveProfile()}>
            {pBusy && <Loader2 className="animate-spin" size={20} />} Salvar perfil
          </button>
        </div>

        <div className="card space-y-3 p-4">
          <h2 className="font-semibold">Alterar senha</h2>
          <Field label="Nova senha" type="password" value={pw} onChange={setPw} />
          <Field label="Repita a nova senha" type="password" value={pw2} onChange={setPw2} />
          {msg(wMsg)}
          <button className="btn-ghost w-full" disabled={wBusy} onClick={() => void savePassword()}>
            {wBusy && <Loader2 className="animate-spin" size={20} />} Alterar senha
          </button>
        </div>

        {isAdmin && establishment && (
          <div className="card space-y-3 p-4">
            <h2 className="font-semibold">Estabelecimento</h2>
            <Field label="Nome" value={eName} onChange={setEName} />
            <Field label="Telefone" value={ePhone} onChange={(v) => setEPhone(formatPhone(v))} inputMode="tel" />
            <Field label="Endereço" value={eAddr} onChange={setEAddr} />
            <Field label="CNPJ/CPF" value={eDoc} onChange={setEDoc} />
            <div>
              <Label>Mensagem no rodapé do cupom</Label>
              <textarea className="field min-h-[80px]" value={eFoot} onChange={(e) => setEFoot(e.target.value)} maxLength={200} />
            </div>
            {msg(eMsg)}
            <button className="btn-primary w-full" disabled={eBusy} onClick={() => void saveEstablishment()}>
              {eBusy && <Loader2 className="animate-spin" size={20} />} Salvar estabelecimento
            </button>
          </div>
        )}

        <button className="card flex min-h-[56px] w-full items-center gap-3 p-4 text-left" onClick={() => navigate('/impressora')}>
          <Printer size={22} className="text-brand-light" /> <span className="font-semibold">Impressora e cupom</span>
        </button>
        <button className="card flex min-h-[56px] w-full items-center gap-3 p-4 text-left" onClick={() => navigate('/pendencias')}>
          <CloudOff size={22} className="text-brand-light" />
          <span className="font-semibold">Pendências de envio</span>
          {pending + problems > 0 && <span className="ml-auto rounded-full bg-warn/20 px-2 py-0.5 text-xs text-warn">{pending + problems}</span>}
        </button>
        <button className="btn-ghost w-full text-bad" onClick={() => void logout()}>
          <LogOut size={20} /> Sair da conta
        </button>
      </div>
    </div>
  );
}
