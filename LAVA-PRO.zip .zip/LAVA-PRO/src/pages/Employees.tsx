import { useState } from 'react';
import { Copy, Loader2, Plus, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useLoad } from '../lib/useLoad';
import { errMsg, must } from '../lib/api';
import { ROLE_LABEL, brl, digits, fmtDateTime, formatPhone, parseMoney } from '../lib/format';
import { Empty, ErrorBox, Field, Label, Notice, PageHeader, Sheet, Spinner } from '../components/ui';

interface Emp {
  id: string;
  full_name: string;
  role: string;
  phone: string | null;
  active: boolean;
  salary: number | null;
  commission_pct: number | null;
}
interface Invite {
  id: string;
  code: string;
  role: string;
  full_name: string;
  expires_at: string;
  used_at: string | null;
}

export default function Employees() {
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin';
  const list = useLoad<Emp[]>('employees', async () => must(await supabase.rpc('list_employees')) as Emp[]);
  const invites = useLoad<Invite[]>(null, async () =>
    must(await supabase.from('invites').select('id, code, role, full_name, expires_at, used_at').is('used_at', null).order('created_at', { ascending: false })) as Invite[],
  );
  const [edit, setEdit] = useState<Emp | null>(null);
  const [inviting, setInviting] = useState(false);

  const removeInvite = async (id: string) => {
    if (!window.confirm('Cancelar este convite?')) return;
    await supabase.from('invites').delete().eq('id', id);
    void invites.reload();
  };

  return (
    <div className="animate-rise">
      <PageHeader
        title="Funcionários"
        back
        right={
          <button onClick={() => setInviting(true)} aria-label="Convidar funcionário" className="flex h-12 w-12 items-center justify-center rounded-full bg-brand text-white">
            <Plus size={22} />
          </button>
        }
      />
      <div className="space-y-3 px-4 pb-4">
        {list.error && <ErrorBox message={list.error} onRetry={() => void list.reload()} />}
        {list.loading && <Spinner />}
        {!list.loading && (list.data ?? []).length === 0 && !list.error && <Empty>Nenhum funcionário.</Empty>}
        <ul className="space-y-2">
          {(list.data ?? []).map((e) => (
            <li key={e.id}>
              <button
                disabled={!isAdmin || e.id === profile?.id}
                onClick={() => setEdit(e)}
                className={`card flex min-h-[60px] w-full items-center justify-between px-4 py-3 text-left ${e.active ? '' : 'opacity-50'}`}
              >
                <span>
                  <span className="block font-semibold">{e.full_name}{e.id === profile?.id && ' (você)'}</span>
                  <span className="block text-xs text-mute">
                    {ROLE_LABEL[e.role] ?? e.role}{!e.active && ' · inativo'}
                    {isAdmin && e.commission_pct ? ` · comissão ${e.commission_pct}%` : ''}
                  </span>
                </span>
                {isAdmin && e.salary != null && <span className="text-sm text-mute">{brl(e.salary)}</span>}
              </button>
            </li>
          ))}
        </ul>
        {!isAdmin && <Notice>Somente o administrador altera dados de funcionários.</Notice>}

        {(invites.data ?? []).length > 0 && (
          <div>
            <h3 className="mb-2 mt-2 text-sm font-semibold text-mute">Convites pendentes</h3>
            <ul className="space-y-2">
              {(invites.data ?? []).map((i) => (
                <li key={i.id} className="card flex items-center justify-between gap-2 px-4 py-3">
                  <span>
                    <span className="block font-semibold">{i.full_name} · {ROLE_LABEL[i.role]}</span>
                    <span className="block text-xs text-mute">
                      Código <b className="tracking-widest text-brand-light">{i.code}</b> · expira {fmtDateTime(i.expires_at)}
                    </span>
                  </span>
                  <button aria-label="Cancelar convite" onClick={() => void removeInvite(i.id)} className="flex h-12 w-12 items-center justify-center text-bad">
                    <Trash2 size={20} />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
      {edit && <EditSheet emp={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); void list.reload(); }} />}
      {inviting && (
        <InviteSheet
          isAdmin={isAdmin}
          onClose={() => { setInviting(false); void invites.reload(); }}
        />
      )}
    </div>
  );
}

function EditSheet({ emp, onClose, onSaved }: { emp: Emp; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(emp.full_name);
  const [phone, setPhone] = useState(emp.phone ? formatPhone(emp.phone) : '');
  const [role, setRole] = useState(emp.role);
  const [salary, setSalary] = useState(emp.salary != null ? String(emp.salary).replace('.', ',') : '');
  const [comm, setComm] = useState(emp.commission_pct != null ? String(emp.commission_pct).replace('.', ',') : '0');
  const [active, setActive] = useState(emp.active);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const save = async () => {
    if (busy) return;
    const c = parseMoney(comm);
    if (name.trim().length < 2) return setError('Informe o nome.');
    if (c > 100) return setError('Comissão deve estar entre 0 e 100%.');
    setBusy(true);
    setError('');
    try {
      must(
        await supabase.rpc('update_employee', {
          p_id: emp.id,
          p: { full_name: name.trim(), phone: digits(phone), role, salary: salary.trim() ? parseMoney(salary) : '', commission_pct: c, active },
        }),
      );
      onSaved();
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };

  return (
    <Sheet open title="Editar funcionário" onClose={onClose}>
      <div className="space-y-4 pb-2">
        <Field label="Nome *" value={name} onChange={setName} />
        <Field label="Telefone" value={phone} onChange={(v) => setPhone(formatPhone(v))} inputMode="tel" />
        <div>
          <Label>Perfil</Label>
          <select className="field" value={role} onChange={(e) => setRole(e.target.value)}>
            {['manager', 'attendant', 'washer'].map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Salário (R$)" value={salary} onChange={setSalary} inputMode="decimal" />
          <Field label="Comissão (%)" value={comm} onChange={setComm} inputMode="decimal" />
        </div>
        <label className="flex min-h-[48px] items-center gap-3">
          <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} className="h-6 w-6 accent-[#7547F5]" />
          <span>Ativo (pode entrar no app)</span>
        </label>
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void save()}>
          {busy && <Loader2 className="animate-spin" size={20} />} Salvar
        </button>
      </div>
    </Sheet>
  );
}

function InviteSheet({ isAdmin, onClose }: { isAdmin: boolean; onClose: () => void }) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState(isAdmin ? 'attendant' : 'washer');
  const [salary, setSalary] = useState('');
  const [comm, setComm] = useState('0');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const roles = isAdmin ? ['manager', 'attendant', 'washer'] : ['attendant', 'washer'];

  const create = async () => {
    if (busy) return;
    if (name.trim().length < 2) return setError('Informe o nome do funcionário.');
    setBusy(true);
    setError('');
    try {
      const r = must(
        await supabase.rpc('create_invite', {
          p: { full_name: name.trim(), phone: digits(phone), role, salary: isAdmin && salary.trim() ? parseMoney(salary) : '', commission_pct: isAdmin ? parseMoney(comm) : 0 },
        }),
      ) as { code: string };
      setCode(r.code);
    } catch (e) {
      setError(errMsg(e));
    }
    setBusy(false);
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      /* sem área de transferência */
    }
  };

  if (code) {
    return (
      <Sheet open title="Convite criado" onClose={onClose}>
        <div className="space-y-4 pb-2 text-center">
          <p className="text-sm text-mute">Passe este código ao funcionário. Ele baixa o app, toca em “Tenho um código de convite”, cria a conta e informa o código. Vale por 7 dias e só pode ser usado uma vez.</p>
          <div className="card py-6 text-4xl font-extrabold tracking-[0.3em] text-brand-light">{code}</div>
          <button className="btn-ghost w-full" onClick={() => void copy()}><Copy size={18} /> Copiar código</button>
          <button className="btn-primary w-full" onClick={onClose}>Concluir</button>
        </div>
      </Sheet>
    );
  }

  return (
    <Sheet open title="Convidar funcionário" onClose={onClose}>
      <div className="space-y-4 pb-2">
        <Field label="Nome *" value={name} onChange={setName} />
        <Field label="Telefone" value={phone} onChange={(v) => setPhone(formatPhone(v))} inputMode="tel" />
        <div>
          <Label>Perfil</Label>
          <select className="field" value={role} onChange={(e) => setRole(e.target.value)}>
            {roles.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
          </select>
        </div>
        {isAdmin && (
          <div className="grid grid-cols-2 gap-3">
            <Field label="Salário (R$)" value={salary} onChange={setSalary} inputMode="decimal" />
            <Field label="Comissão (%)" value={comm} onChange={setComm} inputMode="decimal" />
          </div>
        )}
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void create()}>
          {busy && <Loader2 className="animate-spin" size={20} />} Gerar código de convite
        </button>
      </div>
    </Sheet>
  );
}
