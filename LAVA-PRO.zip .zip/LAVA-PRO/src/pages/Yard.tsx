import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Banknote, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { NEXT_STATUS, STATUS, displayPlate, elapsed, fmtTime, one, startOfToday, vibrate } from '../lib/format';
import { useNow, useOutbox } from '../lib/hooks';
import { useLoad } from '../lib/useLoad';
import { useAuth } from '../context/AuthContext';
import { submitStatus } from '../lib/outbox';
import { errMsg } from '../lib/api';
import type { OrderStatus } from '../lib/types';
import { ErrorBox, Notice, PageHeader, Spinner, StaleBanner, StatusChip } from '../components/ui';

interface Row {
  id: string;
  number: number;
  status: OrderStatus;
  created_at: string;
  plate: string;
  model: string;
  services: string;
  employee: string;
}

const FILTERS: { key: string; label: string }[] = [
  { key: 'all', label: 'No pátio' },
  { key: 'waiting', label: 'Aguardando' },
  { key: 'in_progress', label: 'Em execução' },
  { key: 'done', label: 'Concluídos' },
  { key: 'awaiting_payment', label: 'Pagamento' },
  { key: 'ready', label: 'Prontos' },
  { key: 'delivered', label: 'Entregues hoje' },
];

const SELECT =
  'id, number, status, created_at, vehicles(plate, model), employee:employee_id(full_name), order_items(name)';

export default function Yard() {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const filter = params.get('status') ?? 'all';
  const { profile } = useAuth();
  const { ops } = useOutbox();
  const [query, setQuery] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [actionError, setActionError] = useState('');
  const [queuedNote, setQueuedNote] = useState(false);
  const now = useNow();

  const res = useLoad<Row[]>('yard', async () => {
    const [open, delivered] = await Promise.all([
      supabase.from('orders').select(SELECT).not('status', 'in', '(delivered,cancelled)').order('created_at', { ascending: true }),
      supabase.from('orders').select(SELECT).eq('status', 'delivered').gte('delivered_at', startOfToday().toISOString()).order('delivered_at', { ascending: false }),
    ]);
    const err = open.error ?? delivered.error;
    if (err) throw err;
    const map = (o: any): Row => {
      const v = one<any>(o.vehicles);
      const e = one<any>(o.employee);
      return {
        id: o.id,
        number: o.number,
        status: o.status,
        created_at: o.created_at,
        plate: v?.plate ?? '',
        model: v?.model ?? '',
        services: (o.order_items ?? []).map((i: any) => i.name).join(', '),
        employee: e?.full_name ?? '',
      };
    };
    return [...(open.data ?? []).map(map), ...(delivered.data ?? []).map(map)];
  });
  const load = res.reload;
  const loading = res.loading;
  const error = actionError || res.error;

  // Mostra o status local das mudanças ainda não enviadas ao servidor
  const rows = useMemo(() => {
    const pend = new Map<string, OrderStatus>();
    for (const o of ops) if (o.kind === 'set_status' && o.state === 'pending') pend.set(o.payload.order_id, o.payload.to);
    return (res.data ?? []).map((r) => (pend.has(r.id) ? { ...r, status: pend.get(r.id)! } : r));
  }, [res.data, ops]);

  useEffect(() => {
    const t = setInterval(() => void load(), 30000);
    return () => clearInterval(t);
  }, [load]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: 0 };
    for (const r of rows) {
      c[r.status] = (c[r.status] ?? 0) + 1;
      if (r.status !== 'delivered') c.all += 1;
    }
    return c;
  }, [rows]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase().replace(/[^a-z0-9 ]/g, '');
    return rows.filter((r) => {
      if (filter === 'all' ? r.status === 'delivered' : r.status !== filter) return false;
      if (!q) return true;
      return `${r.plate} ${r.model} ${r.employee} ${r.services}`.toLowerCase().includes(q);
    });
  }, [rows, filter, query]);

  const advance = async (r: Row, to: OrderStatus) => {
    if (busyId) return;
    setBusyId(r.id);
    vibrate();
    setActionError('');
    try {
      const out = await submitStatus({ order_id: r.id, from: r.status, to }, `O.S. #${r.number} → ${STATUS[to].label}`);
      setQueuedNote(out.queued);
    } catch (e) {
      setActionError(errMsg(e));
    }
    await load();
    setBusyId(null);
  };

  return (
    <div className="animate-rise">
      <PageHeader title="Pátio" />
      <div className="space-y-3 px-4 pb-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-mute" size={18} />
          <input className="field pl-11" placeholder="Buscar placa, modelo ou funcionário" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>

        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setParams(f.key === 'all' ? {} : { status: f.key })}
              className={`flex min-h-[44px] shrink-0 items-center gap-2 rounded-full border px-4 text-sm font-semibold transition active:scale-95 ${
                filter === f.key ? 'border-brand-light bg-brand/20 text-brand-light' : 'border-white/10 bg-card text-mute'
              }`}
            >
              {f.label}
              <span className="rounded-full bg-black/30 px-2 py-0.5 text-xs">{counts[f.key] ?? 0}</span>
            </button>
          ))}
        </div>

        <StaleBanner show={res.stale} />
        {queuedNote && <Notice tone="warn">Sem conexão: a mudança ficou guardada neste aparelho e será enviada depois. Veja em Mais &gt; Pendências.</Notice>}
        {error && <ErrorBox message={error} onRetry={() => { setActionError(''); void load(); }} />}
        {loading && <Spinner label="Carregando pátio..." />}

        {!loading && visible.length === 0 && !error && (
          <div className="card p-6 text-center text-sm text-mute">Nenhum veículo nesta lista.</div>
        )}

        <ul className="space-y-3">
          {visible.map((r) => {
            const next = NEXT_STATUS[r.status];
            return (
              <li key={r.id} className="card flex overflow-hidden">
                <div className={`w-1.5 shrink-0 ${STATUS[r.status].dot}`} />
                <div className="min-w-0 flex-1 p-3.5">
                  <button className="block w-full text-left" onClick={() => navigate(`/os/${r.id}`)}>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-lg font-extrabold tracking-wider">{displayPlate(r.plate)}</span>
                      <StatusChip status={r.status} />
                    </div>
                    <div className="mt-0.5 truncate text-sm">{r.model}</div>
                    <div className="truncate text-xs text-mute">{r.services || 'Sem serviços'}</div>
                    <div className="mt-1.5 flex flex-wrap gap-x-3 text-xs text-mute">
                      <span>Entrada {fmtTime(r.created_at)}</span>
                      {r.status !== 'delivered' && <span>{elapsed(r.created_at, now)} no pátio</span>}
                      <span>{r.employee || 'Sem responsável'}</span>
                    </div>
                  </button>
                  {r.status === 'awaiting_payment' && (
                    <button className="btn-primary mt-3 w-full !min-h-[48px]" onClick={() => navigate(`/os/${r.id}`)}>
                      <Banknote size={18} /> Receber pagamento
                    </button>
                  )}
                  {next && r.status !== 'awaiting_payment' && (
                    <button className="btn-ghost mt-3 w-full !min-h-[48px]" disabled={busyId === r.id} onClick={() => void advance(r, next.to)}>
                      {next.label}
                    </button>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
