import { useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import QRCode from 'qrcode';
import { ArrowLeft, Banknote, Camera, Check, FileText, Loader2, MessageCircle, Printer, QrCode, Undo2, XCircle } from 'lucide-react';
import { publicBaseUrl, supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { NEXT_STATUS, PAY_LABEL, STATUS, VEHICLE_LABEL, brl, displayPlate, fmtDateTime, formatPhone, one, parseMoney, uuid, vibrate } from '../lib/format';
import type { OrderStatus, PayMethod, VehicleType } from '../lib/types';
import { useLoad } from '../lib/useLoad';
import { useOnline, useOutbox } from '../lib/hooks';
import { submitPayment, submitStatus } from '../lib/outbox';
import { errMsg, must } from '../lib/api';
import { can } from '../lib/perm';
import { buildEscPos } from '../lib/escpos';
import { receiptPdf } from '../lib/pdf';
import { saveAndShare } from '../lib/files';
import { bluetoothAvailable, loadPrinter, printBytes } from '../lib/printer';
import { uploadOrderPhotos } from '../lib/photos';
import type { ReceiptData } from '../lib/receipt';
import { ErrorBox, Notice, Sheet, Spinner, StaleBanner, StatusChip, Label, Field } from '../components/ui';

interface Order {
  id: string;
  number: number;
  status: OrderStatus;
  payment_status: 'pending' | 'paid';
  notes: string | null;
  subtotal: number;
  discount: number;
  total: number;
  public_token: string;
  created_at: string;
  plate: string;
  brand: string | null;
  model: string;
  color: string | null;
  vtype: VehicleType;
  customer: string;
  phone: string | null;
  employee: string | null;
  items: { id: string; name: string; quantity: number; unit_price: number; discount: number }[];
  payments: { id: string; method: PayMethod; amount: number; created_at: string; refunded_at: string | null }[];
}

const STATUS_LABEL = Object.fromEntries(Object.entries(STATUS).map(([k, v]) => [k, v.label])) as Record<string, string>;

export default function OrderDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { establishmentName, establishment, profile } = useAuth();
  const online = useOnline();
  const { ops } = useOutbox();
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [qr, setQr] = useState('');
  const [payOpen, setPayOpen] = useState(false);
  const [printOpen, setPrintOpen] = useState(!!(location.state as any)?.print);
  const [refund, setRefund] = useState<{ id: string; amount: number; method: PayMethod } | null>(null);
  const [method, setMethod] = useState<PayMethod>('pix');
  const [amount, setAmount] = useState('');
  const payClientId = useRef(uuid());

  const base = publicBaseUrl();
  const canRefund = can(profile?.role, 'refund');
  const canCancel = can(profile?.role, 'cancelOrder');
  const canPay = can(profile?.role, 'finance');

  const res = useLoad<Order | null>(
    id ? `order:${id}` : null,
    async () => {
      const { data, error: err } = await supabase
        .from('orders')
        .select(
          'id, number, status, payment_status, notes, subtotal, discount, total, public_token, created_at, ' +
            'vehicles(plate, brand, model, color, type), customers(name, phone), employee:employee_id(full_name), ' +
            'order_items(id, name, quantity, unit_price, discount), payments(id, method, amount, created_at, refunded_at)',
        )
        .eq('id', id!)
        .maybeSingle();
      if (err) throw err;
      if (!data) return null;
      const r = data as any;
      const v = one<any>(r.vehicles);
      const c = one<any>(r.customers);
      const e = one<any>(r.employee);
      return {
        id: r.id,
        number: r.number,
        status: r.status,
        payment_status: r.payment_status,
        notes: r.notes,
        subtotal: Number(r.subtotal),
        discount: Number(r.discount),
        total: Number(r.total),
        public_token: r.public_token,
        created_at: r.created_at,
        plate: v?.plate ?? '',
        brand: v?.brand ?? null,
        model: v?.model ?? '',
        color: v?.color ?? null,
        vtype: (v?.type ?? 'car') as VehicleType,
        customer: c?.name ?? '',
        phone: c?.phone ?? null,
        employee: e?.full_name ?? null,
        items: (r.order_items ?? []).map((i: any) => ({ ...i, unit_price: Number(i.unit_price), discount: Number(i.discount) })),
        payments: (r.payments ?? []).map((p: any) => ({ ...p, amount: Number(p.amount) })),
      } as Order;
    },
    [id],
  );
  const loading = res.loading;
  const load = res.reload;

  // Mudanças e pagamentos ainda não enviados ao servidor
  const pendingStatus = ops.find((o) => o.kind === 'set_status' && o.state === 'pending' && o.payload.order_id === id);
  const pendingPays = ops.filter((o) => o.kind === 'register_payment' && o.state === 'pending' && o.payload.order_id === id);
  const order = useMemo(() => {
    const o = res.data;
    return o && pendingStatus ? { ...o, status: pendingStatus.payload.to as OrderStatus } : o;
  }, [res.data, pendingStatus]);

  const photos = useLoad<{ id: string; path: string; url: string }[]>(
    null,
    async () => {
      const r = must(await supabase.from('order_photos').select('id, path').eq('order_id', id!).order('created_at')) as any[];
      if (r.length === 0) return [];
      const signed = await supabase.storage.from('order-photos').createSignedUrls(r.map((p) => p.path), 3600);
      const urls = new Map((signed.data ?? []).map((x: any) => [x.path, x.signedUrl]));
      return r.map((p) => ({ id: p.id, path: p.path, url: (urls.get(p.path) as string) ?? '' })).filter((p) => p.url);
    },
    [id],
  );

  useEffect(() => {
    if (res.error && online) void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [online]);

  const trackUrl = order && base ? `${base}/#/acompanhar/${order.public_token}` : '';

  useEffect(() => {
    if (!trackUrl) {
      setQr('');
      return;
    }
    QRCode.toDataURL(trackUrl, { margin: 1, width: 280, color: { dark: '#0B0D14', light: '#FFFFFF' } })
      .then(setQr)
      .catch(() => setQr(''));
  }, [trackUrl]);

  const paidServer = order ? order.payments.filter((p) => !p.refunded_at).reduce((s, p) => s + p.amount, 0) : 0;
  const paidQueued = pendingPays.reduce((s, o) => s + Number(o.payload.amount), 0);
  const paid = paidServer + paidQueued;
  const remaining = order ? Math.max(0, order.total - paid) : 0;

  const nextAction = (() => {
    if (!order) return null;
    if (order.status === 'done' && order.payment_status === 'paid') return { to: 'ready' as OrderStatus, label: 'Marcar pronto para entrega' };
    return NEXT_STATUS[order.status] ?? null;
  })();

  const advance = async (to: OrderStatus) => {
    if (!order || busy) return;
    setBusy(true);
    setError('');
    setNote('');
    vibrate();
    try {
      const from = res.data!.status;
      const out = await submitStatus({ order_id: order.id, from, to }, `O.S. #${order.number} → ${STATUS_LABEL[to]}`);
      if (out.queued) setNote('Sem conexão: a mudança ficou guardada neste aparelho e ainda NÃO foi confirmada pelo servidor.');
    } catch (e) {
      setError(errMsg(e));
    }
    await load();
    setBusy(false);
  };

  const cancelOrder = async () => {
    if (!order || busy) return;
    if (!window.confirm(`Cancelar a O.S. #${order.number}? Esta ação não pode ser desfeita.`)) return;
    setBusy(true);
    setError('');
    try {
      const { data, error: err } = await supabase.from('orders').update({ status: 'cancelled' }).eq('id', order.id).select('id');
      if (err) throw err;
      if (!data || data.length === 0) throw new Error('Não foi possível cancelar esta O.S.');
    } catch (e) {
      setError(errMsg(e));
    }
    await load();
    setBusy(false);
  };

  const openPay = () => {
    setAmount(remaining.toFixed(2).replace('.', ','));
    setMethod('pix');
    payClientId.current = uuid();
    setPayOpen(true);
  };

  const pay = async () => {
    if (!order || busy) return;
    const value = parseMoney(amount);
    if (value <= 0 || value > remaining + 0.009) {
      setError('Informe um valor maior que zero e não superior ao saldo.');
      return;
    }
    setBusy(true);
    setError('');
    setNote('');
    try {
      const out = await submitPayment({ order_id: order.id, method, amount: value, client_id: payClientId.current }, `Pagamento O.S. #${order.number} (${PAY_LABEL[method]})`);
      vibrate(30);
      setPayOpen(false);
      if (out.queued) setNote('Sem conexão: o pagamento ficou guardado neste aparelho e ainda NÃO foi confirmado pelo servidor.');
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
      return;
    }
    await load();
    setBusy(false);
  };

  const doRefund = async (reason: string) => {
    if (!refund) return;
    try {
      must(await supabase.rpc('refund_payment', { p_payment: refund.id, p_reason: reason }));
      setRefund(null);
      await load();
    } catch (e) {
      throw e;
    }
  };

  const addPhotos = async (files: FileList | null) => {
    if (!files || !order || !profile) return;
    setBusy(true);
    const failed = await uploadOrderPhotos(profile.establishment_id, order.id, Array.from(files).slice(0, 8));
    if (failed > 0) setError(`${failed} foto(s) não foram enviadas. Verifique a conexão.`);
    await photos.reload();
    setBusy(false);
  };

  const receipt = (): ReceiptData => ({
    est: { name: establishment?.name ?? establishmentName, phone: establishment?.phone, address: establishment?.address, document: establishment?.document, footer: establishment?.footer },
    number: order!.number,
    createdAt: order!.created_at,
    plate: displayPlate(order!.plate),
    model: [order!.brand, order!.model].filter(Boolean).join(' '),
    customer: order!.customer,
    employee: order!.employee,
    items: order!.items.map((i) => ({ name: i.name, qty: i.quantity, unit: i.unit_price, discount: i.discount, total: i.quantity * i.unit_price - i.discount })),
    subtotal: order!.subtotal,
    discount: order!.discount,
    total: order!.total,
    paid,
    url: trackUrl || undefined,
  });

  const shareWhatsApp = async () => {
    if (!order || !trackUrl) return;
    const text = `Olá! Acompanhe o serviço do seu veículo (${displayPlate(order.plate)}) no ${establishmentName}: ${trackUrl}`;
    try {
      if (navigator.share) {
        await navigator.share({ text });
        return;
      }
    } catch {
      return; // usuário cancelou
    }
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  if (loading && !order) return <Spinner label="Carregando O.S..." />;
  if (!order) {
    return (
      <div className="p-4">
        <ErrorBox message={error || res.error || 'Ordem de serviço não encontrada.'} onRetry={() => void load()} />
      </div>
    );
  }

  return (
    <div className="animate-rise">
      <header className="pt-safe sticky top-0 z-20 flex items-center gap-2 bg-ink/95 px-4 pb-3 backdrop-blur">
        <button onClick={() => navigate(-1)} aria-label="Voltar" className="flex h-12 w-12 items-center justify-center rounded-full bg-card">
          <ArrowLeft size={22} />
        </button>
        <div className="min-w-0 flex-1">
          <h1 className="text-lg font-bold leading-tight">O.S. #{order.number}</h1>
          <p className="text-xs text-mute">{fmtDateTime(order.created_at)}</p>
        </div>
        <StatusChip status={order.status} />
      </header>

      <div className="space-y-3 px-4 pb-4">
        <StaleBanner show={res.stale} />
        {note && <Notice tone="warn">{note}</Notice>}
        {(pendingStatus || pendingPays.length > 0) && <Notice tone="warn">Há alterações desta O.S. aguardando envio ao servidor (Mais &gt; Pendências).</Notice>}
        {error && <ErrorBox message={error} />}

        <div className="card p-4">
          <div className="text-2xl font-extrabold tracking-widest">{displayPlate(order.plate)}</div>
          <div className="text-sm text-mute">
            {[order.brand, order.model, order.color].filter(Boolean).join(' · ')} · {VEHICLE_LABEL[order.vtype]}
          </div>
          <div className="mt-3 text-sm">
            <span className="text-mute">Cliente: </span>
            {order.customer}
            {order.phone ? ` · ${formatPhone(order.phone)}` : ''}
          </div>
          <div className="text-sm">
            <span className="text-mute">Responsável: </span>
            {order.employee ?? 'não definido'}
          </div>
          {order.notes && (
            <div className="mt-1 text-sm">
              <span className="text-mute">Obs.: </span>
              {order.notes}
            </div>
          )}
        </div>

        <div className="card divide-y divide-white/5">
          {order.items.map((i) => (
            <div key={i.id} className="flex items-start justify-between gap-3 p-4">
              <div>
                <div className="font-semibold">{i.name}</div>
                <div className="text-xs text-mute">
                  {i.quantity} x {brl(i.unit_price)}
                  {i.discount > 0 ? ` · desconto ${brl(i.discount)}` : ''}
                </div>
              </div>
              <div className="font-bold">{brl(i.quantity * i.unit_price - i.discount)}</div>
            </div>
          ))}
          <div className="flex items-center justify-between p-4">
            <span className="text-mute">Total</span>
            <span className="text-xl font-extrabold">{brl(order.total)}</span>
          </div>
          <div className="flex items-center justify-between p-4 text-sm">
            <span className="text-mute">Pagamento</span>
            <span className={order.payment_status === 'paid' ? 'font-bold text-ok' : 'font-bold text-warn'}>
              {order.payment_status === 'paid' ? 'Pago' : `Pendente · saldo ${brl(remaining)}`}
            </span>
          </div>
        </div>

        {order.payments.length > 0 && (
          <div className="card divide-y divide-white/5">
            {order.payments.map((p) => (
              <div key={p.id} className="flex items-center justify-between px-4 py-3 text-sm">
                <span>
                  {PAY_LABEL[p.method]} <span className="text-mute">· {fmtDateTime(p.created_at)}{p.refunded_at && ' · ESTORNADO'}</span>
                </span>
                <span className="flex items-center gap-2">
                  <span className={`font-semibold ${p.refunded_at ? 'text-bad line-through' : ''}`}>{brl(p.amount)}</span>
                  {canRefund && !p.refunded_at && (
                    <button aria-label="Estornar" className="flex h-12 w-12 items-center justify-center text-mute" onClick={() => setRefund({ id: p.id, amount: p.amount, method: p.method })}>
                      <Undo2 size={18} />
                    </button>
                  )}
                </span>
              </div>
            ))}
          </div>
        )}

        <div className="grid gap-3">
          {nextAction && order.status !== 'awaiting_payment' && (
            <button className="btn-primary w-full" disabled={busy} onClick={() => void advance(nextAction.to)}>
              {busy ? <Loader2 className="animate-spin" size={20} /> : <Check size={20} />}
              {nextAction.label}
            </button>
          )}
          {canPay && remaining > 0.009 && order.status !== 'cancelled' && (
            <button className={order.status === 'awaiting_payment' ? 'btn-primary w-full' : 'btn-ghost w-full'} onClick={openPay}>
              <Banknote size={20} /> Registrar pagamento
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button className="btn-ghost" onClick={() => setPrintOpen(true)}>
            <Printer size={20} /> Cupom
          </button>
          {canCancel && order.status !== 'cancelled' && order.status !== 'delivered' && (
            <button className="btn-ghost text-bad" disabled={busy} onClick={() => void cancelOrder()}>
              <XCircle size={20} /> Cancelar O.S.
            </button>
          )}
        </div>

        <div className="card space-y-3 p-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold">Fotos</span>
            {(
              <label className={`btn-ghost !min-h-[44px] cursor-pointer ${!online ? 'pointer-events-none opacity-40' : ''}`}>
                <Camera size={18} /> Adicionar
                <input type="file" accept="image/*" capture="environment" multiple className="hidden" onChange={(e) => { void addPhotos(e.target.files); e.target.value = ''; }} />
              </label>
            )}
          </div>
          {photos.loading && <Spinner />}
          {!photos.loading && (photos.data ?? []).length === 0 && <p className="text-sm text-mute">{photos.error ? 'Fotos indisponíveis agora.' : 'Nenhuma foto.'}</p>}
          <div className="grid grid-cols-3 gap-2">
            {(photos.data ?? []).map((p) => (
              <a key={p.id} href={p.url} target="_blank" rel="noreferrer"><img src={p.url} alt="Foto do veículo" className="aspect-square w-full rounded-lg object-cover" /></a>
            ))}
          </div>
        </div>

        <div className="card p-4 text-center">
          <div className="mb-3 flex items-center justify-center gap-2 text-sm font-semibold">
            <QrCode size={18} className="text-brand-light" /> Acompanhamento do cliente
          </div>
          {qr ? (
            <>
              <img src={qr} alt="QR Code de acompanhamento" className="mx-auto h-48 w-48 rounded-xl bg-white p-2" />
              <button className="btn-ghost mt-4 w-full" onClick={() => void shareWhatsApp()}>
                <MessageCircle size={20} /> Compartilhar no WhatsApp
              </button>
            </>
          ) : (
            <p className="text-sm text-mute">
              Para gerar o QR Code, informe o endereço público do app em VITE_PUBLIC_BASE_URL (veja o LEIA-ME.md) e gere o app novamente.
            </p>
          )}
        </div>
      </div>

      <Sheet open={payOpen} title="Registrar pagamento" onClose={() => setPayOpen(false)}>
        <div className="space-y-4 pb-2">
          <div>
            <Label>Forma de pagamento</Label>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(PAY_LABEL) as PayMethod[]).map((m) => (
                <button
                  key={m}
                  onClick={() => setMethod(m)}
                  className={`min-h-[48px] rounded-xl border text-sm font-semibold ${
                    method === m ? 'border-brand-light bg-brand/20 text-brand-light' : 'border-white/10 bg-card text-mute'
                  }`}
                >
                  {PAY_LABEL[m]}
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label>Valor (R$) · saldo {brl(remaining)}</Label>
            <input className="field" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>
          <button className="btn-primary w-full" disabled={busy} onClick={() => void pay()}>
            {busy && <Loader2 className="animate-spin" size={20} />} Confirmar pagamento
          </button>
        </div>
      </Sheet>

      <Sheet open={printOpen} title="Cupom da O.S." onClose={() => setPrintOpen(false)}>
        <PrintPanel order={order} receipt={receipt} qr={qr} />
      </Sheet>

      {refund && <RefundDialog amount={refund.amount} onClose={() => setRefund(null)} onConfirm={doRefund} />}
    </div>
  );
}

function PrintPanel({ order, receipt, qr }: { order: Order; receipt: () => ReceiptData; qr: string }) {
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null);
  const [busy, setBusy] = useState('');
  const printer = loadPrinter();

  const thermal = async () => {
    setBusy('t');
    setMsg(null);
    try {
      await printBytes(buildEscPos(receipt(), printer.format === '80' ? 48 : 32));
      setMsg({ ok: true, t: 'Cupom enviado à impressora.' });
    } catch (e) {
      setMsg({ ok: false, t: `Falha ao imprimir: ${errMsg(e)}` });
    }
    setBusy('');
  };

  const pdf = async () => {
    setBusy('p');
    setMsg(null);
    try {
      const b64 = await receiptPdf(receipt(), printer.format, qr || undefined);
      await saveAndShare(`OS-${order.number}.pdf`, b64, 'application/pdf', `O.S. ${order.number}`);
      setMsg({ ok: true, t: 'PDF gerado.' });
    } catch (e) {
      setMsg({ ok: false, t: `Não foi possível gerar o PDF: ${errMsg(e)}` });
    }
    setBusy('');
  };

  return (
    <div className="space-y-3 pb-2">
      <p className="text-sm text-mute">Formato: {printer.format === 'A4' ? 'A4' : `térmica ${printer.format} mm`} (altere em Configurações &gt; Impressora).</p>
      {printer.format !== 'A4' && (
        <button className="btn-primary w-full" disabled={!!busy || !bluetoothAvailable() || !printer.deviceId} onClick={() => void thermal()}>
          {busy === 't' ? <Loader2 className="animate-spin" size={20} /> : <Printer size={20} />} Imprimir na térmica (Bluetooth)
        </button>
      )}
      {printer.format !== 'A4' && !printer.deviceId && <p className="text-xs text-warn">Nenhuma impressora Bluetooth configurada. Use o PDF ou configure em Configurações.</p>}
      <button className="btn-ghost w-full" disabled={!!busy} onClick={() => void pdf()}>
        {busy === 'p' ? <Loader2 className="animate-spin" size={20} /> : <FileText size={20} />} Gerar / compartilhar PDF
      </button>
      {msg && <Notice tone={msg.ok ? 'ok' : 'bad'}>{msg.t}</Notice>}
    </div>
  );
}

function RefundDialog({ amount, onClose, onConfirm }: { amount: number; onClose: () => void; onConfirm: (reason: string) => Promise<void> }) {
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const go = async () => {
    if (reason.trim().length < 3) return setError('Informe o motivo do estorno.');
    if (!window.confirm(`Estornar ${brl(amount)}? Esta ação fica registrada.`)) return;
    setBusy(true);
    setError('');
    try {
      await onConfirm(reason);
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };
  return (
    <Sheet open title="Estornar pagamento" onClose={onClose}>
      <div className="space-y-4 pb-2">
        <Field label="Motivo do estorno *" value={reason} onChange={setReason} />
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void go()}>
          {busy && <Loader2 className="animate-spin" size={20} />} Estornar {brl(amount)}
        </button>
      </div>
    </Sheet>
  );
}
