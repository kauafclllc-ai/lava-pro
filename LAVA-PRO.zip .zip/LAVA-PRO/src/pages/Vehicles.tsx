import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Loader2, Plus, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useLoad } from '../lib/useLoad';
import { errMsg, must } from '../lib/api';
import { VEHICLE_LABEL, displayPlate, isValidPlate, normalizePlate, one } from '../lib/format';
import type { VehicleType } from '../lib/types';
import { Empty, ErrorBox, Field, Label, PageHeader, Sheet, Spinner, StaleBanner } from '../components/ui';

interface Vehicle {
  id: string;
  plate: string;
  brand: string | null;
  model: string;
  color: string | null;
  type: VehicleType;
  customer_id: string | null;
  customer: string;
}

export default function Vehicles() {
  const [params, setParams] = useSearchParams();
  const { profile } = useAuth();
  const list = useLoad<Vehicle[]>('vehicles', async () => {
    const rows = must(
      await supabase.from('vehicles').select('id, plate, brand, model, color, type, customer_id, customers(name)').order('plate').limit(1000),
    ) as any[];
    return rows.map((r) => ({ ...r, customer: one<any>(r.customers)?.name ?? '' }));
  });
  const customers = useLoad<{ id: string; name: string }[]>('customers-min', async () =>
    must(await supabase.from('customers').select('id, name').order('name').limit(1000)) as any[],
  );
  const [q, setQ] = useState('');
  const [sheet, setSheet] = useState<Vehicle | 'new' | null>(params.get('novo') ? 'new' : null);

  const visible = useMemo(() => {
    const s = q.trim().toLowerCase().replace(/[^a-z0-9 ]/g, '');
    return (list.data ?? []).filter((v) => !s || `${v.plate} ${v.model} ${v.brand ?? ''} ${v.customer}`.toLowerCase().includes(s));
  }, [list.data, q]);

  const close = () => {
    setSheet(null);
    if (params.get('novo')) setParams({}, { replace: true });
  };

  return (
    <div className="animate-rise">
      <PageHeader
        title="Veículos"
        back
        right={
          <button onClick={() => setSheet('new')} aria-label="Novo veículo" className="flex h-12 w-12 items-center justify-center rounded-full bg-brand text-white">
            <Plus size={22} />
          </button>
        }
      />
      <div className="space-y-3 px-4 pb-4">
        <StaleBanner show={list.stale} />
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-mute" size={18} />
          <input className="field pl-11" placeholder="Buscar placa, modelo ou cliente" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        {list.error && <ErrorBox message={list.error} onRetry={() => void list.reload()} />}
        {list.loading && <Spinner />}
        {!list.loading && visible.length === 0 && !list.error && <Empty>Nenhum veículo encontrado.</Empty>}
        <ul className="space-y-2">
          {visible.map((v) => (
            <li key={v.id}>
              <button onClick={() => setSheet(v)} className="card flex min-h-[64px] w-full items-center justify-between px-4 py-3 text-left transition active:scale-[0.98]">
                <span>
                  <span className="block text-lg font-extrabold tracking-wider">{displayPlate(v.plate)}</span>
                  <span className="block text-sm text-mute">{[v.brand, v.model, v.color].filter(Boolean).join(' · ')}</span>
                </span>
                <span className="text-right text-xs text-mute">
                  {VEHICLE_LABEL[v.type]}
                  <span className="block">{v.customer || 'sem cliente'}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>
      {sheet && (
        <VehicleSheet
          vehicle={sheet === 'new' ? null : sheet}
          customers={customers.data ?? []}
          establishmentId={profile!.establishment_id}
          onClose={close}
          onSaved={() => {
            close();
            void list.reload();
          }}
        />
      )}
    </div>
  );
}

function VehicleSheet({
  vehicle,
  customers,
  establishmentId,
  onClose,
  onSaved,
}: {
  vehicle: Vehicle | null;
  customers: { id: string; name: string }[];
  establishmentId: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [plate, setPlate] = useState(vehicle?.plate ?? '');
  const [brand, setBrand] = useState(vehicle?.brand ?? '');
  const [model, setModel] = useState(vehicle?.model ?? '');
  const [color, setColor] = useState(vehicle?.color ?? '');
  const [type, setType] = useState<VehicleType>(vehicle?.type ?? 'car');
  const [customerId, setCustomerId] = useState(vehicle?.customer_id ?? '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const save = async () => {
    if (busy) return;
    if (!isValidPlate(plate)) return setError('Placa inválida. Use AAA-1234 ou AAA-1B23.');
    if (!model.trim()) return setError('Informe o modelo.');
    setBusy(true);
    setError('');
    try {
      const row = {
        plate: normalizePlate(plate),
        brand: brand.trim() || null,
        model: model.trim(),
        color: color.trim() || null,
        type,
        customer_id: customerId || null,
      };
      if (vehicle) must(await supabase.from('vehicles').update(row).eq('id', vehicle.id).select('id').single());
      else must(await supabase.from('vehicles').insert({ ...row, establishment_id: establishmentId }).select('id').single());
      onSaved();
    } catch (e) {
      const m = errMsg(e);
      setError(m.includes('já existe') ? 'Já existe um veículo com esta placa.' : m);
      setBusy(false);
    }
  };

  return (
    <Sheet open title={vehicle ? 'Veículo' : 'Novo veículo'} onClose={onClose}>
      <div className="space-y-4 pb-2">
        <div>
          <Label>Placa *</Label>
          <input
            className="field text-center text-2xl font-bold uppercase tracking-widest"
            value={displayPlate(plate)}
            onChange={(e) => setPlate(normalizePlate(e.target.value))}
            placeholder="ABC-1D23"
            maxLength={8}
            autoCapitalize="characters"
            autoComplete="off"
            spellCheck={false}
          />
        </div>
        <Field label="Modelo *" value={model} onChange={setModel} placeholder="Ex.: Onix" />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Marca" value={brand} onChange={setBrand} placeholder="Chevrolet" />
          <Field label="Cor" value={color} onChange={setColor} placeholder="Prata" />
        </div>
        <div>
          <Label>Tipo</Label>
          <div className="grid grid-cols-3 gap-2">
            {(Object.keys(VEHICLE_LABEL) as VehicleType[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setType(t)}
                className={`min-h-[48px] rounded-xl border text-sm font-semibold ${
                  type === t ? 'border-brand-light bg-brand/20 text-brand-light' : 'border-white/10 bg-card text-mute'
                }`}
              >
                {VEHICLE_LABEL[t]}
              </button>
            ))}
          </div>
        </div>
        <div>
          <Label>Cliente</Label>
          <select className="field" value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
            <option value="">Sem cliente</option>
            {customers.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void save()}>
          {busy && <Loader2 className="animate-spin" size={20} />} Salvar
        </button>
      </div>
    </Sheet>
  );
}
