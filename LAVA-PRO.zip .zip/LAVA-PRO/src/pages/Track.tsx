import { useCallback, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Check } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { STATUS, fmtDateTime } from '../lib/format';
import type { OrderStatus } from '../lib/types';
import { LogoMark, Spinner } from '../components/ui';

interface Info {
  number: number;
  status: OrderStatus;
  created_at: string;
  establishment: string;
  plate_hint: string;
  model: string;
  services: string[];
}

const FLOW: { key: OrderStatus[]; label: string }[] = [
  { key: ['waiting'], label: 'Recebido' },
  { key: ['in_progress'], label: 'Em execução' },
  { key: ['done', 'awaiting_payment'], label: 'Serviço concluído' },
  { key: ['ready'], label: 'Pronto para retirada' },
  { key: ['delivered'], label: 'Entregue' },
];

export default function Track() {
  const { token } = useParams();
  const [info, setInfo] = useState<Info | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    if (!token) return;
    const { data, error: err } = await supabase.rpc('public_order_status', { p_token: token });
    if (err) {
      setError('Não foi possível consultar agora. Tente novamente em instantes.');
    } else if (!data) {
      setError('Acompanhamento não encontrado.');
    } else {
      setError('');
      setInfo(data as Info);
    }
    setLoading(false);
  }, [token]);

  useEffect(() => {
    void load();
    const t = setInterval(() => void load(), 30000);
    return () => clearInterval(t);
  }, [load]);

  const current = info ? FLOW.findIndex((f) => f.key.includes(info.status)) : -1;

  return (
    <div className="pt-safe pb-safe mx-auto flex min-h-full max-w-md flex-col px-5">
      <div className="mb-6 mt-4 flex items-center gap-3">
        <LogoMark size={44} />
        <div>
          <div className="font-extrabold tracking-wide">LAVA PRO</div>
          <div className="text-xs text-mute">{info?.establishment ?? 'Acompanhamento do serviço'}</div>
        </div>
      </div>

      {loading && <Spinner label="Consultando..." />}
      {!loading && error && !info && <div className="card p-5 text-center text-sm text-mute">{error}</div>}

      {info && (
        <div className="animate-rise space-y-4">
          <div className="card p-5">
            <div className="text-xs text-mute">O.S. #{info.number}</div>
            <div className="text-xl font-extrabold">{info.model}</div>
            <div className="text-sm text-mute">Placa final {info.plate_hint}</div>
            <div className="mt-2 text-xs text-mute">Entrada em {fmtDateTime(info.created_at)}</div>
          </div>

          {info.status === 'cancelled' ? (
            <div className="card p-5 text-center font-semibold text-bad">{STATUS.cancelled.label}</div>
          ) : (
            <ol className="card space-y-4 p-5">
              {FLOW.map((f, i) => {
                const done = i < current;
                const active = i === current;
                return (
                  <li key={f.label} className="flex items-center gap-3">
                    <span
                      className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold ${
                        done ? 'bg-ok text-ink' : active ? 'text-white' : 'bg-panel text-mute'
                      }`}
                      style={active ? { backgroundImage: 'linear-gradient(135deg,#7547F5,#398BFF)' } : undefined}
                    >
                      {done ? <Check size={16} /> : i + 1}
                    </span>
                    <span className={active ? 'font-bold' : done ? 'text-txt' : 'text-mute'}>{f.label}</span>
                  </li>
                );
              })}
            </ol>
          )}

          {info.services.length > 0 && (
            <div className="card p-5">
              <div className="mb-2 text-xs text-mute">Serviços</div>
              <ul className="space-y-1 text-sm">
                {info.services.map((s, i) => (
                  <li key={i}>• {s}</li>
                ))}
              </ul>
            </div>
          )}
          <p className="text-center text-xs text-mute">Esta página atualiza sozinha a cada 30 segundos.</p>
        </div>
      )}
    </div>
  );
}
