import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, Receipt, Undo2, Wallet } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useLoad } from '../lib/useLoad';
import { errMsg, must } from '../lib/api';
import { can } from '../lib/perm';
import { PAY_LABEL, brl, displayPlate, fmtDateTime, fmtTime, one, parseMoney, startOfToday } from '../lib/format';
import type { PayMethod } from '../lib/types';
import { ErrorBox, Field, Notice, PageHeader, Sheet, Spinner, StaleBanner } from '../components/ui';

interface Pay {
  id: string;
  method: PayMethod;
  amount: number;
  created_at: string;
  order_id: string;
  number: number | null;
  plate: string;
  refunded_at: string | null;
  refund_reason: string | null;
}
interface Cash {
  open: boolean;
  id?: string;
  opened_at?: string;
  opening_amount?: number;
  cash_in?: number;
  cash_refunds?: number;
  cash_expenses?: number;
  expected?: number;
}

export default function Finance() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const canRefund = can(profile?.role, 'refund');
  const canExpenses = can(profile?.role, 'expenses');

  const pays = useLoad<Pay[]>('finance-pays', async () =>
    (must(
      await supabase
        .from('payments')
        .select('id, method, amount, created_at, order_id, refunded_at, refund_reason, orders(number, vehicles(plate))')
        .gte('created_at', startOfToday().toISOString())
        .order('created_at', { ascending: false }),
    ) as any[]).map((p) => {
      const o = one<any>(p.orders);
      const v = one<any>(o?.vehicles);
      return { id: p.id, method: p.method, amount: Number(p.amount), created_at: p.created_at, order_id: p.order_id, number: o?.number ?? null, plate: v?.plate ?? '', refunded_at: p.refunded_at, refund_reason: p.refund_reason };
    }),
  );
  const cash = useLoad<Cash>(null, async () => must(await supabase.rpc('cash_summary')) as Cash);
  const exp = useLoad<number>('finance-exp', async () =>
    (must(await supabase.from('expenses').select('amount').gte('created_at', startOfToday().toISOString())) as any[]).reduce((s, e) => s + Number(e.amount), 0),
  );

  const [sheet, setSheet] = useState<'open' | 'close' | Pay | null>(null);
  const reloadAll = () => { void pays.reload(); void cash.reload(); void exp.reload(); };

  const valid = (pays.data ?? []).filter((p) => !p.refunded_at);
  const total = valid.reduce((s, r) => s + r.amount, 0);
  const byMethod = useMemo(() => {
    const m = new Map<PayMethod, number>();
    for (const r of valid) m.set(r.method, (m.get(r.method) ?? 0) + r.amount);
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pays.data]);
  const c = cash.data;

  return (
    <div className="animate-rise">
      <PageHeader title="Financeiro" />
      <div className="space-y-4 px-4 pb-4">
        <StaleBanner show={pays.stale} />
        {pays.error && <ErrorBox message={pays.error} onRetry={reloadAll} />}
        {pays.loading && <Spinner label="Carregando recebimentos..." />}

        <div className="card space-y-3 p-4">
          <div className="flex items-center gap-2 font-semibold"><Wallet size={18} className="text-brand-light" /> Caixa</div>
          {cash.loading && <Spinner />}
          {cash.error && <Notice tone="warn">Caixa indisponível agora: {cash.error}</Notice>}
          {c && !c.open && (
            <>
              <p className="text-sm text-mute">Nenhum caixa aberto.</p>
              <button className="btn-primary w-full" onClick={() => setSheet('open')}>Abrir caixa</button>
            </>
          )}
          {c?.open && (
            <>
              <p className="text-xs text-mute">Aberto em {fmtDateTime(c.opened_at!)}</p>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <Mini label="Troco inicial" v={brl(c.opening_amount)} />
                <Mini label="Dinheiro recebido" v={brl(c.cash_in)} />
                <Mini label="Estornos (dinheiro)" v={brl(c.cash_refunds)} />
                <Mini label="Despesas (dinheiro)" v={brl(c.cash_expenses)} />
              </div>
              <div className="rounded-xl bg-panel px-4 py-3">
                <div className="text-xs text-mute">Saldo esperado em dinheiro</div>
                <div className="text-2xl font-extrabold">{brl(c.expected)}</div>
              </div>
              <button className="btn-ghost w-full" onClick={() => setSheet('close')}>Fechar caixa</button>
            </>
          )}
        </div>

        {!pays.loading && !pays.error && (
          <>
            <div className="card p-4">
              <div className="text-sm text-mute">Recebido hoje</div>
              <div className="text-3xl font-extrabold">{brl(total)}</div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                {byMethod.length === 0 && <span className="col-span-2 text-sm text-mute">Nenhum recebimento hoje.</span>}
                {byMethod.map(([m, v]) => <Mini key={m} label={PAY_LABEL[m]} v={brl(v)} />)}
              </div>
              {canExpenses && (
                <button className="mt-3 flex min-h-[48px] w-full items-center justify-between rounded-xl bg-panel px-4 text-left" onClick={() => navigate('/despesas')}>
                  <span className="flex items-center gap-2 text-sm"><Receipt size={16} /> Despesas hoje</span>
                  <b className="text-bad">{brl(exp.data ?? 0)}</b>
                </button>
              )}
            </div>

            <section>
              <h2 className="mb-2 text-sm font-semibold text-mute">Recebimentos de hoje</h2>
              <ul className="space-y-2">
                {(pays.data ?? []).map((r) => (
                  <li key={r.id}>
                    <button className={`card flex min-h-[60px] w-full items-center justify-between px-4 py-3 text-left ${r.refunded_at ? 'opacity-60' : ''}`} onClick={() => (canRefund && !r.refunded_at ? setSheet(r) : navigate(`/os/${r.order_id}`))}>
                      <div>
                        <div className="font-semibold">
                          {displayPlate(r.plate)} <span className="text-xs font-normal text-mute">O.S. #{r.number}</span>
                        </div>
                        <div className="text-xs text-mute">
                          {PAY_LABEL[r.method]} · {fmtTime(r.created_at)}{r.refunded_at && ` · ESTORNADO (${r.refund_reason})`}
                        </div>
                      </div>
                      <div className={`font-bold ${r.refunded_at ? 'text-bad line-through' : 'text-ok'}`}>{brl(r.amount)}</div>
                    </button>
                  </li>
                ))}
              </ul>
              {canRefund && <p className="mt-2 text-xs text-mute">Toque em um recebimento para estornar.</p>}
            </section>
          </>
        )}
      </div>

      {sheet === 'open' && <OpenSheet onClose={() => setSheet(null)} onDone={() => { setSheet(null); reloadAll(); }} />}
      {sheet === 'close' && c?.open && <CloseSheet expected={c.expected ?? 0} onClose={() => setSheet(null)} onDone={() => { setSheet(null); reloadAll(); }} />}
      {sheet && typeof sheet === 'object' && <RefundSheet pay={sheet} onOpenOrder={() => navigate(`/os/${sheet.order_id}`)} onClose={() => setSheet(null)} onDone={() => { setSheet(null); reloadAll(); }} />}
    </div>
  );
}

const Mini = ({ label, v }: { label: string; v: string }) => (
  <div className="rounded-xl bg-panel px-3 py-2">
    <div className="text-xs text-mute">{label}</div>
    <div className="font-bold">{v}</div>
  </div>
);

function OpenSheet({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [v, setV] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const go = async () => {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      must(await supabase.rpc('open_cash', { p_amount: parseMoney(v) }));
      onDone();
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };
  return (
    <Sheet open title="Abrir caixa" onClose={onClose}>
      <div className="space-y-4 pb-2">
        <Field label="Troco inicial em dinheiro (R$)" value={v} onChange={setV} inputMode="decimal" placeholder="0,00" />
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void go()}>{busy && <Loader2 className="animate-spin" size={20} />} Abrir caixa</button>
      </div>
    </Sheet>
  );
}

function CloseSheet({ expected, onClose, onDone }: { expected: number; onClose: () => void; onDone: () => void }) {
  const [v, setV] = useState('');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<{ expected: number; counted: number; difference: number } | null>(null);
  const diff = parseMoney(v) - expected;
  const go = async () => {
    if (busy) return;
    if (!v.trim()) return setError('Informe o valor contado no caixa.');
    setBusy(true);
    setError('');
    try {
      setResult(must(await supabase.rpc('close_cash', { p_counted: parseMoney(v), p_notes: notes })) as any);
    } catch (e) {
      setError(errMsg(e));
    }
    setBusy(false);
  };
  if (result) {
    return (
      <Sheet open title="Caixa fechado" onClose={onDone}>
        <div className="space-y-3 pb-2 text-center">
          <p>Esperado: <b>{brl(result.expected)}</b> · Contado: <b>{brl(result.counted)}</b></p>
          <Notice tone={Math.abs(result.difference) < 0.01 ? 'ok' : 'warn'}>
            {Math.abs(result.difference) < 0.01 ? 'Caixa conferido, sem diferença.' : `Diferença de ${brl(result.difference)} (${result.difference > 0 ? 'sobra' : 'falta'}).`}
          </Notice>
          <button className="btn-primary w-full" onClick={onDone}>Concluir</button>
        </div>
      </Sheet>
    );
  }
  return (
    <Sheet open title="Fechar caixa" onClose={onClose}>
      <div className="space-y-4 pb-2">
        <p className="text-sm text-mute">Saldo esperado em dinheiro: <b className="text-white">{brl(expected)}</b></p>
        <Field label="Valor contado no caixa (R$)" value={v} onChange={setV} inputMode="decimal" placeholder="0,00" />
        {v.trim() && <p className="text-sm text-mute">Diferença: <b className={Math.abs(diff) < 0.01 ? 'text-ok' : 'text-warn'}>{brl(diff)}</b></p>}
        <Field label="Observações" value={notes} onChange={setNotes} />
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void go()}>{busy && <Loader2 className="animate-spin" size={20} />} Fechar caixa</button>
      </div>
    </Sheet>
  );
}

function RefundSheet({ pay, onOpenOrder, onClose, onDone }: { pay: Pay; onOpenOrder: () => void; onClose: () => void; onDone: () => void }) {
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const go = async () => {
    if (busy) return;
    if (reason.trim().length < 3) return setError('Informe o motivo do estorno.');
    if (!window.confirm(`Estornar ${brl(pay.amount)} (${PAY_LABEL[pay.method]})? Esta ação fica registrada.`)) return;
    setBusy(true);
    setError('');
    try {
      must(await supabase.rpc('refund_payment', { p_payment: pay.id, p_reason: reason }));
      onDone();
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };
  return (
    <Sheet open title="Estornar pagamento" onClose={onClose}>
      <div className="space-y-4 pb-2">
        <p className="text-sm">O.S. #{pay.number} · {PAY_LABEL[pay.method]} · <b>{brl(pay.amount)}</b></p>
        <Field label="Motivo do estorno *" value={reason} onChange={setReason} />
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}
        <button className="btn-primary w-full" disabled={busy} onClick={() => void go()}>{busy ? <Loader2 className="animate-spin" size={20} /> : <Undo2 size={20} />} Estornar</button>
        <button className="btn-ghost w-full" onClick={onOpenOrder}>Abrir O.S.</button>
      </div>
    </Sheet>
  );
}
