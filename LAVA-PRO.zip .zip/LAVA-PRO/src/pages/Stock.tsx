import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AlertTriangle, Loader2, Plus, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useLoad } from '../lib/useLoad';
import { errMsg, must } from '../lib/api';
import { brl, fmtDateTime, parseMoney, uuid } from '../lib/format';
import { can } from '../lib/perm';
import { Chips, Empty, ErrorBox, Field, Label, Notice, PageHeader, Sheet, Spinner, StaleBanner } from '../components/ui';

interface Prod {
  id: string;
  name: string;
  unit: string;
  cost: number;
  supplier: string | null;
  min_qty: number;
  qty: number;
  active: boolean;
}
interface Mov {
  id: string;
  kind: string;
  qty: number;
  reason: string | null;
  created_at: string;
}
const KIND = { in: 'Entrada', out: 'Saída', adjust: 'Ajuste' } as const;

export default function Stock() {
  const [params, setParams] = useSearchParams();
  const { profile } = useAuth();
  const manage = can(profile?.role, 'stockManage');
  const list = useLoad<Prod[]>('products', async () =>
    (must(await supabase.from('products').select('id, name, unit, cost, supplier, min_qty, qty, active').order('name')) as any[]).map((p) => ({
      ...p, cost: Number(p.cost), min_qty: Number(p.min_qty), qty: Number(p.qty),
    })),
  );
  const [q, setQ] = useState('');
  const [low, setLow] = useState<'all' | 'low'>('all');
  const [sheet, setSheet] = useState<Prod | 'new' | null>(params.get('novo') && manage ? 'new' : null);

  const visible = useMemo(() => {
    const s = q.trim().toLowerCase();
    return (list.data ?? []).filter((p) => (!s || p.name.toLowerCase().includes(s)) && (low === 'all' || (p.active && p.qty <= p.min_qty)));
  }, [list.data, q, low]);

  const close = () => {
    setSheet(null);
    if (params.get('novo')) setParams({}, { replace: true });
  };

  return (
    <div className="animate-rise">
      <PageHeader
        title="Estoque"
        back
        right={manage && (
          <button onClick={() => setSheet('new')} aria-label="Novo produto" className="flex h-12 w-12 items-center justify-center rounded-full bg-brand text-white">
            <Plus size={22} />
          </button>
        )}
      />
      <div className="space-y-3 px-4 pb-4">
        <StaleBanner show={list.stale} />
        {!manage && <Notice>Somente gerente ou administrador movimenta o estoque.</Notice>}
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-mute" size={18} />
          <input className="field pl-11" placeholder="Buscar produto" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <Chips value={low} onChange={setLow} options={[{ key: 'all', label: 'Todos' }, { key: 'low', label: 'Estoque baixo' }]} />
        {list.error && <ErrorBox message={list.error} onRetry={() => void list.reload()} />}
        {list.loading && <Spinner />}
        {!list.loading && visible.length === 0 && !list.error && <Empty>Nenhum produto.</Empty>}
        <ul className="space-y-2">
          {visible.map((p) => {
            const isLow = p.active && p.qty <= p.min_qty;
            return (
              <li key={p.id}>
                <button onClick={() => setSheet(p)} className={`card flex min-h-[64px] w-full items-center justify-between px-4 py-3 text-left ${p.active ? '' : 'opacity-50'}`}>
                  <span>
                    <span className="block font-semibold">{p.name}</span>
                    <span className="block text-xs text-mute">mín. {p.min_qty} {p.unit}{p.cost > 0 && ` · custo ${brl(p.cost)}`}</span>
                  </span>
                  <span className={`flex items-center gap-1 text-lg font-bold ${isLow ? 'text-bad' : ''}`}>
                    {isLow && <AlertTriangle size={16} />} {p.qty} <span className="text-xs font-normal text-mute">{p.unit}</span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
      {sheet && <ProductSheet prod={sheet === 'new' ? null : sheet} manage={manage} establishmentId={profile!.establishment_id} onClose={close} onSaved={() => { void list.reload(); }} />}
    </div>
  );
}

function ProductSheet({ prod, manage, establishmentId, onClose, onSaved }: { prod: Prod | null; manage: boolean; establishmentId: string; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(prod?.name ?? '');
  const [unit, setUnit] = useState(prod?.unit ?? 'un');
  const [cost, setCost] = useState(prod ? String(prod.cost).replace('.', ',') : '');
  const [supplier, setSupplier] = useState(prod?.supplier ?? '');
  const [minQty, setMinQty] = useState(prod ? String(prod.min_qty).replace('.', ',') : '0');
  const [active, setActive] = useState(prod?.active ?? true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [ok, setOk] = useState('');
  const [kind, setKind] = useState<'in' | 'out' | 'adjust'>('in');
  const [qty, setQty] = useState('');
  const [reason, setReason] = useState('');
  const [movs, setMovs] = useState<Mov[] | null>(null);
  const [current, setCurrent] = useState(prod?.qty ?? 0);

  const loadMovs = async () => {
    if (!prod) return;
    const r = await supabase.from('stock_movements').select('id, kind, qty, reason, created_at').eq('product_id', prod.id).order('created_at', { ascending: false }).limit(15);
    setMovs(((r.data ?? []) as any[]).map((m) => ({ ...m, qty: Number(m.qty) })));
    const p = await supabase.from('products').select('qty').eq('id', prod.id).single();
    if (p.data) setCurrent(Number((p.data as any).qty));
  };
  useEffect(() => { void loadMovs(); /* eslint-disable-next-line */ }, []);

  const saveProduct = async () => {
    if (busy) return;
    if (name.trim().length < 2) return setError('Informe o nome do produto.');
    setBusy(true);
    setError('');
    try {
      const row = { name: name.trim(), unit: unit.trim() || 'un', cost: parseMoney(cost), supplier: supplier.trim() || null, min_qty: parseMoney(minQty), active };
      if (prod) must(await supabase.from('products').update(row).eq('id', prod.id).select('id').single());
      else must(await supabase.from('products').insert({ ...row, establishment_id: establishmentId }).select('id').single());
      onSaved();
      onClose();
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };

  const move = async () => {
    if (busy || !prod) return;
    const n = parseMoney(qty);
    if (kind !== 'adjust' && n <= 0) return setError('Informe uma quantidade maior que zero.');
    if (kind === 'adjust' && !qty.trim()) return setError('Informe a quantidade contada.');
    setBusy(true);
    setError('');
    setOk('');
    try {
      must(await supabase.rpc('stock_move', { p: { client_id: uuid(), product_id: prod.id, kind, qty: n, unit_cost: kind === 'in' && cost.trim() ? parseMoney(cost) : '', reason } }));
      setQty('');
      setReason('');
      setOk('Movimentação registrada.');
      await loadMovs();
      onSaved();
    } catch (e) {
      setError(errMsg(e));
    }
    setBusy(false);
  };

  return (
    <Sheet open title={prod ? prod.name : 'Novo produto'} onClose={onClose}>
      <div className="space-y-4 pb-2">
        {manage && (
          <>
            <Field label="Nome *" value={name} onChange={setName} />
            <div className="grid grid-cols-2 gap-3">
              <Field label="Unidade" value={unit} onChange={setUnit} placeholder="un, L, kg" />
              <Field label="Custo (R$)" value={cost} onChange={setCost} inputMode="decimal" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Estoque mínimo" value={minQty} onChange={setMinQty} inputMode="decimal" />
              <Field label="Fornecedor" value={supplier} onChange={setSupplier} />
            </div>
            <label className="flex min-h-[48px] items-center gap-3">
              <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} className="h-6 w-6 accent-[#7547F5]" />
              <span>Produto ativo</span>
            </label>
            <button className="btn-primary w-full" disabled={busy} onClick={() => void saveProduct()}>
              {busy && <Loader2 className="animate-spin" size={20} />} Salvar produto
            </button>
          </>
        )}

        {prod && manage && (
          <div className="card space-y-3 p-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Movimentar estoque</h3>
              <span className="text-sm text-mute">Atual: <b>{current} {prod.unit}</b></span>
            </div>
            <Chips value={kind} onChange={setKind} options={[{ key: 'in', label: 'Entrada' }, { key: 'out', label: 'Saída' }, { key: 'adjust', label: 'Ajuste (contagem)' }]} />
            <Field label={kind === 'adjust' ? 'Quantidade contada' : 'Quantidade'} value={qty} onChange={setQty} inputMode="decimal" />
            <Field label="Motivo (opcional)" value={reason} onChange={setReason} />
            <button className="btn-ghost w-full" disabled={busy} onClick={() => void move()}>Registrar</button>
          </div>
        )}
        {ok && <Notice tone="ok">{ok}</Notice>}
        {error && <p className="rounded-xl bg-bad/10 px-4 py-3 text-sm text-bad">{error}</p>}

        {prod && (
          <div>
            <Label>Últimas movimentações</Label>
            {movs === null && <Spinner />}
            {movs && movs.length === 0 && <p className="text-sm text-mute">Sem movimentações.</p>}
            <ul className="space-y-1.5">
              {(movs ?? []).map((m) => (
                <li key={m.id} className="flex justify-between text-sm">
                  <span>{KIND[m.kind as keyof typeof KIND] ?? m.kind}{m.reason ? ` · ${m.reason}` : ''}</span>
                  <span className="text-mute">{m.qty} · {fmtDateTime(m.created_at)}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </Sheet>
  );
}
