import { useState, type FormEvent } from 'react';
import { Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { errMsg } from '../lib/api';
import { Label, LogoMark } from '../components/ui';

export default function Onboarding() {
  const { refresh, signOut } = useAuth();
  const [mode, setMode] = useState<'create' | 'join'>('create');
  const [estName, setEstName] = useState('');
  const [fullName, setFullName] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setError('');
    setBusy(true);
    const { error: err } =
      mode === 'create'
        ? await supabase.rpc('create_establishment', { p_name: estName, p_full_name: fullName })
        : await supabase.rpc('join_establishment', { p_code: code });
    if (err) {
      setError(errMsg(err));
      setBusy(false);
      return;
    }
    await refresh();
    setBusy(false);
  };

  return (
    <div className="pt-safe pb-safe flex min-h-full flex-col justify-center bg-ink px-6">
      <div className="mx-auto w-full max-w-sm animate-rise">
        <div className="mb-6 flex flex-col items-center gap-3 text-center">
          <LogoMark size={56} />
          <h1 className="text-xl font-bold">{mode === 'create' ? 'Vamos configurar seu lava-jato' : 'Entrar na equipe'}</h1>
          <p className="text-sm text-mute">
            {mode === 'create'
              ? 'Você será o administrador. Depois poderá convidar a equipe.'
              : 'Digite o código de convite que o administrador enviou para você.'}
          </p>
        </div>

        <div className="mb-3 grid grid-cols-2 gap-2">
          {(['create', 'join'] as const).map((m) => (
            <button
              key={m}
              onClick={() => { setMode(m); setError(''); }}
              className={`min-h-[48px] rounded-xl border text-sm font-semibold ${
                mode === m ? 'border-brand-light bg-brand/20 text-brand-light' : 'border-white/10 bg-card text-mute'
              }`}
            >
              {m === 'create' ? 'Criar meu lava-jato' : 'Tenho um convite'}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="card space-y-4 p-5">
          {mode === 'create' ? (
            <>
              <div>
                <Label>Nome do estabelecimento</Label>
                <input className="field" value={estName} onChange={(e) => setEstName(e.target.value)} placeholder="Ex.: Lava Rápido Central" required minLength={2} />
              </div>
              <div>
                <Label>Seu nome</Label>
                <input className="field" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Ex.: Pedro Silva" autoComplete="name" required minLength={2} />
              </div>
            </>
          ) : (
            <div>
              <Label>Código de convite</Label>
              <input
                className="field text-center text-xl font-bold uppercase tracking-widest"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase().replace(/\s/g, ''))}
                placeholder="A1B2C3D4"
                autoCapitalize="characters"
                maxLength={12}
                required
              />
            </div>
          )}
          {error && <p className="rounded-lg bg-bad/10 px-3 py-2 text-sm text-bad">{error}</p>}
          <button className="btn-primary w-full" disabled={busy} type="submit">
            {busy && <Loader2 className="animate-spin" size={20} />}
            {mode === 'create' ? 'Começar' : 'Entrar na equipe'}
          </button>
        </form>
        <button className="mx-auto mt-4 block min-h-[48px] px-4 text-sm text-mute" onClick={() => void signOut()}>
          Sair da conta
        </button>
      </div>
    </div>
  );
}
