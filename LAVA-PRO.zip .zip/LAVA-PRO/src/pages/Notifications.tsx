import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useLoad } from '../lib/useLoad';
import { must } from '../lib/api';
import { fmtDateTime } from '../lib/format';
import { Empty, ErrorBox, PageHeader, Spinner } from '../components/ui';

interface N {
  id: string;
  kind: string;
  title: string;
  body: string | null;
  ref_id: string | null;
  read_by: string[];
  created_at: string;
}

export default function Notifications() {
  const navigate = useNavigate();
  const { session } = useAuth();
  const uid = session?.user.id ?? '';
  const list = useLoad<N[]>('notifications', async () =>
    must(await supabase.from('notifications').select('id, kind, title, body, ref_id, read_by, created_at').order('created_at', { ascending: false }).limit(50)) as N[],
  );
  const unread = (list.data ?? []).filter((n) => !n.read_by.includes(uid)).length;

  useEffect(() => {
    if (unread > 0) void supabase.rpc('mark_notifications_read');
  }, [unread]);

  const open = (n: N) => {
    if (n.kind === 'awaiting_payment' && n.ref_id) navigate(`/os/${n.ref_id}`);
  };

  return (
    <div className="animate-rise">
      <PageHeader title="Notificações" back />
      <div className="space-y-2 px-4 pb-4">
        {list.error && <ErrorBox message={list.error} onRetry={() => void list.reload()} />}
        {list.loading && <Spinner />}
        {!list.loading && (list.data ?? []).length === 0 && !list.error && <Empty>Nenhuma notificação.</Empty>}
        {(list.data ?? []).map((n) => (
          <button key={n.id} onClick={() => open(n)} className="card block min-h-[56px] w-full px-4 py-3 text-left">
            <div className="flex items-center justify-between gap-2">
              <span className="font-semibold">{n.title}</span>
              {!n.read_by.includes(uid) && <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-brand-light" aria-label="não lida" />}
            </div>
            {n.body && <p className="text-sm text-mute">{n.body}</p>}
            <p className="mt-1 text-xs text-mute">{fmtDateTime(n.created_at)}</p>
          </button>
        ))}
      </div>
    </div>
  );
}
