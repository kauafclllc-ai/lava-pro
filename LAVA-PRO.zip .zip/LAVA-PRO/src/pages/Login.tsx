import { useState, type FormEvent } from 'react';
import { Eye, EyeOff, KeyRound, Loader2, Lock, Mail } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useOnline } from '../lib/hooks';
import { LogoMark, Label } from '../components/ui';

type Mode = 'login' | 'signup' | 'reset' | 'code';

function friendly(msg: string): string {
  const m = msg.toLowerCase();
  if (m.includes('invalid login credentials')) return 'E-mail ou senha incorretos.';
  if (m.includes('email not confirmed')) return 'Confirme seu e-mail antes de entrar. Verifique sua caixa de entrada.';
  if (m.includes('already registered')) return 'Este e-mail já possui cadastro. Use "Entrar".';
  if (m.includes('password should be')) return 'A senha precisa ter pelo menos 6 caracteres.';
  if (m.includes('failed to fetch') || m.includes('network')) return 'Sem conexão com o servidor. Verifique sua internet.';
  if (m.includes('rate limit')) return 'Muitas tentativas. Aguarde alguns minutos.';
  if (m.includes('token has expired') || m.includes('invalid') && m.includes('otp')) return 'Código inválido ou expirado. Peça um novo.';
  return msg;
}

export default function Login() {
  const online = useOnline();
  const [mode, setMode] = useState<Mode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setError('');
    setInfo('');
    if (!online) {
      setError('Sem internet. Conecte-se para entrar.');
      return;
    }
    setBusy(true);
    try {
      if (mode === 'login') {
        const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (err) throw err;
      } else if (mode === 'signup') {
        if (password.length < 6) throw new Error('Password should be at least 6 characters');
        const { data, error: err } = await supabase.auth.signUp({ email: email.trim(), password });
        if (err) throw err;
        if (!data.session) {
          setInfo('Conta criada. Enviamos um e-mail de confirmação. Confirme e depois entre.');
          setMode('login');
        }
      } else if (mode === 'reset') {
        const { error: err } = await supabase.auth.resetPasswordForEmail(email.trim());
        if (err) throw err;
        setInfo('Se o e-mail estiver cadastrado, você receberá um código. Digite-o abaixo com a nova senha.');
        setMode('code');
      } else {
        if (password.length < 6) throw new Error('Password should be at least 6 characters');
        const { error: vErr } = await supabase.auth.verifyOtp({ email: email.trim(), token: code.trim(), type: 'recovery' });
        if (vErr) throw vErr;
        const { error: uErr } = await supabase.auth.updateUser({ password });
        if (uErr) throw uErr;
        setInfo('Senha alterada.');
      }
    } catch (err: any) {
      setError(friendly(String(err?.message ?? err)));
    } finally {
      setBusy(false);
    }
  };

  const title = { login: 'Entrar', signup: 'Criar conta', reset: 'Recuperar senha', code: 'Definir nova senha' }[mode];

  return (
    <div className="pt-safe pb-safe flex min-h-full flex-col justify-center bg-ink px-6">
      <div className="mx-auto w-full max-w-sm animate-rise">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <LogoMark size={64} />
          <div>
            <h1 className="text-2xl font-extrabold tracking-wide">LAVA PRO</h1>
            <p className="text-sm text-mute">Gestão completa para o seu lava-jato</p>
          </div>
        </div>

        <form onSubmit={submit} className="card space-y-4 p-5">
          <h2 className="text-lg font-bold">{title}</h2>

          <div>
            <Label>E-mail</Label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-mute" size={18} />
              <input
                className="field pl-11"
                type="email"
                inputMode="email"
                autoComplete="email"
                placeholder="voce@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          {mode === 'code' && (
            <div>
              <Label>Código recebido por e-mail</Label>
              <div className="relative">
                <KeyRound className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-mute" size={18} />
                <input
                  className="field pl-11 tracking-widest"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  placeholder="000000"
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\s/g, ''))}
                  required
                />
              </div>
            </div>
          )}

          {mode !== 'reset' && (
            <div>
              <Label>{mode === 'code' ? 'Nova senha' : 'Senha'}</Label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-mute" size={18} />
                <input
                  className="field pl-11 pr-12"
                  type={show ? 'text' : 'password'}
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  placeholder="Mínimo de 6 caracteres"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShow((s) => !s)}
                  aria-label={show ? 'Ocultar senha' : 'Mostrar senha'}
                  className="absolute right-1 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center text-mute"
                >
                  {show ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>
          )}

          {error && <p className="rounded-lg bg-bad/10 px-3 py-2 text-sm text-bad">{error}</p>}
          {info && <p className="rounded-lg bg-ok/10 px-3 py-2 text-sm text-ok">{info}</p>}

          <button className="btn-primary w-full" disabled={busy} type="submit">
            {busy && <Loader2 className="animate-spin" size={20} />}
            {mode === 'reset' ? 'Enviar código' : title}
          </button>
        </form>

        <div className="mt-4 flex flex-col items-center gap-1 text-sm">
          {mode === 'login' && (
            <>
              <button className="min-h-[48px] px-4 font-semibold text-brand-light" onClick={() => { setMode('signup'); setError(''); setInfo(''); }}>
                Criar uma conta
              </button>
              <button className="min-h-[44px] px-4 text-mute" onClick={() => { setMode('reset'); setError(''); setInfo(''); }}>
                Esqueci minha senha
              </button>
            </>
          )}
          {mode === 'code' && (
            <button className="min-h-[44px] px-4 text-mute" onClick={() => { setMode('reset'); setError(''); setInfo(''); }}>
              Reenviar código
            </button>
          )}
          {mode !== 'login' && (
            <button className="min-h-[48px] px-4 font-semibold text-brand-light" onClick={() => { setMode('login'); setError(''); setInfo(''); }}>
              Voltar para entrar
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
