import type { OrderStatus, PayMethod, VehicleType } from './types';

export const brl = (n: number | string | null | undefined): string =>
  new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(n) || 0);

// Aceita "12,50" ou "12.50"
export const parseMoney = (s: string): number => {
  const n = Number(String(s).trim().replace(',', '.'));
  return Number.isFinite(n) && n >= 0 ? n : 0;
};

// O PostgREST devolve relações N:1 como objeto, mas por segurança aceitamos lista.
export const one = <T>(x: T | T[] | null | undefined): T | null => (Array.isArray(x) ? (x[0] ?? null) : (x ?? null));

export const startOfToday = (): Date => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
};

export const daysAgoStart = (days: number): Date => {
  const d = startOfToday();
  d.setDate(d.getDate() - days);
  return d;
};

export const fmtTime = (iso: string): string =>
  new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

export const fmtDateTime = (iso: string): string =>
  new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

export const elapsed = (iso: string, now: number): string => {
  const mins = Math.max(0, Math.floor((now - new Date(iso).getTime()) / 60000));
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}h ${String(m).padStart(2, '0')}min`;
};

export function uuid(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

export function vibrate(ms = 12): void {
  try {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate(ms);
  } catch {
    /* sem vibração disponível */
  }
}

// ----- Placa (modelo antigo AAA1234 ou Mercosul AAA1B23) -----
export const normalizePlate = (s: string): string => s.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 7);
export const isValidPlate = (s: string): boolean => /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(normalizePlate(s));
export const displayPlate = (s: string): string => {
  const p = normalizePlate(s);
  return p.length > 3 ? `${p.slice(0, 3)}-${p.slice(3)}` : p;
};

export const formatPhone = (s: string): string => {
  const d = s.replace(/\D/g, '').slice(0, 11);
  if (d.length <= 2) return d;
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
};

export const STATUS: Record<OrderStatus, { label: string; chip: string; dot: string }> = {
  waiting: { label: 'Aguardando', chip: 'bg-slate-400/15 text-slate-300 border-slate-400/30', dot: 'bg-slate-400' },
  in_progress: { label: 'Em execução', chip: 'bg-tech/15 text-tech border-tech/30', dot: 'bg-tech' },
  done: { label: 'Concluído', chip: 'bg-ok/15 text-ok border-ok/30', dot: 'bg-ok' },
  awaiting_payment: { label: 'Aguardando pagamento', chip: 'bg-warn/15 text-warn border-warn/30', dot: 'bg-warn' },
  ready: { label: 'Pronto para entrega', chip: 'bg-brand/20 text-brand-light border-brand/40', dot: 'bg-brand-light' },
  delivered: { label: 'Entregue', chip: 'bg-white/5 text-mute border-white/10', dot: 'bg-mute' },
  cancelled: { label: 'Cancelada', chip: 'bg-bad/15 text-bad border-bad/30', dot: 'bg-bad' },
};

export const NEXT_STATUS: Partial<Record<OrderStatus, { to: OrderStatus; label: string }>> = {
  waiting: { to: 'in_progress', label: 'Iniciar' },
  in_progress: { to: 'done', label: 'Concluir' },
  done: { to: 'awaiting_payment', label: 'Enviar para pagamento' },
  ready: { to: 'delivered', label: 'Entregar' },
};

export const PAY_LABEL: Record<PayMethod, string> = {
  cash: 'Dinheiro',
  pix: 'PIX',
  credit: 'Crédito',
  debit: 'Débito',
  other: 'Outro',
};

export const VEHICLE_LABEL: Record<VehicleType, string> = {
  car: 'Carro',
  suv: 'SUV',
  pickup: 'Picape',
  motorcycle: 'Moto',
  van: 'Van',
  other: 'Outro',
};

export const ROLE_LABEL: Record<string, string> = {
  admin: 'Administrador',
  manager: 'Gerente',
  attendant: 'Atendente',
  washer: 'Lavador',
};

export const EXPENSE_LABEL: Record<string, string> = {
  products: 'Produtos',
  employees: 'Funcionários',
  water: 'Água',
  energy: 'Energia',
  rent: 'Aluguel',
  maintenance: 'Manutenção',
  equipment: 'Equipamentos',
  other: 'Outros',
};

export const monthStart = (): Date => {
  const d = startOfToday();
  d.setDate(1);
  return d;
};

export const digits = (s: string): string => s.replace(/\D/g, '');

export const toLocalInput = (d: Date): string => {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};
