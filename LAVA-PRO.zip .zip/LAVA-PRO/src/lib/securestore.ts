// Armazenamento local criptografado (AES-GCM 256) em IndexedDB.
// A chave é "não extraível" (o JavaScript não consegue exportá-la) e fica no armazenamento
// privado do app. Isso protege os dados contra leitura casual do arquivo; não é um cofre de
// hardware. Se o ambiente não suportar, cai para memória (nada é gravado em texto puro).

const DB_NAME = 'lavapro-secure';
const KV = 'kv';
const META = 'meta';

let dbPromise: Promise<IDBDatabase> | null = null;
let keyPromise: Promise<CryptoKey | null> | null = null;
const memory = new Map<string, string>();

function openDb(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const r = indexedDB.open(DB_NAME, 1);
      r.onupgradeneeded = () => {
        r.result.createObjectStore(KV);
        r.result.createObjectStore(META);
      };
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  return dbPromise;
}

function wrap<T>(r: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

async function getKey(): Promise<CryptoKey | null> {
  if (!keyPromise) {
    keyPromise = (async () => {
      try {
        if (typeof indexedDB === 'undefined' || !globalThis.crypto?.subtle) return null;
        const db = await openDb();
        let key = (await wrap(db.transaction(META, 'readonly').objectStore(META).get('k'))) as CryptoKey | undefined;
        if (!key) {
          key = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
          await wrap(db.transaction(META, 'readwrite').objectStore(META).put(key, 'k'));
        }
        return key;
      } catch {
        return null;
      }
    })();
  }
  return keyPromise;
}

export async function secureSet(key: string, value: unknown): Promise<void> {
  const json = JSON.stringify(value);
  const k = await getKey();
  if (!k) {
    memory.set(key, json);
    return;
  }
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const data = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, k, new TextEncoder().encode(json));
  const db = await openDb();
  await wrap(db.transaction(KV, 'readwrite').objectStore(KV).put({ iv, data }, key));
}

export async function secureGet<T>(key: string): Promise<T | undefined> {
  const k = await getKey();
  try {
    if (!k) {
      const m = memory.get(key);
      return m === undefined ? undefined : (JSON.parse(m) as T);
    }
    const db = await openDb();
    const rec = (await wrap(db.transaction(KV, 'readonly').objectStore(KV).get(key))) as { iv: Uint8Array; data: ArrayBuffer } | undefined;
    if (!rec) return undefined;
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: rec.iv }, k, rec.data);
    return JSON.parse(new TextDecoder().decode(plain)) as T;
  } catch {
    return undefined;
  }
}

export async function secureDelete(key: string): Promise<void> {
  const k = await getKey();
  if (!k) {
    memory.delete(key);
    return;
  }
  const db = await openDb();
  await wrap(db.transaction(KV, 'readwrite').objectStore(KV).delete(key));
}

export async function secureDeletePrefix(prefix: string): Promise<void> {
  const k = await getKey();
  if (!k) {
    for (const key of [...memory.keys()]) if (key.startsWith(prefix)) memory.delete(key);
    return;
  }
  const db = await openDb();
  const keys = (await wrap(db.transaction(KV, 'readonly').objectStore(KV).getAllKeys())) as string[];
  const store = db.transaction(KV, 'readwrite').objectStore(KV);
  for (const key of keys) if (String(key).startsWith(prefix)) store.delete(key);
}
