export function isNetworkError(e: unknown): boolean {
  const m = String((e as any)?.message ?? e ?? '').toLowerCase();
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return true;
  return /failed to fetch|networkerror|network request failed|load failed|fetch failed|timeout|err_internet|err_network/.test(m);
}

// Lança o erro do PostgREST para que quem chama trate em try/catch
export function must<T>(res: { data: T | null; error: any }): T {
  if (res.error) throw res.error;
  return res.data as T;
}

export function errMsg(e: unknown): string {
  if (isNetworkError(e)) return 'Sem conexão com o servidor. Verifique a internet.';
  const m = String((e as any)?.message ?? e ?? 'Erro desconhecido');
  const l = m.toLowerCase();
  if (l.includes('row-level security') || l.includes('permission denied')) return 'Seu perfil não tem permissão para esta ação.';
  if (l.includes('duplicate key')) return 'Este registro já existe.';
  if (l.includes('violates check constraint')) return 'Algum valor informado é inválido.';
  if (l.includes('violates foreign key')) return 'Este item está em uso e não pode ser alterado ou removido.';
  if (l.includes('could not find the function') || l.includes('schema cache')) {
    return 'O banco de dados ainda não está atualizado. Execute a migração 002_fase2.sql no Supabase.';
  }
  return m;
}
