import { brl, PAY_LABEL } from './format';
import { saveAndShare } from './files';

export interface Report {
  orders: number;
  billed: number;
  received: number;
  expenses: number;
  pending: number;
  by_method: { method: string; amount: number }[];
  top_services: { name: string; qty: number; amount: number }[];
  employees: { id: string; name: string; orders: number; billed: number; commission_pct: number; commission: number }[];
  products: { name: string; unit: string; qty: number }[];
}

const num = (n: unknown) => Number(n) || 0;
const stamp = () => new Date().toISOString().slice(0, 10);

function rows(r: Report, est: string, period: string): (string | number)[][] {
  const ticket = r.orders > 0 ? num(r.billed) / r.orders : 0;
  const out: (string | number)[][] = [
    [`Relatório — ${est}`],
    [`Período: ${period}`],
    [],
    ['Resumo'],
    ['Veículos atendidos', r.orders],
    ['Faturamento', num(r.billed)],
    ['Recebido', num(r.received)],
    ['Despesas', num(r.expenses)],
    ['Lucro estimado (recebido - despesas)', num(r.received) - num(r.expenses)],
    ['Pendente', num(r.pending)],
    ['Ticket médio', Number(ticket.toFixed(2))],
    [],
    ['Recebimentos por forma'],
    ...r.by_method.map((m) => [(PAY_LABEL as Record<string, string>)[m.method] ?? m.method, num(m.amount)]),
    [],
    ['Serviços mais vendidos', 'Qtd', 'Valor'],
    ...r.top_services.map((s) => [s.name, num(s.qty), num(s.amount)]),
    [],
    ['Funcionários', 'O.S.', 'Faturado', 'Comissão %', 'Comissão'],
    ...r.employees.map((e) => [e.name, e.orders, num(e.billed), num(e.commission_pct), num(e.commission)]),
    [],
    ['Produtos consumidos', 'Qtd', 'Unidade'],
    ...r.products.map((p) => [p.name, num(p.qty), p.unit]),
  ];
  return out;
}

export async function exportReportXlsx(r: Report, est: string, period: string): Promise<void> {
  const XLSX = await import('xlsx');
  const ws = XLSX.utils.aoa_to_sheet(rows(r, est, period));
  ws['!cols'] = [{ wch: 38 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 14 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Relatório');
  const base64 = XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });
  await saveAndShare(`relatorio-${stamp()}.xlsx`, base64, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Relatório (Excel)');
}

export async function exportReportPdf(r: Report, est: string, period: string): Promise<void> {
  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  let y = 18;
  const strip = (s: string) => s; // jsPDF padrão (WinAnsi) já cobre acentos do português
  const line = (text: string, bold = false, size = 10) => {
    if (y > 280) {
      doc.addPage();
      y = 18;
    }
    doc.setFont('helvetica', bold ? 'bold' : 'normal');
    doc.setFontSize(size);
    doc.text(strip(text), 16, y);
    y += size * 0.5 + 1.5;
  };
  const two = (a: string, b: string) => {
    if (y > 280) {
      doc.addPage();
      y = 18;
    }
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.text(strip(a), 16, y);
    doc.text(strip(b), 194, y, { align: 'right' });
    y += 6;
  };
  line(`Relatório — ${est}`, true, 16);
  line(`Período: ${period}`, false, 10);
  y += 4;
  const ticket = r.orders > 0 ? num(r.billed) / r.orders : 0;
  line('Resumo', true, 12);
  two('Veículos atendidos', String(r.orders));
  two('Faturamento', brl(num(r.billed)));
  two('Recebido', brl(num(r.received)));
  two('Despesas', brl(num(r.expenses)));
  two('Lucro estimado (recebido - despesas)', brl(num(r.received) - num(r.expenses)));
  two('Pendente', brl(num(r.pending)));
  two('Ticket médio', brl(ticket));
  y += 4;
  line('Recebimentos por forma', true, 12);
  if (r.by_method.length === 0) line('Sem recebimentos no período.');
  r.by_method.forEach((m) => two((PAY_LABEL as Record<string, string>)[m.method] ?? m.method, brl(num(m.amount))));
  y += 4;
  line('Serviços mais vendidos', true, 12);
  if (r.top_services.length === 0) line('Sem vendas no período.');
  r.top_services.forEach((s) => two(`${s.name} (${num(s.qty)}x)`, brl(num(s.amount))));
  y += 4;
  line('Funcionários', true, 12);
  r.employees.forEach((e) => two(`${e.name} · ${e.orders} O.S. · ${brl(num(e.billed))}`, `comissão ${brl(num(e.commission))}`));
  y += 4;
  line('Produtos consumidos', true, 12);
  if (r.products.length === 0) line('Sem consumo no período.');
  r.products.forEach((p) => two(p.name, `${num(p.qty)} ${p.unit}`));
  const uri = doc.output('datauristring');
  await saveAndShare(`relatorio-${stamp()}.pdf`, uri.substring(uri.indexOf(',') + 1), 'application/pdf', 'Relatório (PDF)');
}
