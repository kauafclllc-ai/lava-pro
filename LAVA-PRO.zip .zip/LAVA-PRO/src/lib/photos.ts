import { supabase } from './supabase';
import { uuid } from './format';

// Reduz a foto (lado maior 1280px, JPEG 0.78) antes de enviar, para economizar dados.
export async function compressImage(file: File): Promise<Blob> {
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, 1280 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas');
    c.width = Math.round(bmp.width * scale);
    c.height = Math.round(bmp.height * scale);
    c.getContext('2d')!.drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise<Blob | null>((r) => c.toBlob(r, 'image/jpeg', 0.78));
    if (blob) return blob;
  } catch {
    /* usa o arquivo original */
  }
  return file;
}

// Envia as fotos ao armazenamento privado (pasta = id do estabelecimento) e registra no banco.
// Retorna quantas falharam.
export async function uploadOrderPhotos(establishmentId: string, orderId: string, files: File[]): Promise<number> {
  let failed = 0;
  for (const f of files) {
    try {
      const blob = await compressImage(f);
      const path = `${establishmentId}/${orderId}/${uuid()}.jpg`;
      const up = await supabase.storage.from('order-photos').upload(path, blob, { contentType: 'image/jpeg' });
      if (up.error) throw up.error;
      const ins = await supabase.from('order_photos').insert({ establishment_id: establishmentId, order_id: orderId, path });
      if (ins.error) {
        await supabase.storage.from('order-photos').remove([path]);
        throw ins.error;
      }
    } catch {
      failed += 1;
    }
  }
  return failed;
}
