import { supabase } from './supabase';
import { secureGet, secureSet } from './securestore';
import { isNetworkError } from './api';
import { brl } from './format';

// Fila de operações feitas sem conexão. Cada operação carrega um client_id que o servidor usa
// para recusar duplicatas, então reenviar é sempre seguro. Nada é considerado sincronizado
// antes da confirmação do servidor.

export type OpKind = 'create_order' | 'register_payment' | 'set_status';
export type OpState = 'pending' | 'failed' | 'conflict';

export interface Op {
  id: string; // client_id (O.S. e pagamento) ou id local
  kind: OpKind;
  label: string;
  payload: any;
  createdAt: number;
  attempts: number;
  state: OpState;
  error?: string;
}

type Listener = () => void;
const listeners = new Set<Listener>();
let running = false;
let currentUid: string | null = null;
let opsCache: Op[] = [];

const key = (uid: string) => `u:${uid}:outbox`;
const notify = () => listeners.forEach((l) => l());

export function subscribeOutbox(l: Listener): () => void {
  listeners.add(l);
  return () => listeners.delete(l);
}
export const getOps = (): Op[] => opsCache;
export const isSyncing = (): boolean => running;

async function persist(): Promise<void> {
  if (currentUid) await secureSet(key(currentUid), opsCache);
  notify();
}

export async function initOutbox(uid: string): Promise<void> {
  currentUid = uid;
  opsCache = (await secureGet<Op[]>(key(uid))) ?? [];
  notify();
}

export function resetOutbox(): void {
  currentUid = null;
  opsCache = [];
  notify();
}

export async function enqueue(op: Omit<Op, 'createdAt' | 'attempts' | 'state'>): Promise<void> {
  if (opsCache.some((o) => o.id === op.id && o.kind === op.kind)) return; // já na fila
  opsCache = [...opsCache, { ...op, createdAt: Date.now(), attempts: 0, state: 'pending' }];
  await persist();
}

export async function discardOp(id: string): Promise<void> {
  opsCache = opsCache.filter((o) => o.id !== id);
  await persist();
}

export async function retryOp(id: string): Promise<void> {
  opsCache = opsCache.map((o) => (o.id === id ? { ...o, state: 'pending', error: undefined } : o));
  await persist();
  void runSync();
}

// Executa uma operação. Retorna 'ok' | 'network' | {error, conflict?}
async function execute(op: Op): Promise<'ok' | 'network' | { error: string; conflict?: boolean }> {
  try {
    if (op.kind === 'create_order') {
      const { error } = await supabase.rpc('create_order', { p: op.payload });
      if (error) return isNetworkError(error) ? 'network' : { error: error.message };
      return 'ok';
    }
    if (op.kind === 'register_payment') {
      const { error } = await supabase.rpc('register_payment', {
        p_order: op.payload.order_id,
        p_method: op.payload.method,
        p_amount: op.payload.amount,
        p_client_id: op.id,
      });
      if (error) return isNetworkError(error) ? 'network' : { error: error.message };
      return 'ok';
    }
    // set_status: só aplica se o status no servidor ainda é o esperado (controle de conflito)
    const { data, error } = await supabase
      .from('orders')
      .update({ status: op.payload.to })
      .eq('id', op.payload.order_id)
      .eq('status', op.payload.from)
      .select('id');
    if (error) return isNetworkError(error) ? 'network' : { error: error.message };
    if (!data || data.length === 0) {
      return { error: 'A O.S. foi alterada por outra pessoa enquanto você estava sem conexão.', conflict: true };
    }
    return 'ok';
  } catch (e) {
    return isNetworkError(e) ? 'network' : { error: String((e as any)?.message ?? e) };
  }
}

export async function runSync(): Promise<void> {
  if (running || !currentUid) return;
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
  running = true;
  notify();
  try {
    for (const op of [...opsCache]) {
      if (op.state !== 'pending') continue;
      const res = await execute(op);
      if (res === 'network') break; // sem conexão: tenta de novo depois, mantendo a ordem
      if (res === 'ok') {
        opsCache = opsCache.filter((o) => !(o.id === op.id && o.kind === op.kind));
      } else {
        opsCache = opsCache.map((o) =>
          o.id === op.id && o.kind === op.kind
            ? { ...o, attempts: o.attempts + 1, state: res.conflict ? 'conflict' : 'failed', error: res.error }
            : o,
        );
      }
      await persist();
    }
  } finally {
    running = false;
    notify();
  }
}

let timer: ReturnType<typeof setInterval> | null = null;
let onlineHandler: (() => void) | null = null;

export function startAutoSync(): void {
  stopAutoSync();
  onlineHandler = () => void runSync();
  window.addEventListener('online', onlineHandler);
  timer = setInterval(() => {
    if (opsCache.some((o) => o.state === 'pending')) void runSync();
  }, 20000);
  void runSync();
}

export function stopAutoSync(): void {
  if (timer) clearInterval(timer);
  if (onlineHandler) window.removeEventListener('online', onlineHandler);
  timer = null;
  onlineHandler = null;
}

// ---------- Envio com fila (usado pelas telas) ----------

export interface SubmitResult {
  queued: boolean;
  data?: any;
}

export async function submitOrder(payload: any, label: string): Promise<SubmitResult> {
  if (typeof navigator === 'undefined' || navigator.onLine !== false) {
    const { data, error } = await supabase.rpc('create_order', { p: payload });
    if (!error) return { queued: false, data };
    if (!isNetworkError(error)) throw error;
  }
  await enqueue({ id: payload.client_id, kind: 'create_order', label, payload });
  return { queued: true };
}

export async function submitPayment(args: { order_id: string; method: string; amount: number; client_id: string }, label: string): Promise<SubmitResult> {
  if (typeof navigator === 'undefined' || navigator.onLine !== false) {
    const { data, error } = await supabase.rpc('register_payment', {
      p_order: args.order_id,
      p_method: args.method,
      p_amount: args.amount,
      p_client_id: args.client_id,
    });
    if (!error) return { queued: false, data };
    if (!isNetworkError(error)) throw error;
  }
  await enqueue({ id: args.client_id, kind: 'register_payment', label: `${label} · ${brl(args.amount)}`, payload: args });
  return { queued: true };
}

export async function submitStatus(args: { order_id: string; from: string; to: string }, label: string): Promise<SubmitResult> {
  if (typeof navigator === 'undefined' || navigator.onLine !== false) {
    const { data, error } = await supabase.from('orders').update({ status: args.to }).eq('id', args.order_id).eq('status', args.from).select('id');
    if (!error) {
      if (!data || data.length === 0) throw new Error('A O.S. foi alterada por outra pessoa. Atualize a tela.');
      return { queued: false };
    }
    if (!isNetworkError(error)) throw error;
  }
  await enqueue({ id: `${args.order_id}:${args.to}`, kind: 'set_status', label, payload: args });
  return { queued: true };
}
