import type { Role } from './types';

export type Feature =
  | 'newOrder'
  | 'finance'
  | 'customers'
  | 'vehicles'
  | 'services'
  | 'servicesManage'
  | 'employees'
  | 'stock'
  | 'stockManage'
  | 'expenses'
  | 'reports'
  | 'appointments'
  | 'notifications'
  | 'refund'
  | 'cancelOrder';

const MAP: Record<Feature, Role[]> = {
  newOrder: ['admin', 'manager', 'attendant'],
  finance: ['admin', 'manager', 'attendant'],
  customers: ['admin', 'manager', 'attendant'],
  vehicles: ['admin', 'manager', 'attendant'],
  services: ['admin', 'manager', 'attendant'],
  servicesManage: ['admin', 'manager'],
  employees: ['admin', 'manager'],
  stock: ['admin', 'manager', 'attendant'],
  stockManage: ['admin', 'manager'],
  expenses: ['admin', 'manager'],
  reports: ['admin', 'manager'],
  appointments: ['admin', 'manager', 'attendant'],
  notifications: ['admin', 'manager', 'attendant'],
  refund: ['admin', 'manager'],
  cancelOrder: ['admin', 'manager'],
};

export function can(role: Role | undefined | null, feature: Feature): boolean {
  return !!role && MAP[feature].includes(role);
}
