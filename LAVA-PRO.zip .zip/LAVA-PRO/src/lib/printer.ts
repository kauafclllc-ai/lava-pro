import { Capacitor } from '@capacitor/core';
import type { ReceiptFormat } from './receipt';

// Impressão em impressora térmica Bluetooth LE (ESC/POS).
// Importante: funciona com impressoras que usam Bluetooth LE. Modelos antigos que só falam
// Bluetooth "clássico" (SPP) não aparecem aqui; use "Compartilhar PDF" com o app da impressora.
// USB não é suportado nesta versão.

export interface PrinterSettings {
  deviceId?: string;
  deviceName?: string;
  service?: string;
  characteristic?: string;
  writeNoResponse?: boolean;
  format: ReceiptFormat;
}

const KEY = 'lavapro:printer';
const KNOWN_SERVICES = [
  '0000ff00-0000-1000-8000-00805f9b34fb',
  '000018f0-0000-1000-8000-00805f9b34fb',
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000fee7-0000-1000-8000-00805f9b34fb',
];

export function loadPrinter(): PrinterSettings {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { format: '58', ...JSON.parse(raw) };
  } catch {
    /* sem armazenamento */
  }
  return { format: '58' };
}

export function savePrinter(s: PrinterSettings): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* sem armazenamento */
  }
}

export const bluetoothAvailable = (): boolean => Capacitor.isNativePlatform();

async function ble() {
  const { BleClient } = await import('@capacitor-community/bluetooth-le');
  await BleClient.initialize({ androidNeverForLocation: true });
  return BleClient;
}

// Escolhe a impressora e descobre qual característica aceita escrita
export async function pickPrinter(): Promise<PrinterSettings> {
  const BleClient = await ble();
  const device = await BleClient.requestDevice({ optionalServices: KNOWN_SERVICES });
  await BleClient.connect(device.deviceId);
  try {
    const services = await BleClient.getServices(device.deviceId);
    let found: { service: string; characteristic: string; noResp: boolean } | null = null;
    for (const svc of services) {
      for (const ch of svc.characteristics) {
        if (ch.properties.write || ch.properties.writeWithoutResponse) {
          const cand = { service: svc.uuid, characteristic: ch.uuid, noResp: !ch.properties.write && !!ch.properties.writeWithoutResponse };
          if (KNOWN_SERVICES.includes(svc.uuid.toLowerCase())) {
            found = cand;
            break;
          }
          found = found ?? cand;
        }
      }
      if (found && KNOWN_SERVICES.includes(found.service.toLowerCase())) break;
    }
    if (!found) throw new Error('Esta impressora não aceita impressão por Bluetooth LE.');
    const s: PrinterSettings = {
      ...loadPrinter(),
      deviceId: device.deviceId,
      deviceName: device.name ?? 'Impressora',
      service: found.service,
      characteristic: found.characteristic,
      writeNoResponse: found.noResp,
    };
    savePrinter(s);
    return s;
  } finally {
    try {
      await BleClient.disconnect(device.deviceId);
    } catch {
      /* já desconectado */
    }
  }
}

export async function printBytes(bytes: Uint8Array): Promise<void> {
  const s = loadPrinter();
  if (!s.deviceId || !s.service || !s.characteristic) throw new Error('Nenhuma impressora configurada.');
  const BleClient = await ble();
  await BleClient.connect(s.deviceId);
  try {
    const CHUNK = 100;
    for (let i = 0; i < bytes.length; i += CHUNK) {
      const slice = bytes.slice(i, i + CHUNK);
      const view = new DataView(slice.buffer, slice.byteOffset, slice.byteLength);
      if (s.writeNoResponse) await BleClient.writeWithoutResponse(s.deviceId, s.service, s.characteristic, view);
      else await BleClient.write(s.deviceId, s.service, s.characteristic, view);
      await new Promise((r) => setTimeout(r, 40));
    }
  } finally {
    try {
      await BleClient.disconnect(s.deviceId);
    } catch {
      /* já desconectado */
    }
  }
}
