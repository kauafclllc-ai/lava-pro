import { brl } from './format';

export interface ReceiptItem {
  name: string;
  qty: number;
  unit: number;
  discount: number;
  total: number;
}

export interface ReceiptData {
  est: { name: string; phone?: string | null; address?: string | null; document?: string | null; footer?: string | null };
  number: number | string;
  createdAt: string;
  plate: string;
  model: string;
  customer: string;
  employee?: string | null;
  items: ReceiptItem[];
  subtotal: number;
  discount: number;
  total: number;
  paid: number;
  url?: string; // endereço público de acompanhamento (vai no QR Code)
}

export type ReceiptFormat = '58' | '80' | 'A4';
export const COLS: Record<ReceiptFormat, number> = { '58': 32, '80': 48, A4: 64 };

// Impressoras térmicas simples não imprimem acentos de forma confiável: transliterar para ASCII.
export function ascii(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^\x20-\x7e]/g, '?');
}

const pad = (left: string, right: string, cols: number): string => {
  const space = Math.max(1, cols - left.length - right.length);
  return left + ' '.repeat(space) + right;
};

function wrap(text: string, cols: number): string[] {
  const out: string[] = [];
  let line = '';
  for (const word of ascii(text).split(/\s+/)) {
    if (!word) continue;
    if ((line + ' ' + word).trim().length > cols) {
      if (line) out.push(line);
      line = word.length > cols ? word.slice(0, cols) : word;
    } else {
      line = (line + ' ' + word).trim();
    }
  }
  if (line) out.push(line);
  return out;
}

const centered = (s: string, cols: number): string => {
  const t = s.slice(0, cols);
  return ' '.repeat(Math.max(0, Math.floor((cols - t.length) / 2))) + t;
};

const money = (n: number): string => ascii(brl(n)).replace(/ /g, ' ');

export function fmtReceiptDate(iso: string): string {
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

// Layout em texto monoespaçado. Usado na impressão ESC/POS, no PDF e na prévia.
export function receiptLines(r: ReceiptData, cols: number): string[] {
  const line = '-'.repeat(cols);
  const out: string[] = [];
  for (const l of wrap(r.est.name.toUpperCase(), cols)) out.push(centered(l, cols));
  if (r.est.document) out.push(centered(ascii(r.est.document), cols));
  if (r.est.address) for (const l of wrap(r.est.address, cols)) out.push(centered(l, cols));
  if (r.est.phone) out.push(centered(ascii(r.est.phone), cols));
  out.push(line);
  out.push(centered(`ORDEM DE SERVICO #${r.number}`, cols));
  out.push(centered(fmtReceiptDate(r.createdAt), cols));
  out.push(line);
  out.push(pad('Placa:', ascii(r.plate), cols));
  out.push(pad('Modelo:', ascii(r.model).slice(0, cols - 8), cols));
  out.push(pad('Cliente:', ascii(r.customer).slice(0, cols - 9), cols));
  if (r.employee) out.push(pad('Resp.:', ascii(r.employee).slice(0, cols - 7), cols));
  out.push(line);
  for (const it of r.items) {
    for (const l of wrap(it.name, cols)) out.push(l);
    out.push(pad(`  ${it.qty} x ${money(it.unit)}`, money(it.qty * it.unit), cols));
    if (it.discount > 0) out.push(pad('  Desconto', '-' + money(it.discount), cols));
  }
  out.push(line);
  if (r.discount > 0) {
    out.push(pad('Subtotal', money(r.subtotal), cols));
    out.push(pad('Descontos', '-' + money(r.discount), cols));
  }
  out.push(pad('TOTAL', money(r.total), cols));
  out.push(pad('Pago', money(r.paid), cols));
  const open = Math.max(0, r.total - r.paid);
  out.push(pad(open > 0 ? 'A PAGAR' : 'SITUACAO', open > 0 ? money(open) : 'PAGO', cols));
  out.push(line);
  if (r.est.footer) for (const l of wrap(r.est.footer, cols)) out.push(centered(l, cols));
  return out;
}
