import { ReceiptData, ascii, receiptLines } from './receipt';

// Gera os bytes ESC/POS de um cupom. Padrão aceito pela grande maioria das impressoras
// térmicas de 58 mm e 80 mm.

const ESC = 0x1b;
const GS = 0x1d;

function textBytes(s: string): number[] {
  return Array.from(ascii(s)).map((c) => c.charCodeAt(0));
}

export function qrBytes(data: string, moduleSize = 6): number[] {
  const d = textBytes(data);
  const len = d.length + 3;
  return [
    GS, 0x28, 0x6b, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00, // modelo 2
    GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x43, moduleSize, // tamanho do módulo
    GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x45, 0x31, // correção de erro M
    GS, 0x28, 0x6b, len & 0xff, (len >> 8) & 0xff, 0x31, 0x50, 0x30, ...d, // dados
    GS, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x51, 0x30, // imprimir
  ];
}

export function buildEscPos(r: ReceiptData, cols: 32 | 48): Uint8Array {
  const b: number[] = [ESC, 0x40]; // inicializar
  const lines = receiptLines(r, cols);
  // cabeçalho (nome) em negrito/centralizado, o resto alinhado à esquerda em fonte normal
  b.push(ESC, 0x61, 0x00);
  for (const l of lines) b.push(...textBytes(l), 0x0a);
  if (r.url) {
    b.push(ESC, 0x61, 0x01); // centralizar
    b.push(...qrBytes(r.url, cols === 32 ? 5 : 6));
    b.push(0x0a, ...textBytes('Acompanhe pelo QR Code'), 0x0a);
    b.push(ESC, 0x61, 0x00);
  }
  b.push(ESC, 0x64, 0x04); // avançar 4 linhas
  b.push(GS, 0x56, 0x42, 0x00); // corte parcial (ignorado se não houver guilhotina)
  return Uint8Array.from(b);
}

export function buildTestPage(cols: 32 | 48): Uint8Array {
  const b: number[] = [ESC, 0x40, ESC, 0x61, 0x01, ESC, 0x45, 0x01];
  b.push(...textBytes('LAVA PRO'), 0x0a, ESC, 0x45, 0x00);
  b.push(...textBytes('Teste de impressao'), 0x0a);
  b.push(...textBytes('-'.repeat(cols)), 0x0a);
  b.push(ESC, 0x61, 0x00, ...textBytes('Acentos: acao, coracao, pao'), 0x0a);
  b.push(...textBytes('Valor: R$ 1.234,56'), 0x0a, ...qrBytes('https://exemplo.com'), 0x0a);
  b.push(ESC, 0x64, 0x04, GS, 0x56, 0x42, 0x00);
  return Uint8Array.from(b);
}
