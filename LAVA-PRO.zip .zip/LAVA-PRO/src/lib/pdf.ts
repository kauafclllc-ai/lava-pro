import { COLS, ReceiptData, ReceiptFormat, receiptLines } from './receipt';

// Cupom em PDF nos tamanhos 58 mm, 80 mm e A4. Retorna base64.
export async function receiptPdf(r: ReceiptData, format: ReceiptFormat, qrDataUrl?: string): Promise<string> {
  const { jsPDF } = await import('jspdf');
  const cols = COLS[format];
  const lines = receiptLines(r, cols);
  const pt = format === '58' ? 8 : format === '80' ? 7 : 10;
  const lineH = pt * 0.42; // mm
  const margin = format === 'A4' ? 20 : 2;
  const qr = r.url && qrDataUrl ? (format === 'A4' ? 40 : format === '80' ? 34 : 30) : 0;
  const width = format === '58' ? 58 : format === '80' ? 80 : 210;
  const height = format === 'A4' ? 297 : Math.ceil(lines.length * lineH + qr + margin * 2 + 12);

  const doc = new jsPDF({ unit: 'mm', format: [width, height], orientation: 'portrait' });
  doc.setFont('courier', 'normal');
  doc.setFontSize(pt);
  let y = margin + lineH;
  for (const l of lines) {
    doc.text(l, margin, y);
    y += lineH;
  }
  if (qr) {
    doc.addImage(qrDataUrl as string, 'PNG', (width - qr) / 2, y + 2, qr, qr);
    doc.setFontSize(pt - 1);
    doc.text('Acompanhe pelo QR Code', width / 2, y + qr + 6, { align: 'center' });
  }
  const dataUri = doc.output('datauristring');
  return dataUri.substring(dataUri.indexOf(',') + 1);
}
