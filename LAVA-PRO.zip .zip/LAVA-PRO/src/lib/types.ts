export type Role = 'admin' | 'manager' | 'attendant' | 'washer';

export type OrderStatus =
  | 'waiting'
  | 'in_progress'
  | 'done'
  | 'awaiting_payment'
  | 'ready'
  | 'delivered'
  | 'cancelled';

export type VehicleType = 'car' | 'suv' | 'pickup' | 'motorcycle' | 'van' | 'other';

export type PayMethod = 'cash' | 'pix' | 'credit' | 'debit' | 'other';

export interface Profile {
  id: string;
  establishment_id: string;
  full_name: string;
  role: Role;
  active: boolean;
  phone: string | null;
}

export interface Establishment {
  id: string;
  name: string;
  phone: string | null;
  address: string | null;
  document: string | null;
  footer: string | null;
}

export interface Customer {
  id: string;
  name: string;
  phone: string | null;
}

export interface Service {
  id: string;
  name: string;
  price: number;
  active: boolean;
}

export interface Employee {
  id: string;
  full_name: string;
  role: Role;
}
