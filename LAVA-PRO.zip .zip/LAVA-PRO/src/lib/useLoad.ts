import { useCallback, useEffect, useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { cached } from './cache';
import { errMsg } from './api';

// Carrega dados com cache offline. `name` identifica o cache (ou null para não usar cache).
export function useLoad<T>(name: string | null, fetcher: () => Promise<T>, deps: unknown[] = []) {
  const { session } = useAuth();
  const uid = session?.user.id ?? null;
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stale, setStale] = useState(false);
  const fetchRef = useRef(fetcher);
  fetchRef.current = fetcher;
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);

  const reload = useCallback(async () => {
    try {
      const res = name
        ? await cached(uid, name, () => fetchRef.current())
        : { data: await fetchRef.current(), stale: false };
      if (!alive.current) return;
      setData(res.data);
      setStale(res.stale);
      setError('');
    } catch (e) {
      if (!alive.current) return;
      setError(errMsg(e));
    } finally {
      if (alive.current) setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [name, uid]);

  useEffect(() => {
    setLoading(true);
    void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reload, ...deps]);

  return { data, loading, error, stale, reload, setData };
}
