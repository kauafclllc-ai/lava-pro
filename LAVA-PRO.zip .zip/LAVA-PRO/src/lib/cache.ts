import { secureGet, secureSet, secureDeletePrefix } from './securestore';
import { isNetworkError } from './api';

// Cache de leitura para uso sem internet. Sempre tenta o servidor primeiro; só usa o cache
// quando a falha é de conexão. Os dados do cache são marcados como "desatualizados".

export interface Cached<T> {
  data: T;
  stale: boolean;
  savedAt?: number;
}

const k = (uid: string, name: string) => `u:${uid}:cache:${name}`;

export async function cached<T>(uid: string | null, name: string, fetcher: () => Promise<T>): Promise<Cached<T>> {
  try {
    const data = await fetcher();
    if (uid) void secureSet(k(uid, name), { data, savedAt: Date.now() });
    return { data, stale: false };
  } catch (e) {
    if (uid && isNetworkError(e)) {
      const hit = await secureGet<{ data: T; savedAt: number }>(k(uid, name));
      if (hit) return { data: hit.data, stale: true, savedAt: hit.savedAt };
    }
    throw e;
  }
}

export async function readCache<T>(uid: string, name: string): Promise<T | undefined> {
  return (await secureGet<{ data: T }>(k(uid, name)))?.data;
}

export async function clearCache(uid: string): Promise<void> {
  await secureDeletePrefix(`u:${uid}:cache:`);
}
