import { useEffect, useState } from 'react';
import { getOps, isSyncing, subscribeOutbox } from './outbox';

export function useOnline(): boolean {
  const [online, setOnline] = useState<boolean>(typeof navigator === 'undefined' ? true : navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  return online;
}

export function useNow(intervalMs = 30000): number {
  const [now, setNow] = useState<number>(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

export function useOutbox() {
  const [, force] = useState(0);
  useEffect(() => subscribeOutbox(() => force((n) => n + 1)), []);
  const ops = getOps();
  return {
    ops,
    syncing: isSyncing(),
    pending: ops.filter((o) => o.state === 'pending').length,
    problems: ops.filter((o) => o.state !== 'pending').length,
  };
}
