import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const isConfigured = Boolean(url && key);

// Só a URL pública e a chave "anon" entram no app. A chave service_role nunca.
export const supabase = createClient(url ?? 'http://invalid.local', key ?? 'invalid-key', {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
});

export function publicBaseUrl(): string {
  const configured = (import.meta.env.VITE_PUBLIC_BASE_URL as string | undefined)?.trim();
  return configured ? configured.replace(/\/+$/, '') : '';
}
