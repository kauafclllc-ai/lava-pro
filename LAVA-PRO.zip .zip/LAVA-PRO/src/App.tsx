import { Navigate, Outlet, Route, Routes } from 'react-router-dom';
import { AlertTriangle, UserX } from 'lucide-react';
import { useAuth } from './context/AuthContext';
import { isConfigured } from './lib/supabase';
import Layout from './components/Layout';
import { ErrorBox, SplashScreenView } from './components/ui';
import Login from './pages/Login';
import Onboarding from './pages/Onboarding';
import Dashboard from './pages/Dashboard';
import NewOrder from './pages/NewOrder';
import Yard from './pages/Yard';
import OrderDetail from './pages/OrderDetail';
import Finance from './pages/Finance';
import More from './pages/More';
import Track from './pages/Track';
import Customers from './pages/Customers';
import Vehicles from './pages/Vehicles';
import Services from './pages/Services';
import Employees from './pages/Employees';
import Stock from './pages/Stock';
import Expenses from './pages/Expenses';
import Reports from './pages/Reports';
import Appointments from './pages/Appointments';
import Notifications from './pages/Notifications';
import Settings from './pages/Settings';
import PrinterSettings from './pages/PrinterSettings';
import Scanner from './pages/Scanner';
import Pending from './pages/Pending';

function RequireAuth() {
  const { session, profile, loading, profileError, refresh, signOut } = useAuth();
  if (loading) return <SplashScreenView />;
  if (!session) return <Navigate to="/login" replace />;
  if (profileError) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 p-6">
        <ErrorBox message={`Não foi possível carregar sua conta. ${profileError}`} onRetry={() => void refresh()} />
        <button className="min-h-[48px] px-4 text-sm text-mute" onClick={() => void signOut()}>
          Sair da conta
        </button>
      </div>
    );
  }
  if (!profile) return <Onboarding />;
  if (!profile.active) {
    return (
      <div className="flex h-full items-center justify-center p-6">
        <div className="card max-w-sm p-6 text-center">
          <UserX className="mx-auto mb-3 text-bad" size={36} />
          <h1 className="mb-2 text-lg font-bold">Conta desativada</h1>
          <p className="mb-4 text-sm text-mute">Seu acesso a este estabelecimento foi desativado. Fale com o administrador.</p>
          <button className="btn-ghost w-full" onClick={() => void signOut()}>
            Sair da conta
          </button>
        </div>
      </div>
    );
  }
  return <Outlet />;
}

export default function App() {
  const { session, loading } = useAuth();

  if (!isConfigured) {
    return (
      <div className="flex h-full items-center justify-center p-6">
        <div className="card max-w-sm p-6 text-center">
          <AlertTriangle className="mx-auto mb-3 text-warn" size={36} />
          <h1 className="mb-2 text-lg font-bold">Backend não configurado</h1>
          <p className="text-sm text-mute">
            Defina VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY antes de gerar o aplicativo. Veja o arquivo LEIA-ME.md.
          </p>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/acompanhar/:token" element={<Track />} />
      <Route path="/login" element={loading ? <SplashScreenView /> : session ? <Navigate to="/" replace /> : <Login />} />
      <Route element={<RequireAuth />}>
        <Route element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="nova-os" element={<NewOrder />} />
          <Route path="patio" element={<Yard />} />
          <Route path="os/:id" element={<OrderDetail />} />
          <Route path="financeiro" element={<Finance />} />
          <Route path="mais" element={<More />} />
          <Route path="clientes" element={<Customers />} />
          <Route path="veiculos" element={<Vehicles />} />
          <Route path="servicos" element={<Services />} />
          <Route path="funcionarios" element={<Employees />} />
          <Route path="estoque" element={<Stock />} />
          <Route path="despesas" element={<Expenses />} />
          <Route path="relatorios" element={<Reports />} />
          <Route path="agendamentos" element={<Appointments />} />
          <Route path="notificacoes" element={<Notifications />} />
          <Route path="configuracoes" element={<Settings />} />
          <Route path="impressora" element={<PrinterSettings />} />
          <Route path="scanner" element={<Scanner />} />
          <Route path="pendencias" element={<Pending />} />
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
