import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { isConfigured, supabase } from '../lib/supabase';
import type { Establishment, Profile } from '../lib/types';
import { initOutbox, resetOutbox, startAutoSync, stopAutoSync } from '../lib/outbox';
import { clearCache } from '../lib/cache';
import { errMsg } from '../lib/api';

interface AuthState {
  session: Session | null;
  profile: Profile | null;
  establishment: Establishment | null;
  establishmentName: string;
  loading: boolean;
  profileError: string | null;
  refresh: () => Promise<void>;
  signOut: () => Promise<void>;
}

const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [establishment, setEstablishment] = useState<Establishment | null>(null);
  const [authReady, setAuthReady] = useState(!isConfigured);
  const [profileReady, setProfileReady] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);

  useEffect(() => {
    if (!isConfigured) return;
    supabase.auth
      .getSession()
      .then(({ data }) => setSession(data.session))
      .catch(() => setSession(null))
      .finally(() => setAuthReady(true));
    const { data } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  const uid = session?.user.id ?? null;

  const loadProfile = useCallback(async () => {
    if (!uid) {
      setProfile(null);
      setEstablishment(null);
      setProfileError(null);
      setProfileReady(true);
      return;
    }
    const { data, error } = await supabase.rpc('my_profile');
    if (error) {
      // Erro de rede/permissão NÃO é tratado como "sem estabelecimento"
      setProfileError(errMsg(error));
      setProfileReady(true);
      return;
    }
    setProfileError(null);
    const r = data as any;
    if (!r) {
      setProfile(null);
      setEstablishment(null);
    } else {
      setProfile({
        id: r.id,
        establishment_id: r.establishment_id,
        full_name: r.full_name,
        role: r.role,
        active: r.active,
        phone: r.phone ?? null,
      });
      setEstablishment({
        id: r.establishment_id,
        name: r.establishment,
        phone: r.establishment_phone ?? null,
        address: r.establishment_address ?? null,
        document: r.establishment_document ?? null,
        footer: r.receipt_footer ?? null,
      });
    }
    setProfileReady(true);
  }, [uid]);

  useEffect(() => {
    setProfileReady(false);
    void loadProfile();
  }, [loadProfile]);

  // Fila offline: carrega e sincroniza automaticamente enquanto houver usuário ativo
  const active = Boolean(profile?.active);
  useEffect(() => {
    if (!uid || !active) {
      stopAutoSync();
      return;
    }
    let cancelled = false;
    void initOutbox(uid).then(() => {
      if (!cancelled) startAutoSync();
    });
    return () => {
      cancelled = true;
      stopAutoSync();
    };
  }, [uid, active]);

  const signOut = useCallback(async () => {
    const id = uid;
    stopAutoSync();
    await supabase.auth.signOut();
    if (id) await clearCache(id); // a fila de pendências é mantida (e só roda para o mesmo usuário)
    resetOutbox();
    setProfile(null);
    setEstablishment(null);
  }, [uid]);

  const value = useMemo<AuthState>(
    () => ({
      session,
      profile,
      establishment,
      establishmentName: establishment?.name ?? '',
      loading: !authReady || (Boolean(session) && !profileReady),
      profileError,
      refresh: loadProfile,
      signOut,
    }),
    [session, profile, establishment, authReady, profileReady, profileError, loadProfile, signOut],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth fora do AuthProvider');
  return v;
}
