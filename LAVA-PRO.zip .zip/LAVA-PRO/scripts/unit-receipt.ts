import { receiptLines, ascii, COLS } from '../src/lib/receipt';
import { buildEscPos, qrBytes } from '../src/lib/escpos';
import { normalizePlate, isValidPlate, parseMoney, formatPhone } from '../src/lib/format';

let fail = 0;
const ok = (c: boolean, m: string) => { console.log((c ? 'PASS  ' : 'FAIL  ') + m); if (!c) fail++; };

const r = {
  est: { name: 'Lava Rápido Ção & Cia', phone: '(11) 99999-0000', address: 'Av. São João, 1000 - Centro', document: '12.345.678/0001-90', footer: 'Obrigado pela preferência! Volte sempre.' },
  number: 42, createdAt: '2026-11-02T14:30:00-03:00', plate: 'ABC-1D23', model: 'Chevrolet Onix Plus Premier', customer: 'João da Conceição Álvares de Souza',
  employee: 'Mário', items: [
    { name: 'Lavagem completa com cera e aspiração detalhada', qty: 2, unit: 40, discount: 5, total: 75 },
    { name: 'Cera', qty: 1, unit: 30, discount: 0, total: 30 },
  ], subtotal: 110, discount: 5, total: 105, paid: 50, url: 'https://lavapro.netlify.app/#/acompanhar/0b6f5d9e-1111-4222-8333-444455556666',
};

for (const f of ['58', '80', 'A4'] as const) {
  const cols = COLS[f];
  const lines = receiptLines(r, cols);
  ok(lines.every((l) => l.length <= cols), `formato ${f}: nenhuma linha passa de ${cols} colunas (máx ${Math.max(...lines.map((l) => l.length))})`);
  ok(lines.every((l) => /^[\x20-\x7e]*$/.test(l)), `formato ${f}: somente ASCII imprimível`);
  ok(lines.some((l) => l.includes('TOTAL') && l.includes('105,00')), `formato ${f}: mostra o total R$ 105,00`);
  ok(lines.some((l) => l.includes('A PAGAR') && l.includes('55,00')), `formato ${f}: saldo a pagar R$ 55,00`);
}
const paid = receiptLines({ ...r, paid: 105 }, 32);
ok(paid.some((l) => l.includes('PAGO')) && !paid.some((l) => l.includes('A PAGAR')), 'cupom quitado mostra PAGO');
ok(ascii('ação, coração, ÇÃO') === 'acao, coracao, CAO', 'acentos removidos corretamente');

const b = buildEscPos(r, 32);
ok(b[0] === 0x1b && b[1] === 0x40, 'ESC/POS começa com inicialização (ESC @)');
ok(b.slice(-4).join() === [0x1d, 0x56, 0x42, 0x00].join(), 'ESC/POS termina com corte');
const qr = qrBytes('https://x.co');
ok(qr.slice(0, 5).join() === [0x1d, 0x28, 0x6b, 0x04, 0x00].join(), 'QR nativo: comando de modelo');
const len = 'https://x.co'.length + 3;
const tail = qr.slice(-8).join();
ok(tail === [0x1d, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x51, 0x30].join(), 'QR nativo: termina com o comando de impressão completo');
const dataIdx = qr.findIndex((v, i) => v === 0x31 && qr[i + 1] === 0x50 && qr[i + 2] === 0x30);
ok(qr[dataIdx - 2] === (len & 0xff) && qr[dataIdx - 1] === 0x00 || qr[dataIdx - 3] === (len & 0xff), 'QR nativo: tamanho dos dados (pL pH) correto');
ok(String.fromCharCode(...qr.slice(dataIdx + 3, dataIdx + 3 + 12)) === 'https://x.co', 'QR nativo: conteúdo da URL gravado nos bytes');
ok(Array.from(b).some((v, i, a) => v === 0x1d && a[i + 1] === 0x28 && a[i + 2] === 0x6b), 'cupom com URL inclui QR');
ok(!Array.from(buildEscPos({ ...r, url: undefined }, 32)).some((v, i, a) => v === 0x1d && a[i + 1] === 0x28 && a[i + 2] === 0x6b), 'cupom sem URL não inclui QR');
ok(Array.from(b).every((v) => v >= 0 && v <= 255), 'todos os bytes entre 0 e 255');

ok(normalizePlate('abc-1d23') === 'ABC1D23' && isValidPlate('ABC1D23') && isValidPlate('ABC1234'), 'placa Mercosul e antiga válidas');
ok(!isValidPlate('AB12345') && !isValidPlate('ABC12'), 'placas inválidas recusadas');
ok(parseMoney('12,50') === 12.5 && parseMoney('abc') === 0 && parseMoney('-3') === 0, 'parseMoney (vírgula, lixo e negativo)');
ok(formatPhone('11987654321') === '(11) 98765-4321', 'máscara de telefone');

console.log(fail === 0 ? '\nTODOS OS TESTES PASSARAM' : `\n${fail} FALHA(S)`);
process.exit(fail ? 1 : 0);
