-- ============================================================
-- LAVA PRO - Esquema do banco (Fase 1)
-- Cole este arquivo inteiro no Supabase: SQL Editor > New query > Run.
-- Pode ser executado em um projeto novo. Não execute duas vezes.
-- ============================================================

create extension if not exists pgcrypto;

-- ---------- Tabelas ----------

create table public.establishments (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 80),
  order_seq integer not null default 0,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  full_name text not null check (char_length(full_name) between 2 and 80),
  role text not null default 'attendant' check (role in ('admin','manager','attendant','washer')),
  created_at timestamptz not null default now()
);
create index profiles_est_idx on public.profiles(establishment_id);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  phone text,
  created_at timestamptz not null default now()
);
create index customers_est_idx on public.customers(establishment_id);
create index customers_phone_idx on public.customers(establishment_id, phone);

create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  plate text not null check (plate ~ '^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$'),
  brand text,
  model text not null,
  color text,
  type text not null default 'car' check (type in ('car','suv','pickup','motorcycle','van','other')),
  created_at timestamptz not null default now(),
  unique (establishment_id, plate)
);

create table public.services (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  price numeric(10,2) not null check (price >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create index services_est_idx on public.services(establishment_id);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  number integer not null,
  vehicle_id uuid not null references public.vehicles(id),
  customer_id uuid not null references public.customers(id),
  employee_id uuid references public.profiles(id) on delete set null,
  status text not null default 'waiting'
    check (status in ('waiting','in_progress','done','awaiting_payment','ready','delivered','cancelled')),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid')),
  notes text,
  subtotal numeric(10,2) not null check (subtotal >= 0),
  discount numeric(10,2) not null default 0 check (discount >= 0),
  total numeric(10,2) not null check (total >= 0),
  public_token uuid not null default gen_random_uuid() unique,
  client_id uuid not null,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  delivered_at timestamptz,
  unique (establishment_id, number),
  unique (establishment_id, client_id)
);
create index orders_est_status_idx on public.orders(establishment_id, status);
create index orders_est_created_idx on public.orders(establishment_id, created_at desc);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  service_id uuid references public.services(id) on delete set null,
  name text not null,
  quantity integer not null check (quantity between 1 and 99),
  unit_price numeric(10,2) not null check (unit_price >= 0),
  discount numeric(10,2) not null default 0 check (discount >= 0),
  created_at timestamptz not null default now()
);
create index order_items_order_idx on public.order_items(order_id);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  order_id uuid not null references public.orders(id) on delete cascade,
  method text not null check (method in ('cash','pix','credit','debit','other')),
  amount numeric(10,2) not null check (amount > 0),
  client_id uuid not null,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique (establishment_id, client_id)
);
create index payments_est_created_idx on public.payments(establishment_id, created_at desc);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  description text not null,
  category text not null default 'other',
  amount numeric(10,2) not null check (amount > 0),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index expenses_est_created_idx on public.expenses(establishment_id, created_at desc);

create table public.audit_log (
  id bigint generated always as identity primary key,
  establishment_id uuid,
  user_id uuid,
  table_name text not null,
  record_id text,
  action text not null,
  data jsonb,
  created_at timestamptz not null default now()
);
create index audit_est_idx on public.audit_log(establishment_id, created_at desc);

-- ---------- Funções auxiliares ----------

create or replace function public.current_establishment() returns uuid
language sql stable security definer set search_path = public as $$
  select establishment_id from public.profiles where id = auth.uid()
$$;

create or replace function public.app_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

-- Numeração sequencial da O.S. por estabelecimento
create or replace function public.set_order_number() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.establishments
     set order_seq = order_seq + 1
   where id = new.establishment_id
  returning order_seq into new.number;
  return new;
end $$;

create trigger trg_orders_number before insert on public.orders
for each row execute function public.set_order_number();

create or replace function public.touch_order() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  if new.status = 'delivered' and old.status is distinct from 'delivered' then
    new.delivered_at := now();
  end if;
  return new;
end $$;

create trigger trg_orders_touch before update on public.orders
for each row execute function public.touch_order();


-- Proteção de colunas: pelo app (papéis authenticated/anon) só é possível mudar o
-- andamento. Valores, pagamento e identificadores só mudam pelas funções do servidor.
create or replace function public.guard_order_update() returns trigger
language plpgsql set search_path = public as $$
begin
  if current_user in ('authenticated','anon') then
    if new.id is distinct from old.id
       or new.establishment_id is distinct from old.establishment_id
       or new.number is distinct from old.number
       or new.vehicle_id is distinct from old.vehicle_id
       or new.customer_id is distinct from old.customer_id
       or new.subtotal is distinct from old.subtotal
       or new.discount is distinct from old.discount
       or new.total is distinct from old.total
       or new.payment_status is distinct from old.payment_status
       or new.public_token is distinct from old.public_token
       or new.client_id is distinct from old.client_id
       or new.created_by is distinct from old.created_by
       or new.created_at is distinct from old.created_at
       or new.delivered_at is distinct from old.delivered_at then
      raise exception 'Campo protegido: não pode ser alterado diretamente';
    end if;
    if public.app_role() = 'washer' then
      if new.employee_id is distinct from old.employee_id or new.notes is distinct from old.notes then
        raise exception 'Lavador só pode atualizar o andamento';
      end if;
      if new.status is distinct from old.status and new.status not in ('in_progress','done') then
        raise exception 'Lavador só pode iniciar ou concluir o serviço';
      end if;
    end if;
  end if;
  return new;
end $$;

create trigger trg_orders_guard before update on public.orders
for each row execute function public.guard_order_update();

-- Auditoria
create or replace function public.audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
declare r jsonb := to_jsonb(coalesce(new, old));
begin
  insert into public.audit_log(establishment_id, user_id, table_name, record_id, action, data)
  values ((r->>'establishment_id')::uuid, auth.uid(), tg_table_name, r->>'id', tg_op, r);
  return coalesce(new, old);
end $$;

create trigger trg_audit_orders after insert or update or delete on public.orders
for each row execute function public.audit_row();
create trigger trg_audit_payments after insert or update or delete on public.payments
for each row execute function public.audit_row();
create trigger trg_audit_expenses after insert or update or delete on public.expenses
for each row execute function public.audit_row();

-- ---------- Segurança em nível de linha (RLS) ----------

alter table public.establishments enable row level security;
alter table public.profiles       enable row level security;
alter table public.customers      enable row level security;
alter table public.vehicles       enable row level security;
alter table public.services       enable row level security;
alter table public.orders         enable row level security;
alter table public.order_items    enable row level security;
alter table public.payments       enable row level security;
alter table public.expenses       enable row level security;
alter table public.audit_log      enable row level security;

-- establishments
create policy est_select on public.establishments for select to authenticated
  using (id = public.current_establishment());
create policy est_update on public.establishments for update to authenticated
  using (id = public.current_establishment() and public.app_role() = 'admin')
  with check (id = public.current_establishment());

-- profiles
create policy prof_select on public.profiles for select to authenticated
  using (establishment_id = public.current_establishment());
-- Uma única política de UPDATE. (Políticas permissivas se combinam com OR, inclusive
-- no WITH CHECK; duas políticas separadas permitiam a um funcionário se promover a admin.)
create policy prof_update on public.profiles for update to authenticated
  using (establishment_id = public.current_establishment()
         and (id = auth.uid() or public.app_role() = 'admin'))
  with check (establishment_id = public.current_establishment()
         and (public.app_role() = 'admin' or (id = auth.uid() and role = public.app_role())));

-- customers e vehicles
create policy cust_select on public.customers for select to authenticated
  using (establishment_id = public.current_establishment());
create policy cust_write on public.customers for all to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'))
  with check (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'));

create policy veh_select on public.vehicles for select to authenticated
  using (establishment_id = public.current_establishment());
create policy veh_write on public.vehicles for all to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'))
  with check (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'));

-- services
create policy svc_select on public.services for select to authenticated
  using (establishment_id = public.current_establishment());
create policy svc_write on public.services for all to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'))
  with check (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'));

-- orders: o cliente do app só LÊ e atualiza o andamento; criação e pagamento
-- passam exclusivamente pelas funções create_order e register_payment.
create policy ord_select on public.orders for select to authenticated
  using (establishment_id = public.current_establishment());
create policy ord_update on public.orders for update to authenticated
  using (establishment_id = public.current_establishment()
         and (public.app_role() in ('admin','manager','attendant')
              or (public.app_role() = 'washer' and employee_id = auth.uid())))
  with check (establishment_id = public.current_establishment());

-- order_items e payments: somente leitura direta
create policy item_select on public.order_items for select to authenticated
  using (establishment_id = public.current_establishment());
create policy pay_select on public.payments for select to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'));

-- expenses
create policy exp_select on public.expenses for select to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'));
create policy exp_write on public.expenses for all to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'))
  with check (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'));

-- audit_log: somente leitura para administradores
create policy audit_select on public.audit_log for select to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() = 'admin');

-- ---------- Funções expostas ao aplicativo ----------

-- Cria o estabelecimento do primeiro acesso e torna o usuário administrador.
create or replace function public.create_establishment(p_name text, p_full_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_est uuid;
begin
  if auth.uid() is null then raise exception 'Não autenticado'; end if;
  if exists (select 1 from public.profiles where id = auth.uid()) then
    raise exception 'Usuário já possui estabelecimento';
  end if;
  if char_length(trim(coalesce(p_name,''))) < 2 then raise exception 'Nome do estabelecimento inválido'; end if;
  if char_length(trim(coalesce(p_full_name,''))) < 2 then raise exception 'Seu nome é obrigatório'; end if;
  insert into public.establishments(name) values (trim(p_name)) returning id into v_est;
  insert into public.profiles(id, establishment_id, full_name, role)
  values (auth.uid(), v_est, trim(p_full_name), 'admin');
  return v_est;
end $$;

-- Cria a O.S. completa em uma única transação, com validação no servidor
-- e proteção contra envio duplicado (client_id).
create or replace function public.create_order(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_est uuid := public.current_establishment();
  v_client uuid := nullif(p->>'client_id','')::uuid;
  v_order public.orders;
  v_customer uuid;
  v_vehicle uuid;
  v_plate text;
  v_employee uuid := nullif(p->>'employee_id','')::uuid;
  v_item jsonb;
  v_qty int; v_price numeric; v_disc numeric;
  v_subtotal numeric := 0;
  v_discount numeric := 0;
begin
  if v_est is null then raise exception 'Usuário sem estabelecimento'; end if;
  if public.app_role() not in ('admin','manager','attendant') then
    raise exception 'Sem permissão para criar O.S.';
  end if;
  if v_client is null then raise exception 'client_id obrigatório'; end if;

  select * into v_order from public.orders where establishment_id = v_est and client_id = v_client;
  if found then
    return jsonb_build_object('id', v_order.id, 'number', v_order.number,
                              'public_token', v_order.public_token, 'duplicate', true);
  end if;

  if jsonb_typeof(p->'items') is distinct from 'array' or jsonb_array_length(p->'items') = 0 then
    raise exception 'Selecione ao menos um serviço';
  end if;

  v_plate := upper(regexp_replace(coalesce(p->'vehicle'->>'plate',''), '[^A-Za-z0-9]', '', 'g'));
  if v_plate !~ '^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$' then raise exception 'Placa inválida'; end if;
  if char_length(trim(coalesce(p->'vehicle'->>'model',''))) < 1 then raise exception 'Modelo do veículo obrigatório'; end if;

  if v_employee is not null then
    perform 1 from public.profiles where id = v_employee and establishment_id = v_est;
    if not found then raise exception 'Funcionário inválido'; end if;
  end if;

  -- Cliente
  if nullif(p->'customer'->>'id','') is not null then
    select id into v_customer from public.customers
     where id = (p->'customer'->>'id')::uuid and establishment_id = v_est;
    if v_customer is null then raise exception 'Cliente não encontrado'; end if;
  else
    if char_length(trim(coalesce(p->'customer'->>'name',''))) < 2 then
      raise exception 'Nome do cliente obrigatório';
    end if;
    insert into public.customers(establishment_id, name, phone)
    values (v_est, trim(p->'customer'->>'name'),
            nullif(regexp_replace(coalesce(p->'customer'->>'phone',''), '\D', '', 'g'), ''))
    returning id into v_customer;
  end if;

  -- Veículo (cria ou atualiza pela placa)
  insert into public.vehicles(establishment_id, customer_id, plate, brand, model, color, type)
  values (v_est, v_customer, v_plate,
          nullif(trim(coalesce(p->'vehicle'->>'brand','')),''),
          trim(p->'vehicle'->>'model'),
          nullif(trim(coalesce(p->'vehicle'->>'color','')),''),
          coalesce(nullif(p->'vehicle'->>'type',''),'car'))
  on conflict (establishment_id, plate) do update
    set customer_id = excluded.customer_id, brand = excluded.brand, model = excluded.model,
        color = excluded.color, type = excluded.type
  returning id into v_vehicle;

  -- Totais calculados no servidor
  for v_item in select jsonb_array_elements(p->'items') loop
    v_qty := (v_item->>'quantity')::int;
    v_price := (v_item->>'unit_price')::numeric;
    v_disc := coalesce((v_item->>'discount')::numeric, 0);
    if v_qty < 1 or v_qty > 99 then raise exception 'Quantidade inválida'; end if;
    if v_price < 0 or v_disc < 0 or v_disc > v_qty * v_price then raise exception 'Valores inválidos'; end if;
    perform 1 from public.services
     where id = (v_item->>'service_id')::uuid and establishment_id = v_est;
    if not found then raise exception 'Serviço não encontrado'; end if;
    v_subtotal := v_subtotal + v_qty * v_price;
    v_discount := v_discount + v_disc;
  end loop;

  insert into public.orders(establishment_id, vehicle_id, customer_id, employee_id, notes,
                            subtotal, discount, total, client_id, created_by)
  values (v_est, v_vehicle, v_customer, v_employee, nullif(trim(coalesce(p->>'notes','')),''),
          v_subtotal, v_discount, v_subtotal - v_discount, v_client, auth.uid())
  returning * into v_order;

  insert into public.order_items(order_id, establishment_id, service_id, name, quantity, unit_price, discount)
  select v_order.id, v_est, s.id, s.name, (i->>'quantity')::int, (i->>'unit_price')::numeric,
         coalesce((i->>'discount')::numeric, 0)
    from jsonb_array_elements(p->'items') i
    join public.services s on s.id = (i->>'service_id')::uuid and s.establishment_id = v_est;

  return jsonb_build_object('id', v_order.id, 'number', v_order.number,
                            'public_token', v_order.public_token, 'duplicate', false);
end $$;

-- Registra pagamento com proteção contra duplicidade (client_id).
create or replace function public.register_payment(p_order uuid, p_method text, p_amount numeric, p_client_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_est uuid := public.current_establishment();
  v_order public.orders;
  v_paid numeric;
begin
  if v_est is null or public.app_role() not in ('admin','manager','attendant') then
    raise exception 'Sem permissão para registrar pagamento';
  end if;
  if exists (select 1 from public.payments where establishment_id = v_est and client_id = p_client_id) then
    return jsonb_build_object('duplicate', true);
  end if;
  select * into v_order from public.orders where id = p_order and establishment_id = v_est for update;
  if not found then raise exception 'O.S. não encontrada'; end if;
  if v_order.status = 'cancelled' then raise exception 'O.S. cancelada'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Valor inválido'; end if;

  select coalesce(sum(amount), 0) into v_paid from public.payments where order_id = p_order;
  if v_paid + p_amount > v_order.total + 0.009 then raise exception 'Valor maior que o saldo da O.S.'; end if;

  insert into public.payments(establishment_id, order_id, method, amount, client_id, created_by)
  values (v_est, p_order, p_method, p_amount, p_client_id, auth.uid());

  v_paid := v_paid + p_amount;
  if v_paid >= v_order.total - 0.009 then
    update public.orders
       set payment_status = 'paid',
           status = case when status = 'awaiting_payment' then 'ready' else status end
     where id = p_order;
  end if;
  return jsonb_build_object('duplicate', false, 'paid', v_paid, 'total', v_order.total);
end $$;

-- Página pública de acompanhamento (QR Code). Expõe só o mínimo, por token.
create or replace function public.public_order_status(p_token uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'number', o.number,
    'status', o.status,
    'created_at', o.created_at,
    'establishment', e.name,
    'plate_hint', right(v.plate, 3),
    'model', v.model,
    'services', coalesce((select jsonb_agg(i.name) from public.order_items i where i.order_id = o.id), '[]'::jsonb)
  )
  from public.orders o
  join public.establishments e on e.id = o.establishment_id
  join public.vehicles v on v.id = o.vehicle_id
  where o.public_token = p_token
$$;

-- Permissões de execução
revoke all on function public.create_establishment(text, text) from public, anon;
revoke all on function public.create_order(jsonb) from public, anon;
revoke all on function public.register_payment(uuid, text, numeric, uuid) from public, anon;
grant execute on function public.create_establishment(text, text) to authenticated;
grant execute on function public.create_order(jsonb) to authenticated;
grant execute on function public.register_payment(uuid, text, numeric, uuid) to authenticated;
grant execute on function public.public_order_status(uuid) to anon, authenticated;
