-- ============================================================
-- LAVA PRO - Migração da Fase 2
-- Execute DEPOIS de supabase/schema.sql, uma única vez.
-- Cola tudo no SQL Editor do Supabase e clique em Run.
-- ============================================================

-- ---------- Perfis e estabelecimento: novos campos ----------

alter table public.profiles
  add column phone text,
  add column salary numeric(10,2) check (salary is null or salary >= 0),
  add column commission_pct numeric(5,2) not null default 0 check (commission_pct between 0 and 100),
  add column active boolean not null default true;

alter table public.establishments
  add column phone text,
  add column address text,
  add column document text,
  add column receipt_footer text;

alter table public.orders add column stock_consumed boolean not null default false;

-- Usuário desativado perde o acesso a tudo
create or replace function public.current_establishment() returns uuid
language sql stable security definer set search_path = public as $$
  select establishment_id from public.profiles where id = auth.uid() and active
$$;

create or replace function public.app_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() and active
$$;

-- Perfil do usuário logado (funciona mesmo se estiver desativado, para o app avisar)
create or replace function public.my_profile() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'id', p.id, 'establishment_id', p.establishment_id, 'full_name', p.full_name,
    'role', p.role, 'active', p.active, 'phone', p.phone,
    'establishment', e.name, 'establishment_phone', e.phone,
    'establishment_address', e.address, 'establishment_document', e.document,
    'receipt_footer', e.receipt_footer)
  from public.profiles p join public.establishments e on e.id = p.establishment_id
  where p.id = auth.uid()
$$;

-- ---------- Permissões de tabela: escrita só pelas funções do servidor ----------

revoke insert, update, delete on public.profiles from authenticated;
revoke insert, delete, update on public.establishments from authenticated;
grant update (name, phone, address, document, receipt_footer) on public.establishments to authenticated;
revoke insert, delete, update on public.orders from authenticated;
grant update (status, employee_id, notes) on public.orders to authenticated;
revoke insert, update, delete on public.order_items from authenticated;
revoke insert, update, delete on public.payments from authenticated;
revoke insert, update, delete on public.audit_log from authenticated;

-- Lavador só enxerga o que é dele; dados de clientes só para quem atende
drop policy ord_select on public.orders;
create policy ord_select on public.orders for select to authenticated
  using (establishment_id = public.current_establishment()
         and (public.app_role() in ('admin','manager','attendant') or employee_id = auth.uid()));

drop policy item_select on public.order_items;
create policy item_select on public.order_items for select to authenticated
  using (establishment_id = public.current_establishment()
         and (public.app_role() in ('admin','manager','attendant')
              or exists (select 1 from public.orders o where o.id = order_id and o.employee_id = auth.uid())));

drop policy cust_select on public.customers;
create policy cust_select on public.customers for select to authenticated
  using (establishment_id = public.current_establishment()
         and public.app_role() in ('admin','manager','attendant'));

drop policy prof_update on public.profiles;

-- ---------- Convites e gestão da equipe ----------

create table public.invites (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  code text not null unique,
  role text not null check (role in ('manager','attendant','washer')),
  full_name text not null check (char_length(full_name) between 2 and 80),
  phone text,
  salary numeric(10,2) check (salary is null or salary >= 0),
  commission_pct numeric(5,2) not null default 0 check (commission_pct between 0 and 100),
  expires_at timestamptz not null default now() + interval '7 days',
  used_by uuid references auth.users(id),
  used_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index invites_est_idx on public.invites(establishment_id);
alter table public.invites enable row level security;
create policy inv_select on public.invites for select to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'));
create policy inv_delete on public.invites for delete to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager') and used_at is null);
revoke insert, update on public.invites from authenticated;

create or replace function public.create_invite(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_est uuid := public.current_establishment();
  v_role text := public.app_role();
  v_new text := p->>'role';
  v_code text; v_id uuid;
begin
  if v_est is null or v_role not in ('admin','manager') then raise exception 'Sem permissão'; end if;
  if v_new not in ('manager','attendant','washer') then raise exception 'Perfil inválido'; end if;
  if v_role = 'manager' and v_new = 'manager' then raise exception 'Gerente não pode convidar outro gerente'; end if;
  if char_length(trim(coalesce(p->>'full_name',''))) < 2 then raise exception 'Nome obrigatório'; end if;
  loop
    v_code := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8));
    exit when not exists (select 1 from public.invites where code = v_code);
  end loop;
  insert into public.invites(establishment_id, code, role, full_name, phone, salary, commission_pct, created_by)
  values (v_est, v_code, v_new, trim(p->>'full_name'),
          nullif(regexp_replace(coalesce(p->>'phone',''), '\D', '', 'g'), ''),
          case when v_role = 'admin' then nullif(p->>'salary','')::numeric end,
          case when v_role = 'admin' then coalesce(nullif(p->>'commission_pct','')::numeric, 0) else 0 end,
          auth.uid())
  returning id into v_id;
  return jsonb_build_object('id', v_id, 'code', v_code);
end $$;

create or replace function public.join_establishment(p_code text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v public.invites;
begin
  if auth.uid() is null then raise exception 'Não autenticado'; end if;
  if exists (select 1 from public.profiles where id = auth.uid()) then
    raise exception 'Usuário já possui estabelecimento';
  end if;
  select * into v from public.invites
   where code = upper(trim(coalesce(p_code, ''))) and used_at is null and expires_at > now()
   for update;
  if not found then raise exception 'Código inválido ou expirado'; end if;
  insert into public.profiles(id, establishment_id, full_name, role, phone, salary, commission_pct)
  values (auth.uid(), v.establishment_id, v.full_name, v.role, v.phone, v.salary, v.commission_pct);
  update public.invites set used_by = auth.uid(), used_at = now() where id = v.id;
  return jsonb_build_object('establishment_id', v.establishment_id);
end $$;

create or replace function public.update_employee(p_id uuid, p jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_est uuid := public.current_establishment();
  t public.profiles;
begin
  if v_est is null or public.app_role() <> 'admin' then raise exception 'Somente o administrador pode alterar funcionários'; end if;
  select * into t from public.profiles where id = p_id and establishment_id = v_est;
  if not found then raise exception 'Funcionário não encontrado'; end if;
  if p_id = auth.uid() and (p ? 'role' or p ? 'active') then
    raise exception 'Você não pode alterar seu próprio perfil ou status';
  end if;
  if p ? 'role' and p->>'role' not in ('manager','attendant','washer') then raise exception 'Perfil inválido'; end if;
  update public.profiles set
    full_name = coalesce(nullif(trim(p->>'full_name'), ''), full_name),
    phone = case when p ? 'phone' then nullif(regexp_replace(coalesce(p->>'phone',''), '\D', '', 'g'), '') else phone end,
    salary = case when p ? 'salary' then nullif(p->>'salary','')::numeric else salary end,
    commission_pct = case when p ? 'commission_pct' then coalesce(nullif(p->>'commission_pct','')::numeric, 0) else commission_pct end,
    role = case when p ? 'role' then p->>'role' else role end,
    active = case when p ? 'active' then (p->>'active')::boolean else active end
  where id = p_id;
end $$;

create or replace function public.update_my_profile(p_name text, p_phone text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Não autenticado'; end if;
  if char_length(trim(coalesce(p_name,''))) < 2 then raise exception 'Nome inválido'; end if;
  update public.profiles
     set full_name = trim(p_name),
         phone = nullif(regexp_replace(coalesce(p_phone,''), '\D', '', 'g'), '')
   where id = auth.uid() and active;
end $$;

-- ---------- Estoque ----------

create table public.products (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  unit text not null default 'un' check (char_length(unit) between 1 and 12),
  cost numeric(10,2) not null default 0 check (cost >= 0),
  supplier text,
  min_qty numeric(12,3) not null default 0 check (min_qty >= 0),
  qty numeric(12,3) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create index products_est_idx on public.products(establishment_id);

create table public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  kind text not null check (kind in ('in','out','adjust')),
  qty numeric(12,3) not null,
  unit_cost numeric(10,2),
  reason text,
  order_id uuid references public.orders(id) on delete set null,
  client_id uuid not null,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique (establishment_id, client_id)
);
create index stock_mov_prod_idx on public.stock_movements(product_id, created_at desc);

create table public.service_products (
  service_id uuid not null references public.services(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  qty numeric(12,3) not null check (qty > 0),
  primary key (service_id, product_id)
);

-- ---------- Avisos ----------

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  kind text not null,
  title text not null,
  body text,
  ref_id uuid,
  read_by uuid[] not null default '{}',
  created_at timestamptz not null default now()
);
create index notif_est_idx on public.notifications(establishment_id, created_at desc);

-- Baixa/entrada de estoque (uso interno, não exposta ao app)
create or replace function public.internal_apply_stock(
  p_est uuid, p_product uuid, p_kind text, p_qty numeric, p_cost numeric,
  p_reason text, p_order uuid, p_client uuid, p_user uuid) returns void
language plpgsql security definer set search_path = public as $$
declare v_old numeric; v_new numeric; v_min numeric; v_name text; v_delta numeric;
begin
  if p_kind in ('in','out') and coalesce(p_qty, 0) <= 0 then raise exception 'Quantidade deve ser maior que zero'; end if;
  if p_kind = 'adjust' and coalesce(p_qty, 0) = 0 then raise exception 'Ajuste não pode ser zero'; end if;
  select qty, min_qty, name into v_old, v_min, v_name
    from public.products where id = p_product and establishment_id = p_est for update;
  if not found then raise exception 'Produto não encontrado'; end if;
  v_delta := case p_kind when 'out' then -p_qty else p_qty end;
  v_new := v_old + v_delta;
  insert into public.stock_movements(establishment_id, product_id, kind, qty, unit_cost, reason, order_id, client_id, created_by)
  values (p_est, p_product, p_kind, p_qty, p_cost, p_reason, p_order, p_client, p_user);
  update public.products
     set qty = v_new,
         cost = case when p_kind = 'in' and p_cost is not null then p_cost else cost end
   where id = p_product;
  if v_old > v_min and v_new <= v_min then
    insert into public.notifications(establishment_id, kind, title, body, ref_id)
    values (p_est, 'low_stock', 'Estoque baixo: ' || v_name,
            'Restam ' || v_new::text || ' (mínimo ' || v_min::text || ')', p_product);
  end if;
end $$;

create or replace function public.stock_move(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_est uuid := public.current_establishment();
  v_client uuid := nullif(p->>'client_id','')::uuid;
begin
  if v_est is null or public.app_role() not in ('admin','manager') then raise exception 'Sem permissão para movimentar estoque'; end if;
  if v_client is null then raise exception 'client_id obrigatório'; end if;
  if p->>'kind' not in ('in','out','adjust') then raise exception 'Tipo de movimentação inválido'; end if;
  if exists (select 1 from public.stock_movements where establishment_id = v_est and client_id = v_client) then
    return jsonb_build_object('duplicate', true);
  end if;
  perform public.internal_apply_stock(v_est, (p->>'product_id')::uuid, p->>'kind', (p->>'qty')::numeric,
          nullif(p->>'unit_cost','')::numeric, nullif(trim(coalesce(p->>'reason','')), ''), null, v_client, auth.uid());
  return jsonb_build_object('duplicate', false);
end $$;

-- Baixa automática ao concluir o serviço (uma única vez por O.S.)
create or replace function public.consume_order_stock() returns trigger
language plpgsql security definer set search_path = public as $$
declare r record;
begin
  if not new.stock_consumed
     and new.status in ('done','awaiting_payment','ready','delivered')
     and old.status in ('waiting','in_progress') then
    for r in
      select sp.product_id, sp.qty * oi.quantity as q
        from public.order_items oi
        join public.service_products sp on sp.service_id = oi.service_id
       where oi.order_id = new.id
    loop
      perform public.internal_apply_stock(new.establishment_id, r.product_id, 'out', r.q, null,
              'O.S. #' || new.number::text, new.id, gen_random_uuid(), auth.uid());
    end loop;
    update public.orders set stock_consumed = true where id = new.id;
  end if;
  return null;
end $$;
create trigger trg_orders_consume after update of status on public.orders
for each row execute function public.consume_order_stock();

create or replace function public.notify_awaiting_payment() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_plate text;
begin
  if new.status = 'awaiting_payment' and old.status is distinct from 'awaiting_payment' then
    select plate into v_plate from public.vehicles where id = new.vehicle_id;
    insert into public.notifications(establishment_id, kind, title, body, ref_id)
    values (new.establishment_id, 'awaiting_payment', 'Aguardando pagamento',
            'O.S. #' || new.number::text || ' · ' || coalesce(v_plate, ''), new.id);
  end if;
  return null;
end $$;
create trigger trg_orders_notify after update of status on public.orders
for each row execute function public.notify_awaiting_payment();

create or replace function public.mark_notifications_read() returns void
language sql security definer set search_path = public as $$
  update public.notifications
     set read_by = array_append(read_by, auth.uid())
   where establishment_id = public.current_establishment()
     and not (auth.uid() = any(read_by))
$$;

-- ---------- Despesas: forma de pagamento e categorias ----------

alter table public.expenses
  add column method text not null default 'cash' check (method in ('cash','pix','credit','debit','other')),
  add constraint expenses_category_check
    check (category in ('products','employees','water','energy','rent','maintenance','equipment','other'));

-- ---------- Caixa e estornos ----------

create table public.cash_sessions (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  opened_by uuid references auth.users(id),
  opened_at timestamptz not null default now(),
  opening_amount numeric(10,2) not null check (opening_amount >= 0),
  closed_by uuid references auth.users(id),
  closed_at timestamptz,
  counted_amount numeric(10,2),
  expected_amount numeric(10,2),
  difference numeric(10,2),
  notes text
);
create unique index cash_one_open_idx on public.cash_sessions(establishment_id) where closed_at is null;
create index cash_est_idx on public.cash_sessions(establishment_id, opened_at desc);

alter table public.payments
  add column refunded_at timestamptz,
  add column refunded_by uuid references auth.users(id),
  add column refund_reason text;

-- Resumo do caixa aberto (todos os valores calculados no servidor)
create or replace function public.cash_summary() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  v_est uuid := public.current_establishment();
  s public.cash_sessions;
  v_cash_in numeric; v_refunds numeric; v_exp numeric; v_methods jsonb;
begin
  if v_est is null or public.app_role() not in ('admin','manager','attendant') then raise exception 'Sem permissão'; end if;
  select * into s from public.cash_sessions where establishment_id = v_est and closed_at is null;
  if not found then return jsonb_build_object('open', false); end if;
  select coalesce(sum(amount), 0) into v_cash_in from public.payments
   where establishment_id = v_est and method = 'cash' and created_at >= s.opened_at;
  select coalesce(sum(amount), 0) into v_refunds from public.payments
   where establishment_id = v_est and method = 'cash' and refunded_at >= s.opened_at;
  select coalesce(sum(amount), 0) into v_exp from public.expenses
   where establishment_id = v_est and method = 'cash' and created_at >= s.opened_at;
  select coalesce(jsonb_agg(jsonb_build_object('method', method, 'amount', amt) order by amt desc), '[]'::jsonb)
    into v_methods
    from (select method, sum(amount) as amt from public.payments
           where establishment_id = v_est and created_at >= s.opened_at and refunded_at is null
           group by method) m;
  return jsonb_build_object(
    'open', true, 'id', s.id, 'opened_at', s.opened_at, 'opening_amount', s.opening_amount,
    'cash_in', v_cash_in, 'cash_refunds', v_refunds, 'cash_expenses', v_exp,
    'expected', s.opening_amount + v_cash_in - v_refunds - v_exp,
    'by_method', v_methods);
end $$;

create or replace function public.open_cash(p_amount numeric) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_est uuid := public.current_establishment(); v_id uuid;
begin
  if v_est is null or public.app_role() not in ('admin','manager','attendant') then raise exception 'Sem permissão para abrir o caixa'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'Valor inicial inválido'; end if;
  if exists (select 1 from public.cash_sessions where establishment_id = v_est and closed_at is null) then
    raise exception 'Já existe um caixa aberto';
  end if;
  insert into public.cash_sessions(establishment_id, opened_by, opening_amount)
  values (v_est, auth.uid(), p_amount) returning id into v_id;
  return v_id;
end $$;

create or replace function public.close_cash(p_counted numeric, p_notes text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_est uuid := public.current_establishment(); sm jsonb; v_expected numeric;
begin
  if v_est is null or public.app_role() not in ('admin','manager','attendant') then raise exception 'Sem permissão para fechar o caixa'; end if;
  if p_counted is null or p_counted < 0 then raise exception 'Valor contado inválido'; end if;
  sm := public.cash_summary();
  if not (sm->>'open')::boolean then raise exception 'Não há caixa aberto'; end if;
  v_expected := (sm->>'expected')::numeric;
  update public.cash_sessions
     set closed_at = now(), closed_by = auth.uid(), counted_amount = p_counted,
         expected_amount = v_expected, difference = p_counted - v_expected,
         notes = nullif(trim(coalesce(p_notes, '')), '')
   where id = (sm->>'id')::uuid;
  return jsonb_build_object('expected', v_expected, 'counted', p_counted, 'difference', p_counted - v_expected);
end $$;

-- Estorno de pagamento (gerente/admin)
create or replace function public.refund_payment(p_payment uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_est uuid := public.current_establishment();
  pay public.payments; o public.orders; v_paid numeric;
begin
  if v_est is null or public.app_role() not in ('admin','manager') then raise exception 'Somente gerente ou administrador pode estornar'; end if;
  if char_length(trim(coalesce(p_reason, ''))) < 3 then raise exception 'Informe o motivo do estorno'; end if;
  select * into pay from public.payments where id = p_payment and establishment_id = v_est for update;
  if not found then raise exception 'Pagamento não encontrado'; end if;
  if pay.refunded_at is not null then raise exception 'Pagamento já estornado'; end if;
  update public.payments
     set refunded_at = now(), refunded_by = auth.uid(), refund_reason = trim(p_reason)
   where id = p_payment;
  select * into o from public.orders where id = pay.order_id for update;
  select coalesce(sum(amount), 0) into v_paid from public.payments where order_id = o.id and refunded_at is null;
  if v_paid < o.total - 0.009 then
    update public.orders set payment_status = 'pending' where id = o.id;
  end if;
end $$;

-- register_payment: agora ignora pagamentos estornados no saldo
create or replace function public.register_payment(p_order uuid, p_method text, p_amount numeric, p_client_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_est uuid := public.current_establishment();
  v_order public.orders;
  v_paid numeric;
begin
  if v_est is null or public.app_role() not in ('admin','manager','attendant') then
    raise exception 'Sem permissão para registrar pagamento';
  end if;
  if p_method not in ('cash','pix','credit','debit','other') then raise exception 'Forma de pagamento inválida'; end if;
  if exists (select 1 from public.payments where establishment_id = v_est and client_id = p_client_id) then
    return jsonb_build_object('duplicate', true);
  end if;
  select * into v_order from public.orders where id = p_order and establishment_id = v_est for update;
  if not found then raise exception 'O.S. não encontrada'; end if;
  if v_order.status = 'cancelled' then raise exception 'O.S. cancelada'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Valor inválido'; end if;

  select coalesce(sum(amount), 0) into v_paid from public.payments where order_id = p_order and refunded_at is null;
  if v_paid + p_amount > v_order.total + 0.009 then raise exception 'Valor maior que o saldo da O.S.'; end if;

  insert into public.payments(establishment_id, order_id, method, amount, client_id, created_by)
  values (v_est, p_order, p_method, p_amount, p_client_id, auth.uid());

  v_paid := v_paid + p_amount;
  if v_paid >= v_order.total - 0.009 then
    update public.orders
       set payment_status = 'paid',
           status = case when status = 'awaiting_payment' then 'ready' else status end
     where id = p_order;
  end if;
  return jsonb_build_object('duplicate', false, 'paid', v_paid, 'total', v_order.total);
end $$;

-- ---------- Agendamentos ----------

create table public.appointments (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  customer_name text not null check (char_length(customer_name) between 2 and 80),
  phone text,
  plate text check (plate is null or plate ~ '^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$'),
  model text,
  service_id uuid references public.services(id) on delete set null,
  scheduled_at timestamptz not null,
  notes text,
  status text not null default 'scheduled' check (status in ('scheduled','done','cancelled','no_show')),
  order_id uuid references public.orders(id) on delete set null,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index appt_est_idx on public.appointments(establishment_id, scheduled_at);

-- ---------- Fotos das O.S. ----------

create table public.order_photos (
  id uuid primary key default gen_random_uuid(),
  establishment_id uuid not null references public.establishments(id) on delete cascade,
  order_id uuid not null references public.orders(id) on delete cascade,
  path text not null unique,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index photos_order_idx on public.order_photos(order_id);

-- ---------- RLS das novas tabelas ----------

alter table public.products         enable row level security;
alter table public.stock_movements  enable row level security;
alter table public.service_products enable row level security;
alter table public.notifications    enable row level security;
alter table public.cash_sessions    enable row level security;
alter table public.appointments     enable row level security;
alter table public.order_photos     enable row level security;

create policy prod_select on public.products for select to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'));
create policy prod_insert on public.products for insert to authenticated
  with check (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager') and qty = 0);
create policy prod_update on public.products for update to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'))
  with check (establishment_id = public.current_establishment());
revoke update on public.products from authenticated;
grant update (name, unit, cost, supplier, min_qty, active) on public.products to authenticated;
revoke delete on public.products from authenticated;

create policy mov_select on public.stock_movements for select to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'));
revoke insert, update, delete on public.stock_movements from authenticated;

create policy sp_select on public.service_products for select to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'));
create policy sp_write on public.service_products for all to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'))
  with check (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager')
              and exists (select 1 from public.services s where s.id = service_id and s.establishment_id = public.current_establishment())
              and exists (select 1 from public.products p where p.id = product_id and p.establishment_id = public.current_establishment()));

create policy notif_select on public.notifications for select to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'));
revoke insert, update, delete on public.notifications from authenticated;

create policy cash_select on public.cash_sessions for select to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'));
revoke insert, update, delete on public.cash_sessions from authenticated;

create policy appt_select on public.appointments for select to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'));
create policy appt_write on public.appointments for all to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'))
  with check (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager','attendant'));

create policy photo_select on public.order_photos for select to authenticated
  using (establishment_id = public.current_establishment()
         and (public.app_role() in ('admin','manager','attendant')
              or exists (select 1 from public.orders o where o.id = order_id and o.employee_id = auth.uid())));
create policy photo_insert on public.order_photos for insert to authenticated
  with check (establishment_id = public.current_establishment()
              and path like public.current_establishment()::text || '/%'
              and exists (select 1 from public.orders o
                           where o.id = order_id
                             and o.establishment_id = public.current_establishment()
                             and (public.app_role() in ('admin','manager','attendant') or o.employee_id = auth.uid())));
create policy photo_delete on public.order_photos for delete to authenticated
  using (establishment_id = public.current_establishment() and public.app_role() in ('admin','manager'));
revoke update on public.order_photos from authenticated;

-- Storage das fotos (bucket privado; pasta = id do estabelecimento)
insert into storage.buckets (id, name, public) values ('order-photos', 'order-photos', false)
on conflict (id) do nothing;

create policy photos_obj_select on storage.objects for select to authenticated
  using (bucket_id = 'order-photos' and (storage.foldername(name))[1] = public.current_establishment()::text);
create policy photos_obj_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'order-photos' and (storage.foldername(name))[1] = public.current_establishment()::text);
create policy photos_obj_delete on storage.objects for delete to authenticated
  using (bucket_id = 'order-photos' and (storage.foldername(name))[1] = public.current_establishment()::text
         and public.app_role() in ('admin','manager'));

-- ---------- Relatórios ----------

create or replace function public.report_summary(p_from timestamptz, p_to timestamptz) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_est uuid := public.current_establishment(); r jsonb;
begin
  if v_est is null or public.app_role() not in ('admin','manager') then raise exception 'Sem permissão'; end if;
  if p_from is null or p_to is null or p_to <= p_from then raise exception 'Período inválido'; end if;
  select jsonb_build_object(
    'orders', (select count(*) from public.orders
                where establishment_id = v_est and status <> 'cancelled' and created_at >= p_from and created_at < p_to),
    'billed', (select coalesce(sum(total), 0) from public.orders
                where establishment_id = v_est and status <> 'cancelled' and created_at >= p_from and created_at < p_to),
    'received',
      (select coalesce(sum(amount), 0) from public.payments
        where establishment_id = v_est and created_at >= p_from and created_at < p_to)
      - (select coalesce(sum(amount), 0) from public.payments
          where establishment_id = v_est and refunded_at >= p_from and refunded_at < p_to),
    'expenses', (select coalesce(sum(amount), 0) from public.expenses
                  where establishment_id = v_est and created_at >= p_from and created_at < p_to),
    'pending', (select coalesce(sum(o.total - coalesce(pp.paid, 0)), 0)
                  from public.orders o
                  left join (select order_id, sum(amount) as paid from public.payments
                              where refunded_at is null group by order_id) pp on pp.order_id = o.id
                 where o.establishment_id = v_est and o.status <> 'cancelled' and o.payment_status = 'pending'
                   and o.created_at >= p_from and o.created_at < p_to),
    'by_method', coalesce((select jsonb_agg(jsonb_build_object('method', method, 'amount', amt) order by amt desc)
                  from (select method, sum(amount) as amt from public.payments
                         where establishment_id = v_est and refunded_at is null
                           and created_at >= p_from and created_at < p_to group by method) m), '[]'::jsonb),
    'top_services', coalesce((select jsonb_agg(jsonb_build_object('name', name, 'qty', qty, 'amount', amt) order by qty desc)
                  from (select oi.name, sum(oi.quantity) as qty, sum(oi.quantity * oi.unit_price - oi.discount) as amt
                          from public.order_items oi join public.orders o on o.id = oi.order_id
                         where o.establishment_id = v_est and o.status <> 'cancelled'
                           and o.created_at >= p_from and o.created_at < p_to
                         group by oi.name order by qty desc limit 10) t), '[]'::jsonb),
    'employees', coalesce((select jsonb_agg(jsonb_build_object(
                    'id', id, 'name', full_name, 'orders', orders, 'billed', billed,
                    'commission_pct', commission_pct, 'commission', commission) order by billed desc)
                  from (select p.id, p.full_name, p.commission_pct,
                               count(o.id) as orders,
                               coalesce(sum(o.total), 0) as billed,
                               round(coalesce(sum(case when o.payment_status = 'paid' then o.total else 0 end), 0)
                                     * p.commission_pct / 100, 2) as commission
                          from public.profiles p
                          left join public.orders o on o.employee_id = p.id and o.status <> 'cancelled'
                               and o.created_at >= p_from and o.created_at < p_to
                         where p.establishment_id = v_est and p.role in ('washer','attendant','manager')
                         group by p.id, p.full_name, p.commission_pct) e), '[]'::jsonb),
    'products', coalesce((select jsonb_agg(jsonb_build_object('name', name, 'unit', unit, 'qty', qty) order by qty desc)
                  from (select pr.name, pr.unit, sum(sm.qty) as qty
                          from public.stock_movements sm join public.products pr on pr.id = sm.product_id
                         where sm.establishment_id = v_est and sm.kind = 'out'
                           and sm.created_at >= p_from and sm.created_at < p_to
                         group by pr.name, pr.unit) q), '[]'::jsonb)
  ) into r;
  return r;
end $$;


-- ---------- Privacidade: salário e comissão não são legíveis por leitura direta ----------

revoke select on public.profiles from authenticated;
grant select (id, establishment_id, full_name, role, phone, active, created_at) on public.profiles to authenticated;

-- Lista da equipe: admin vê tudo; gerente vê sem salário/comissão
create or replace function public.list_employees() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_est uuid := public.current_establishment(); v_role text := public.app_role();
begin
  if v_est is null or v_role not in ('admin','manager') then raise exception 'Sem permissão'; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', p.id, 'full_name', p.full_name, 'role', p.role, 'phone', p.phone, 'active', p.active,
      'created_at', p.created_at,
      'salary', case when v_role = 'admin' then p.salary end,
      'commission_pct', case when v_role = 'admin' then p.commission_pct end)
      order by p.active desc, p.full_name)
    from public.profiles p where p.establishment_id = v_est), '[]'::jsonb);
end $$;

-- ---------- Auditoria das novas tabelas ----------

create trigger trg_audit_profiles after insert or update on public.profiles
for each row execute function public.audit_row();
create trigger trg_audit_products after insert or update on public.products
for each row execute function public.audit_row();
create trigger trg_audit_cash after insert or update on public.cash_sessions
for each row execute function public.audit_row();
create trigger trg_audit_movements after insert on public.stock_movements
for each row execute function public.audit_row();

-- ---------- Permissões de execução: só usuários logados (exceto a página pública) ----------

do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig, p.proname
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prokind = 'f'
  loop
    execute format('revoke all on function %s from public, anon', f.sig);
    if f.proname like 'internal\_%' then
      execute format('revoke all on function %s from authenticated', f.sig);
    else
      execute format('grant execute on function %s to authenticated', f.sig);
    end if;
  end loop;
end $$;
grant execute on function public.public_order_status(uuid) to anon, authenticated;
