#!/usr/bin/env bash
# Uso: ./run_tests.sh "<argumentos do psql, ex.: -h /tmp/sock -p 5432 -U postgres>"
# Cria um banco de teste descartável, aplica shim + schema + migração e roda as suítes.
set -euo pipefail
PSQL="psql ${1:-} -q"
DIR="$(cd "$(dirname "$0")" && pwd)"
$PSQL -d postgres -c 'drop database if exists lavapro_test' -c 'create database lavapro_test' 2>&1 | grep -v NOTICE || true
for f in "$DIR/supabase_shim.sql" "$DIR/../schema.sql" "$DIR/../migrations/002_fase2.sql"; do
  $PSQL -v ON_ERROR_STOP=1 -d lavapro_test -f "$f" >/dev/null
done
echo "schema + migração aplicados sem erros"
for t in security_test.sql fase2_test.sql; do
  echo "=== $t"
  $PSQL -d lavapro_test -f "$DIR/$t" 2>&1 | sed 's/^psql:[^ ]* //' | grep -E "FAIL|passaram|^ *[0-9]+ +\|" || true
done
