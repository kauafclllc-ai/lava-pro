-- Suíte da Fase 2. Rode depois de security_test.sql (usa o schema "tt" criado lá).
\set C '''aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'''
\set D '''bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'''
\set E '''cccccccc-cccc-cccc-cccc-cccccccccccc'''
\set F '''dddddddd-dddd-dddd-dddd-dddddddddddd'''
\set G '''eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee'''
\set su 'reset role;'
\set asC 'reset role; set role authenticated; do $$ begin perform set_config(''request.jwt.claim.sub'', ''aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'', false); end $$;'
\set asD 'reset role; set role authenticated; do $$ begin perform set_config(''request.jwt.claim.sub'', ''bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'', false); end $$;'
\set asE 'reset role; set role authenticated; do $$ begin perform set_config(''request.jwt.claim.sub'', ''cccccccc-cccc-cccc-cccc-cccccccccccc'', false); end $$;'
\set asF 'reset role; set role authenticated; do $$ begin perform set_config(''request.jwt.claim.sub'', ''dddddddd-dddd-dddd-dddd-dddddddddddd'', false); end $$;'
\set asG 'reset role; set role authenticated; do $$ begin perform set_config(''request.jwt.claim.sub'', ''eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee'', false); end $$;'

insert into auth.users(id,email) values (:C,'c@x'),(:D,'d@x'),(:E,'e@x'),(:F,'f@x'),(:G,'g@x');

\echo '=== FASE 2 / Equipe: convites'
:asC
select public.create_establishment('Lava C','Carla') is not null as c_criou;
select public.create_invite('{"role":"washer","full_name":"Dudu Lavador","phone":"(11) 90000-0001","salary":"1500","commission_pct":"10"}'::jsonb)->>'code' as cod_washer \gset
select public.create_invite('{"role":"attendant","full_name":"Eva Atendente"}'::jsonb)->>'code' as cod_att \gset
select tt.rows_eq($$select 1 from public.invites$$, 2, 'admin vê os convites pendentes');
select tt.must_fail($$select public.create_invite('{"role":"admin","full_name":"Fake Admin"}'::jsonb)$$, 'convite não pode criar admin');
:asG
select tt.must_fail($$select public.join_establishment('CODIGO00')$$, 'código inexistente é recusado');
:asD
select tt.must_ok($$select public.join_establishment('$$ || :'cod_washer' || $$')$$, 'D entra com o código de lavador');
select tt.val_eq($$select role from public.profiles where id = auth.uid()$$, 'washer', 'perfil criado com o papel do convite');
select tt.must_fail($$select salary from public.profiles where id = auth.uid()$$, 'lavador não lê salário nem do próprio perfil (coluna protegida)');
select tt.must_fail($$select commission_pct from public.profiles$$, 'lavador não lê comissão de ninguém (coluna protegida)');
:su
select tt.val_eq($$select role || '/' || commission_pct::text || '/' || salary::text from public.profiles where id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'$$, 'washer/10.00/1500.00', 'comissão e salário do convite gravados');
:asD
select tt.must_fail($$select public.join_establishment('$$ || :'cod_washer' || $$')$$, 'código já usado é recusado / usuário já tem perfil');
:asG
select tt.must_fail($$select public.join_establishment('$$ || :'cod_washer' || $$')$$, 'código usado não serve para outro usuário');
:asE
select tt.must_ok($$select public.join_establishment('  $$ || lower(:'cod_att') || $$ ')$$, 'E entra com o código (minúsculas e espaços ignorados)');
select tt.must_fail($$select public.create_invite('{"role":"washer","full_name":"Fulano"}'::jsonb)$$, 'atendente não cria convite');
select tt.rows_eq($$select 1 from public.invites$$, 0, 'atendente não vê convites');
:asC
select public.create_invite('{"role":"washer","full_name":"Expirado"}'::jsonb)->>'code' as cod_exp \gset
:su
update public.invites set expires_at = now() - interval '1 day' where code = :'cod_exp';
:asG
select tt.must_fail($$select public.join_establishment('$$ || :'cod_exp' || $$')$$, 'convite expirado é recusado');

\echo '=== Equipe: edição, ativação e limites'
:asD
select tt.must_fail($$update public.profiles set commission_pct = 100 where id = auth.uid()$$, 'lavador não altera a própria comissão (UPDATE direto)');
select tt.must_ok($$select public.update_my_profile('Dudu Silva','(11) 91111-2222')$$, 'lavador atualiza nome e telefone pela função');
select tt.val_eq($$select full_name from public.profiles where id = auth.uid()$$, 'Dudu Silva', 'nome atualizado');
:su
select tt.val_eq($$select commission_pct::text from public.profiles where id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'$$, '10.00', 'comissão intacta após o lavador atualizar o próprio perfil');
:asD
select tt.must_fail($$select public.update_employee('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','{"commission_pct":"100"}'::jsonb)$$, 'lavador não usa update_employee');
:asE
select tt.must_fail($$select public.update_employee('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','{"commission_pct":"50"}'::jsonb)$$, 'atendente não usa update_employee');
:asC
select tt.must_ok($$select public.update_employee('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','{"commission_pct":"15","salary":"1600"}'::jsonb)$$, 'admin ajusta comissão e salário');
select tt.must_fail($$select public.update_employee('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','{"role":"admin"}'::jsonb)$$, 'ninguém é promovido a admin por função');
select tt.must_fail($$select public.update_employee('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','{"active":false}'::jsonb)$$, 'admin não se desativa');
select tt.must_fail($$select public.update_employee('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','{"role":"washer"}'::jsonb)$$, 'admin não rebaixa a si mesmo');
:asF
select public.create_establishment('Lava F','Fabio') is not null as f_criou;
select tt.must_fail($$select public.update_employee('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','{"commission_pct":"0"}'::jsonb)$$, 'admin de outro lava-jato não edita funcionário alheio');
select tt.rows_eq($$select 1 from public.invites$$, 0, 'outro lava-jato não vê convites');
select tt.rows_eq($$select 1 from public.profiles$$, 1, 'outro lava-jato só vê o próprio perfil');

\echo '=== Lista da equipe (salário só para admin)'
:asC
select tt.val_eq($$select (select e->>'salary' from jsonb_array_elements(public.list_employees()) e where e->>'full_name' = 'Dudu Silva')$$, '1600.00', 'admin vê o salário na lista da equipe');
:asE
select tt.must_fail($$select public.list_employees()$$, 'atendente não lista a equipe com dados internos');
:asD
select tt.must_fail($$select public.list_employees()$$, 'lavador não lista a equipe com dados internos');

\echo '=== Dados de apoio (serviço, produto, vínculo)'
:asC
insert into public.services(establishment_id,name,price) select public.current_establishment(),'Lavagem',50;
select tt.must_ok($$insert into public.products(establishment_id,name,unit,min_qty) select public.current_establishment(),'Shampoo','L',7$$, 'admin cadastra produto com saldo zero');
select tt.must_fail($$insert into public.products(establishment_id,name,unit,qty) select public.current_establishment(),'Fraude','L',999$$, 'produto não nasce com saldo (só por movimentação)');
select tt.must_fail($$update public.products set qty = 500$$, 'saldo do produto não é editável direto');
select tt.must_fail($$delete from public.products$$, 'produto não é apagado direto');
select tt.must_ok($$insert into public.service_products(service_id,product_id,establishment_id,qty) select s.id, p.id, s.establishment_id, 0.5 from public.services s, public.products p$$, 'vínculo serviço-produto (0,5 L por uso)');
:su
select id as prod from public.products where name = 'Shampoo' \gset
select id as prod_f_dummy from public.products limit 0 \gset

\echo '=== Estoque'
:asC
select tt.val_eq($$select public.stock_move(jsonb_build_object('product_id','$$ || :'prod' || $$','kind','in','qty',8,'unit_cost',4,'client_id','11111111-0000-0000-0000-000000000001'))->>'duplicate'$$, 'false', 'entrada de estoque registrada');
select tt.val_eq($$select public.stock_move(jsonb_build_object('product_id','$$ || :'prod' || $$','kind','in','qty',8,'unit_cost',4,'client_id','11111111-0000-0000-0000-000000000001'))->>'duplicate'$$, 'true', 'reenvio da entrada é detectado');
select tt.val_eq($$select qty::text || '/' || cost::text from public.products where id = '$$ || :'prod' || $$'$$, '8.000/4.00', 'saldo 8 e custo atualizado, sem duplicar');
select tt.must_fail($$select public.stock_move(jsonb_build_object('product_id','$$ || :'prod' || $$','kind','in','qty',0,'client_id',gen_random_uuid()))$$, 'quantidade zero é recusada');
select tt.must_fail($$select public.stock_move(jsonb_build_object('product_id','$$ || :'prod' || $$','kind','adjust','qty',0,'client_id',gen_random_uuid()))$$, 'ajuste zero é recusado');
:asE
select tt.must_fail($$select public.stock_move(jsonb_build_object('product_id','$$ || :'prod' || $$','kind','in','qty',5,'client_id',gen_random_uuid()))$$, 'atendente não movimenta estoque');
select tt.rows_eq($$select 1 from public.products$$, 1, 'atendente consulta produtos');
select tt.rows_eq($$select 1 from public.stock_movements$$, 0, 'atendente não vê o histórico de movimentações');
:asD
select tt.rows_eq($$select 1 from public.products$$, 0, 'lavador não vê produtos');
:asF
select tt.rows_eq($$select 1 from public.products$$, 0, 'outro lava-jato não vê produtos');
select tt.must_fail($$select public.stock_move(jsonb_build_object('product_id','$$ || :'prod' || $$','kind','in','qty',5,'client_id',gen_random_uuid()))$$, 'outro lava-jato não movimenta meu produto');

\echo '=== Baixa automática de estoque e avisos'
:asE
select public.create_order(jsonb_build_object(
  'client_id','22222222-0000-0000-0000-000000000001',
  'vehicle', jsonb_build_object('plate','CCC1C11','model','Civic'),
  'customer', jsonb_build_object('name','Cliente Um'),
  'employee_id','bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
  'items', (select jsonb_agg(jsonb_build_object('service_id',id,'quantity',2,'unit_price',price)) from public.services)
))->>'number' as os_a;
select public.create_order(jsonb_build_object(
  'client_id','22222222-0000-0000-0000-000000000002',
  'vehicle', jsonb_build_object('plate','DDD2D22','model','Fit'),
  'customer', jsonb_build_object('name','Cliente Dois'),
  'employee_id','bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
  'items', (select jsonb_agg(jsonb_build_object('service_id',id,'quantity',1,'unit_price',60)) from public.services)
))->>'number' as os_b;
select tt.val_eq($$select count(*) from public.orders$$, '2', 'duas O.S. na Lava C');
:asD
select tt.rows_eq($$select 1 from public.orders$$, 2, 'lavador vê as O.S. atribuídas a ele');
select tt.rows_eq($$select 1 from public.customers$$, 0, 'lavador não vê clientes');
select tt.rows_eq($$select 1 from public.notifications$$, 0, 'lavador não vê avisos');
select tt.dml_rows($$update public.orders set status = 'in_progress' where number = 1$$, 1, 'lavador inicia a O.S. 1');
select tt.val_eq($$select qty::text from (select qty from public.products) x$$, null, 'lavador não consegue consultar o saldo');
select tt.dml_rows($$update public.orders set status = 'done' where number = 1$$, 1, 'lavador conclui a O.S. 1');
:su
select tt.val_eq($$select qty::text from public.products where id = '$$ || :'prod' || $$'$$, '7.000', 'baixa automática: 2 x 0,5 L = 1 L (8 -> 7)');
select tt.val_eq($$select stock_consumed::text from public.orders where number = 1 and establishment_id = (select establishment_id from public.profiles where id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa')$$, 'true', 'O.S. marcada como consumida');
select tt.val_eq($$select count(*)::text from public.stock_movements where kind = 'out' and order_id is not null$$, '1', 'um único movimento de saída ligado à O.S.');
:asE
select tt.dml_rows($$update public.orders set status = 'awaiting_payment' where number = 1$$, 1, 'atendente envia a O.S. 1 para pagamento');
:su
select tt.val_eq($$select qty::text from public.products where id = '$$ || :'prod' || $$'$$, '7.000', 'mudar de etapa depois não baixa estoque de novo');
:asE
select tt.rows_eq($$select 1 from public.notifications where kind = 'low_stock'$$, 1, 'aviso de estoque baixo gerado ao atingir o mínimo');
select tt.rows_eq($$select 1 from public.notifications where kind = 'awaiting_payment'$$, 1, 'aviso de aguardando pagamento gerado');
select tt.must_ok($$select public.mark_notifications_read()$$, 'marcar avisos como lidos');
select tt.val_eq($$select count(*)::text from public.notifications where not (auth.uid() = any(read_by))$$, '0', 'todos os avisos lidos por E');
select tt.must_ok($$select public.mark_notifications_read()$$, 'marcar de novo é idempotente');
select tt.val_eq($$select max(cardinality(read_by))::text from public.notifications$$, '1', 'sem leitura duplicada');
:asF
select tt.rows_eq($$select 1 from public.notifications$$, 0, 'outro lava-jato não vê avisos');

\echo '=== Caixa'
:asE
select tt.val_eq($$select public.cash_summary()->>'open'$$, 'false', 'caixa começa fechado');
select tt.must_fail($$select public.open_cash(-1)$$, 'valor de abertura negativo é recusado');
select tt.must_ok($$select public.open_cash(50)$$, 'atendente abre o caixa com R$ 50');
select tt.must_fail($$select public.open_cash(10)$$, 'não abre dois caixas ao mesmo tempo');
select tt.rows_eq($$select 1 from public.cash_sessions$$, 0, 'atendente não lê a tabela de sessões de caixa');
select public.register_payment((select id from public.orders where number = 1), 'cash', 30, '33333333-0000-0000-0000-000000000001');
select public.register_payment((select id from public.orders where number = 1), 'pix', 20, '33333333-0000-0000-0000-000000000002');
select tt.val_eq($$select payment_status from public.orders where number = 1$$, 'pending', 'pagamento parcial mantém a O.S. pendente');
select public.register_payment((select id from public.orders where number = 1), 'pix', 50, '33333333-0000-0000-0000-000000000003');
select tt.val_eq($$select payment_status || '/' || status from public.orders where number = 1$$, 'paid/ready', 'quitação: O.S. paga e pronta para entrega');
select tt.must_fail($$select public.register_payment((select id from public.orders where number = 1), 'pix', 1, gen_random_uuid())$$, 'não paga além do total');
select tt.must_fail($$select public.register_payment((select id from public.orders where number = 1), 'bitcoin', 1, gen_random_uuid())$$, 'forma de pagamento inválida é recusada');
:asC
select tt.must_ok($$insert into public.expenses(establishment_id,description,category,amount,method) select public.current_establishment(),'Esponjas','products',10,'cash'$$, 'admin lança despesa em dinheiro');
select tt.must_fail($$insert into public.expenses(establishment_id,description,category,amount) select public.current_establishment(),'x','categoria-invalida',10$$, 'categoria de despesa inválida é recusada');
select tt.val_eq($$select (public.cash_summary()->>'expected')::numeric::text$$, '70.00', 'caixa esperado: 50 + 30 dinheiro - 10 despesa = 70');
select tt.val_eq($$select jsonb_array_length(public.cash_summary()->'by_method')::text$$, '2', 'resumo separa dinheiro e PIX');

\echo '=== Estorno'
:asE
select tt.must_fail($$select public.refund_payment((select id from public.payments where method = 'pix' and amount = 50), 'cliente desistiu')$$, 'atendente não estorna');
:asC
select tt.must_fail($$select public.refund_payment((select id from public.payments where method = 'pix' and amount = 50), 'x')$$, 'estorno exige motivo');
select tt.must_ok($$select public.refund_payment((select id from public.payments where method = 'pix' and amount = 50), 'cobrança em duplicidade')$$, 'admin estorna o PIX de R$ 50');
select tt.val_eq($$select payment_status from public.orders where number = 1$$, 'pending', 'estorno devolve a O.S. para pendente');
select tt.must_fail($$select public.refund_payment((select id from public.payments where method = 'pix' and amount = 50), 'de novo')$$, 'não estorna duas vezes');
select tt.must_ok($$select public.refund_payment((select id from public.payments where method = 'cash'), 'devolução ao cliente')$$, 'admin estorna o dinheiro de R$ 30');
select tt.val_eq($$select (public.cash_summary()->>'expected')::numeric::text$$, '40.00', 'caixa esperado após estorno: 50 + 30 - 30 - 10 = 40');
:asE
select tt.must_ok($$select public.register_payment((select id from public.orders where number = 1), 'pix', 80, gen_random_uuid())$$, 'saldo reaberto aceita novo pagamento de R$ 80');
select tt.val_eq($$select payment_status from public.orders where number = 1$$, 'paid', 'O.S. volta a paga (20 + 80 = 100)');
:asC
select public.register_payment((select id from public.orders where number = 2), 'pix', 60, '33333333-0000-0000-0000-000000000009');
select tt.val_eq($$select (public.close_cash(45, 'conferido')->>'difference')$$, '5.00', 'fechamento: contado 45 vs esperado 40 = diferença +5');
select tt.val_eq($$select public.cash_summary()->>'open'$$, 'false', 'caixa fechado após o fechamento');
select tt.must_fail($$select public.close_cash(10, null)$$, 'não fecha caixa que não está aberto');
select tt.val_eq($$select (difference)::text from public.cash_sessions where closed_at is not null$$, '5.00', 'diferença gravada na sessão');
select tt.must_ok($$select public.open_cash(0)$$, 'novo caixa pode ser aberto depois do fechamento');
:asD
select tt.must_fail($$select public.open_cash(10)$$, 'lavador não abre caixa');
select tt.must_fail($$select public.cash_summary()$$, 'lavador não vê resumo de caixa');

\echo '=== Relatórios e comissões'
:asC
select public.report_summary(now() - interval '1 day', now() + interval '1 day') as rep \gset
select tt.val_eq($$select ('$$ || :'rep' || $$'::jsonb->>'orders')$$, '2', 'relatório: 2 O.S.');
select tt.val_eq($$select (('$$ || :'rep' || $$'::jsonb->>'billed')::numeric = 160)::text$$, 'true', 'relatório: faturamento 160');
select tt.val_eq($$select (('$$ || :'rep' || $$'::jsonb->>'received')::numeric = 160)::text$$, 'true', 'relatório: recebido 160 = pagamentos 240 - estornos 80');
select tt.val_eq($$select (('$$ || :'rep' || $$'::jsonb->>'expenses')::numeric = 10)::text$$, 'true', 'relatório: despesas 10');
select tt.val_eq($$select (('$$ || :'rep' || $$'::jsonb->>'pending')::numeric = 0)::text$$, 'true', 'relatório: nada pendente (as duas O.S. estão pagas)');
select tt.val_eq($$select jsonb_array_length('$$ || :'rep' || $$'::jsonb->'by_method')::text$$, '1', 'relatório: só PIX (o dinheiro foi estornado)');
select tt.val_eq($$select ('$$ || :'rep' || $$'::jsonb->'top_services'->0->>'name')$$, 'Lavagem', 'relatório: serviço mais vendido');
select tt.val_eq($$select ('$$ || :'rep' || $$'::jsonb->'products'->0->>'qty')::numeric::text$$, '1.000', 'relatório: consumo de 1 L de Shampoo');
select tt.val_eq($$select (e->>'orders') || '/' || ((e->>'billed')::numeric)::text || '/' || ((e->>'commission')::numeric)::text from jsonb_array_elements('$$ || :'rep' || $$'::jsonb->'employees') e where e->>'name' = 'Dudu Silva'$$, '2/160.00/24.00', 'relatório: lavador com 2 O.S., faturado 160, comissão 15% = 24,00');
select tt.must_fail($$select public.report_summary(now(), now() - interval '1 day')$$, 'período invertido é recusado');
:asE
select tt.must_fail($$select public.report_summary(now() - interval '1 day', now() + interval '1 day')$$, 'atendente não vê relatórios');
:asD
select tt.must_fail($$select public.report_summary(now() - interval '1 day', now() + interval '1 day')$$, 'lavador não vê relatórios');
:asF
select tt.val_eq($$select (public.report_summary(now() - interval '1 day', now() + interval '1 day')->>'orders')$$, '0', 'relatório de outro lava-jato não enxerga as O.S. da Lava C');

\echo '=== Agendamentos'
:asE
select tt.must_ok($$insert into public.appointments(establishment_id,customer_name,plate,model,scheduled_at) select public.current_establishment(),'Ana Cliente','EEE5E55','Polo',now() + interval '1 hour'$$, 'atendente agenda um serviço');
select tt.must_fail($$insert into public.appointments(establishment_id,customer_name,plate,scheduled_at) select public.current_establishment(),'Ana','placa-ruim',now()$$, 'placa inválida no agendamento é recusada');
select tt.rows_eq($$select 1 from public.appointments$$, 1, 'atendente vê o agendamento');
:asD
select tt.rows_eq($$select 1 from public.appointments$$, 0, 'lavador não vê agenda');
select tt.must_fail($$insert into public.appointments(establishment_id,customer_name,scheduled_at) select establishment_id,'Intruso',now() from public.profiles where id = auth.uid()$$, 'lavador não agenda');
:asF
select tt.rows_eq($$select 1 from public.appointments$$, 0, 'outro lava-jato não vê a agenda');

\echo '=== Fotos e Storage'
:asC
select public.current_establishment() as est_c \gset
:su
select id as os1 from public.orders where number = 1 and establishment_id = :'est_c' \gset
select id as os2 from public.orders where number = 2 and establishment_id = :'est_c' \gset
:asE
select tt.must_ok($$insert into public.order_photos(establishment_id,order_id,path) values ('$$ || :'est_c' || $$','$$ || :'os1' || $$','$$ || :'est_c' || $$/$$ || :'os1' || $$/a.jpg')$$, 'atendente registra foto na pasta do próprio lava-jato');
select tt.must_fail($$insert into public.order_photos(establishment_id,order_id,path) values ('$$ || :'est_c' || $$','$$ || :'os1' || $$','outra-pasta/a.jpg')$$, 'foto fora da pasta do lava-jato é recusada');
select tt.must_ok($$insert into storage.objects(bucket_id,name) values ('order-photos','$$ || :'est_c' || $$/x/a.jpg')$$, 'upload na pasta do lava-jato');
select tt.must_fail($$insert into storage.objects(bucket_id,name) values ('order-photos','pasta-alheia/x/a.jpg')$$, 'upload em pasta alheia é recusado');
:asD
select tt.must_ok($$insert into public.order_photos(establishment_id,order_id,path) values ('$$ || :'est_c' || $$','$$ || :'os1' || $$','$$ || :'est_c' || $$/$$ || :'os1' || $$/lav.jpg')$$, 'lavador registra foto em O.S. atribuída a ele');
select tt.rows_eq($$select 1 from public.order_photos$$, 2, 'lavador vê as fotos da O.S. dele');
:su
update public.orders set employee_id = :E where number = 2;
:asD
select tt.rows_eq($$select 1 from public.orders where number = 2$$, 0, 'lavador deixa de ver O.S. reatribuída a outro');
select tt.must_fail($$insert into public.order_photos(establishment_id,order_id,path) values ('$$ || :'est_c' || $$','$$ || :'os2' || $$','$$ || :'est_c' || $$/$$ || :'os2' || $$/lav.jpg')$$, 'lavador não registra foto em O.S. de outro');
select tt.dml_rows($$delete from public.order_photos$$, 0, 'lavador não apaga fotos (nenhuma linha afetada)');
:asF
select tt.rows_eq($$select 1 from public.order_photos$$, 0, 'outro lava-jato não vê fotos');
select tt.rows_eq($$select 1 from storage.objects$$, 0, 'outro lava-jato não vê arquivos');
select tt.must_fail($$insert into storage.objects(bucket_id,name) values ('order-photos','$$ || :'est_c' || $$/x/hack.jpg')$$, 'outro lava-jato não grava na pasta da Lava C');

\echo '=== Usuário desativado'
:asC
select tt.must_ok($$select public.update_employee('cccccccc-cccc-cccc-cccc-cccccccccccc','{"active":false}'::jsonb)$$, 'admin desativa a atendente');
:asE
select tt.val_eq($$select public.my_profile()->>'active'$$, 'false', 'app consegue saber que a conta está desativada');
select tt.rows_eq($$select 1 from public.orders$$, 0, 'desativada não vê O.S.');
select tt.rows_eq($$select 1 from public.products$$, 0, 'desativada não vê produtos');
select tt.must_fail($$select public.create_order(jsonb_build_object('client_id',gen_random_uuid()))$$, 'desativada não cria O.S.');
select tt.must_fail($$select public.register_payment(gen_random_uuid(),'pix',1,gen_random_uuid())$$, 'desativada não registra pagamento');
:asC
select tt.must_ok($$select public.update_employee('cccccccc-cccc-cccc-cccc-cccccccccccc','{"active":true}'::jsonb)$$, 'admin reativa a atendente');
:asE
select tt.rows_eq($$select 1 from public.orders$$, 2, 'reativada volta a ver as O.S.');

\echo '=== Referências entre estabelecimentos'
:asF
select tt.must_fail($$insert into public.order_photos(establishment_id,order_id,path) select public.current_establishment(), '$$ || :'os1' || $$', public.current_establishment()::text || '/x/y.jpg'$$, 'F não anexa foto a O.S. da Lava C');
select tt.must_ok($$insert into public.services(establishment_id,name,price) select public.current_establishment(),'Servico F',10$$, 'F cadastra o próprio serviço');
select tt.must_ok($$insert into public.products(establishment_id,name,unit) select public.current_establishment(),'Produto F','un'$$, 'F cadastra o próprio produto');
select tt.must_fail($$insert into public.service_products(service_id,product_id,establishment_id,qty) select (select id from public.services s where s.id <> (select id from public.services where name = 'Servico F') limit 1), p.id, p.establishment_id, 1 from public.products p where name = 'Produto F'$$, 'F não vincula o próprio produto a serviço de outro lava-jato');

\echo '=== Funções internas e anônimo'
:asC
select tt.must_fail($$select public.internal_apply_stock(public.current_establishment(), '$$ || :'prod' || $$', 'in', 100, 1, 'fraude', null, gen_random_uuid(), auth.uid())$$, 'função interna de estoque não é chamável pelo app');
:su
set role anon;
select tt.must_fail($$select public.my_profile()$$, 'anon não chama my_profile');
select tt.must_fail($$select public.stock_move('{}'::jsonb)$$, 'anon não chama stock_move');
select tt.must_fail($$select public.report_summary(now() - interval '1 day', now())$$, 'anon não chama report_summary');
select tt.must_fail($$select public.create_invite('{}'::jsonb)$$, 'anon não chama create_invite');
select tt.must_fail($$select public.join_establishment('X')$$, 'anon não chama join_establishment');
select tt.must_fail($$select public.cash_summary()$$, 'anon não chama cash_summary');
select tt.must_fail($$select public.open_cash(1)$$, 'anon não chama open_cash');
select tt.must_fail($$select public.refund_payment(gen_random_uuid(), 'abc')$$, 'anon não chama refund_payment');
select tt.must_fail($$select public.update_employee(gen_random_uuid(), '{}'::jsonb)$$, 'anon não chama update_employee');
select tt.must_fail($$select * from public.products$$, 'anon não lê produtos');
select tt.must_fail($$select * from public.notifications$$, 'anon não lê avisos');
select tt.must_fail($$select * from storage.objects$$, 'anon não lê arquivos');
reset role;

\echo '=== RESUMO FASE 2'
select count(*) filter (where ok) as passaram, count(*) filter (where not ok) as falharam, count(*) as total from tt.results;
select label as "FALHOU" from tt.results where not ok;
