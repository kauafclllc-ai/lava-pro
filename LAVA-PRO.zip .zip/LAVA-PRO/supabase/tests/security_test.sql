-- Rode DEPOIS de supabase_shim.sql e ../schema.sql, em um banco de teste vazio.
-- Mostra PASS/FAIL por verificação e um resumo no final.
create schema tt;
create table tt.results (ok boolean, label text);
grant usage on schema tt to public; grant insert on tt.results to public;

-- deve falhar (erro ou bloqueio)
create function tt.must_fail(q text, label text) returns void language plpgsql as $$
begin
  execute q;
  insert into tt.results values (false, label); raise notice 'FAIL  %', label;
exception when others then
  -- "does not exist" indica erro de preparação do teste, não bloqueio de segurança
  if sqlerrm ilike '%does not exist%' then
    insert into tt.results values (false, label); raise notice 'FAIL  % (problema de preparação: %)', label, sqlerrm;
  else
    insert into tt.results values (true, label); raise notice 'PASS  % (%)', label, sqlerrm;
  end if;
end $$;
-- deve afetar/retornar exatamente n linhas (use "with u as (update ... returning 1) select 1 from u")
create function tt.rows_eq(q text, n int, label text) returns void language plpgsql as $$
declare c int;
begin
  execute 'select count(*) from (' || q || ') z' into c;
  insert into tt.results values (c = n, label);
  raise notice '%  % (obtido %, esperado %)', case when c = n then 'PASS' else 'FAIL' end, label, c, n;
exception when others then
  insert into tt.results values (false, label); raise notice 'FAIL  % (erro: %)', label, sqlerrm;
end $$;
-- deve funcionar (sem erro)
create function tt.must_ok(q text, label text) returns void language plpgsql as $$
begin
  execute q;
  insert into tt.results values (true, label); raise notice 'PASS  %', label;
exception when others then
  insert into tt.results values (false, label); raise notice 'FAIL  % (erro: %)', label, sqlerrm;
end $$;
-- valor de uma consulta (como texto) deve ser igual ao esperado
create function tt.val_eq(q text, expected text, label text) returns void language plpgsql as $$
declare v text;
begin
  execute 'select (' || q || ')::text' into v;
  insert into tt.results values (v is not distinct from expected, label);
  raise notice '%  % (obtido %, esperado %)', case when v is not distinct from expected then 'PASS' else 'FAIL' end, label, v, expected;
exception when others then
  insert into tt.results values (false, label); raise notice 'FAIL  % (erro: %)', label, sqlerrm;
end $$;
-- DML (update/delete/insert): número de linhas afetadas deve ser n
create function tt.dml_rows(q text, n int, label text) returns void language plpgsql as $$
declare c int;
begin
  execute q; get diagnostics c = row_count;
  insert into tt.results values (c = n, label);
  raise notice '%  % (afetadas %, esperado %)', case when c = n then 'PASS' else 'FAIL' end, label, c, n;
exception when others then
  insert into tt.results values (false, label); raise notice 'FAIL  % (erro: %)', label, sqlerrm;
end $$;
grant execute on all functions in schema tt to public;

\set A '''11111111-1111-1111-1111-111111111111'''
\set X '''22222222-2222-2222-2222-222222222222'''
\set W '''33333333-3333-3333-3333-333333333333'''
\set B '''44444444-4444-4444-4444-444444444444'''
\set N '''55555555-5555-5555-5555-555555555555'''
\set su  'reset role;'
\set asA 'reset role; set role authenticated; do $$ begin perform set_config(''request.jwt.claim.sub'', ''11111111-1111-1111-1111-111111111111'', false); end $$;'
\set asX 'reset role; set role authenticated; do $$ begin perform set_config(''request.jwt.claim.sub'', ''22222222-2222-2222-2222-222222222222'', false); end $$;'
\set asW 'reset role; set role authenticated; do $$ begin perform set_config(''request.jwt.claim.sub'', ''33333333-3333-3333-3333-333333333333'', false); end $$;'
\set asB 'reset role; set role authenticated; do $$ begin perform set_config(''request.jwt.claim.sub'', ''44444444-4444-4444-4444-444444444444'', false); end $$;'
\set asN 'reset role; set role authenticated; do $$ begin perform set_config(''request.jwt.claim.sub'', ''55555555-5555-5555-5555-555555555555'', false); end $$;'

insert into auth.users(id,email) values (:A,'a@x'),(:X,'x@x'),(:W,'w@x'),(:B,'b@x'),(:N,'n@x');

\echo '=== Preparação'
:asA
select public.create_establishment('Lava A','Ana') is not null as a_criou;
:su
insert into public.profiles(id,establishment_id,full_name,role)
  select :X, establishment_id, 'Xavier','attendant' from public.profiles where id = :A;
insert into public.profiles(id,establishment_id,full_name,role)
  select :W, establishment_id, 'Will','washer' from public.profiles where id = :A;
:asA
insert into public.services(establishment_id,name,price) select public.current_establishment(),'Lavagem simples',40;
insert into public.services(establishment_id,name,price) select public.current_establishment(),'Cera',30;
:asX
select public.create_order(jsonb_build_object(
 'client_id','aaaaaaaa-0000-0000-0000-000000000001',
 'vehicle', jsonb_build_object('plate','abc-1d23','brand','GM','model','Onix','color','Prata','type','car'),
 'customer', jsonb_build_object('name','Joao','phone','(11) 98888-7777'),
 'employee_id','33333333-3333-3333-3333-333333333333',
 'items', (select jsonb_agg(jsonb_build_object('service_id',id,'quantity',2,'unit_price',price,'discount',5)) from public.services)
)) ->> 'number' as os1;
select public.create_order(jsonb_build_object(
 'client_id','aaaaaaaa-0000-0000-0000-000000000002',
 'vehicle', jsonb_build_object('plate','XYZ9K88','model','Gol'),
 'customer', jsonb_build_object('name','Maria'),
 'items', (select jsonb_agg(jsonb_build_object('service_id',id,'quantity',1,'unit_price',price)) from public.services limit 1)
)) ->> 'number' as os2;

\echo '=== Funcional: O.S., totais e duplicidade (atendente)'
select tt.val_eq($$select total from public.orders where number = 1$$, '130.00', 'total calculado no servidor (2x40 + 2x30 - 10)');
select tt.val_eq($$select count(*) from public.orders$$, '2', 'duas O.S. criadas');
select tt.val_eq($$select public.create_order(jsonb_build_object('client_id','aaaaaaaa-0000-0000-0000-000000000001','vehicle',jsonb_build_object('plate','ABC1D23','model','Onix'),'customer',jsonb_build_object('name','Joao'),'items',(select jsonb_agg(jsonb_build_object('service_id',id,'quantity',1,'unit_price',price)) from public.services)))->>'duplicate'$$, 'true', 'reenvio com o mesmo client_id é detectado');
select tt.val_eq($$select count(*) from public.orders$$, '2', 'reenvio não cria O.S. duplicada');
select tt.val_eq($$select count(*) from public.vehicles$$, '2', 'veículo reaproveitado pela placa');
select tt.must_fail($$select public.create_order(jsonb_build_object('client_id',gen_random_uuid(),'vehicle',jsonb_build_object('plate','XXXX','model','m'),'customer',jsonb_build_object('name','Zé'),'items','[]'::jsonb))$$, 'O.S. sem itens é recusada');
select tt.must_fail($$select public.create_order(jsonb_build_object('client_id',gen_random_uuid(),'vehicle',jsonb_build_object('plate','XXXX','model','m'),'customer',jsonb_build_object('name','Zé'),'items',(select jsonb_agg(jsonb_build_object('service_id',id,'quantity',1,'unit_price',price)) from public.services)))$$, 'placa inválida é recusada');
select tt.must_fail($$select public.create_order(jsonb_build_object('client_id',gen_random_uuid(),'vehicle',jsonb_build_object('plate','ABC1D23','model','m'),'customer',jsonb_build_object('name','Zé'),'items',(select jsonb_agg(jsonb_build_object('service_id',id,'quantity',1,'unit_price',10,'discount',50)) from public.services limit 1)))$$, 'desconto maior que o valor é recusado');

\echo '=== Funcional: pagamento'
select tt.val_eq($$select public.register_payment((select id from public.orders where number=1),'pix',30,'bbbbbbbb-0000-0000-0000-000000000001')->>'duplicate'$$, 'false', 'pagamento parcial registrado');
select tt.val_eq($$select public.register_payment((select id from public.orders where number=1),'pix',30,'bbbbbbbb-0000-0000-0000-000000000001')->>'duplicate'$$, 'true', 'reenvio do pagamento é detectado');
select tt.val_eq($$select count(*) from public.payments$$, '1', 'pagamento duplicado não é gravado');
select tt.must_fail($$select public.register_payment((select id from public.orders where number=1),'cash',9999,gen_random_uuid())$$, 'pagamento acima do saldo é recusado');
select tt.val_eq($$select public.register_payment((select id from public.orders where number=1),'cash',100,gen_random_uuid())->>'paid'$$, '130.00', 'quitação soma 130,00');
select tt.val_eq($$select payment_status from public.orders where number=1$$, 'paid', 'O.S. marcada como paga ao quitar');

\echo '=== ATAQUE: atendente tenta fraudar valores (deve ser bloqueado)'
select tt.must_fail($$update public.orders set total = 0 where number = 2$$, 'atendente não altera o total da O.S.');
select tt.must_fail($$update public.orders set payment_status = 'paid' where number = 2$$, 'atendente não marca O.S. como paga sem pagamento');
select tt.must_fail($$update public.orders set discount = 40 where number = 2$$, 'atendente não altera o desconto');
select tt.must_fail($$update public.orders set public_token = gen_random_uuid() where number = 2$$, 'atendente não troca o token público');
select tt.must_fail($$insert into public.payments(establishment_id,order_id,method,amount,client_id) select establishment_id,id,'cash',1,gen_random_uuid() from public.orders where number=2$$, 'atendente não insere pagamento direto na tabela');
select tt.must_fail($$insert into public.order_items(order_id,establishment_id,name,quantity,unit_price) select id,establishment_id,'x',1,1 from public.orders where number=2$$, 'atendente não insere item direto na tabela');
select tt.must_fail($$insert into public.orders(establishment_id,vehicle_id,customer_id,subtotal,total,client_id) select establishment_id,vehicle_id,customer_id,0,0,gen_random_uuid() from public.orders where number=2$$, 'atendente não insere O.S. direto na tabela');
select tt.dml_rows($$update public.orders set status='in_progress' where number=2$$, 1, 'atendente pode mudar o andamento');
select tt.rows_eq($$select 1 from public.expenses$$, 0, 'atendente não lê despesas');
select tt.rows_eq($$select 1 from public.audit_log$$, 0, 'atendente não lê auditoria');

\echo '=== ATAQUE: lavador'
:asW
select tt.must_fail($$update public.profiles set role = 'admin' where id = '33333333-3333-3333-3333-333333333333'$$, 'lavador não se promove a admin');
:su
select tt.val_eq($$select role from public.profiles where id = '33333333-3333-3333-3333-333333333333'$$, 'washer', 'papel do lavador continua washer');
:asW
select tt.must_fail($$update public.profiles set full_name = 'hack' where id = '11111111-1111-1111-1111-111111111111'$$, 'lavador não edita perfil de outra pessoa');
select tt.must_fail($$update public.profiles set establishment_id = gen_random_uuid() where id = '33333333-3333-3333-3333-333333333333'$$, 'lavador não troca de estabelecimento');
select tt.must_fail($$select public.create_order(jsonb_build_object('client_id',gen_random_uuid()))$$, 'lavador não cria O.S.');
select tt.must_fail($$select public.register_payment((select id from public.orders where number=1),'pix',1,gen_random_uuid())$$, 'lavador não registra pagamento');
select tt.rows_eq($$select 1 from public.payments$$, 0, 'lavador não vê pagamentos');
select tt.rows_eq($$select 1 from public.expenses$$, 0, 'lavador não vê despesas');
select tt.rows_eq($$select 1 from public.audit_log$$, 0, 'lavador não vê auditoria');
select tt.must_fail($$insert into public.services(establishment_id,name,price) select public.current_establishment(),'Servico falso',1$$, 'lavador não cadastra serviço');
select tt.dml_rows($$update public.orders set status='in_progress' where number=1$$, 1, 'lavador inicia a O.S. atribuída a ele');
select tt.must_fail($$update public.orders set status='delivered' where number=1$$, 'lavador não marca como entregue');
select tt.must_fail($$update public.orders set notes='trocado' where number=1$$, 'lavador não altera observações');
select tt.must_fail($$update public.orders set employee_id = null where number=1$$, 'lavador não reatribui a O.S.');
select tt.dml_rows($$update public.orders set status='done' where number=2$$, 0, 'lavador não mexe em O.S. de outro funcionário');

\echo '=== Admin pode gerir a equipe'
:asA
select tt.must_ok($$select public.update_employee('33333333-3333-3333-3333-333333333333', '{"role":"manager"}'::jsonb)$$, 'admin altera o papel de um funcionário (função)');
select tt.val_eq($$select role from public.profiles where id = '33333333-3333-3333-3333-333333333333'$$, 'manager', 'papel alterado de fato');
select tt.val_eq($$select count(*) > 0 from public.audit_log$$, 'true', 'admin lê a auditoria');
:su
update public.profiles set role = 'washer' where id = :W;

\echo '=== ISOLAMENTO entre estabelecimentos'
:su
select id as est_a from public.establishments order by created_at limit 1 \gset
select id as svc_a from public.services where name = 'Cera' \gset
select id as os_a from public.orders where number = 1 \gset
:asB
select public.create_establishment('Lava B','Beto') is not null as b_criou;
select tt.rows_eq($$select 1 from public.orders$$, 0, 'B não vê O.S. de A');
select tt.rows_eq($$select 1 from public.customers$$, 0, 'B não vê clientes de A');
select tt.rows_eq($$select 1 from public.vehicles$$, 0, 'B não vê veículos de A');
select tt.rows_eq($$select 1 from public.services$$, 0, 'B não vê serviços de A');
select tt.rows_eq($$select 1 from public.payments$$, 0, 'B não vê pagamentos de A');
select tt.rows_eq($$select 1 from public.profiles$$, 1, 'B vê só o próprio perfil');
select tt.dml_rows($$update public.orders set status='cancelled'$$, 0, 'B não altera O.S. de A');
select tt.must_fail($$select public.create_order(jsonb_build_object('client_id',gen_random_uuid(),'vehicle',jsonb_build_object('plate','ZZZ9Z99','model','m'),'customer',jsonb_build_object('name','Zé'),'items',jsonb_build_array(jsonb_build_object('service_id','$$ || :'svc_a' || $$','quantity',1,'unit_price',1))))$$, 'B não usa o service_id real de A');
select tt.must_fail($$select public.register_payment('$$ || :'os_a' || $$','pix',1,gen_random_uuid())$$, 'B não registra pagamento em O.S. de A');
:su
select tt.val_eq($$select count(*) from public.orders where status = 'cancelled'$$, '0', 'nenhuma O.S. de A foi cancelada pelo ataque');

\echo '=== Usuário sem estabelecimento'
:asN
select tt.rows_eq($$select 1 from public.orders$$, 0, 'usuário sem perfil não lê O.S.');
select tt.must_fail($$select public.create_order(jsonb_build_object('client_id',gen_random_uuid()))$$, 'usuário sem perfil não cria O.S.');
select tt.must_fail($$insert into public.profiles(id,establishment_id,full_name,role) values ('55555555-5555-5555-5555-555555555555','$$ || :'est_a' || $$','Intruso','admin')$$, 'usuário não se insere como admin em estabelecimento alheio');

\echo '=== Anônimo (página pública do QR Code)'
:su
select public_token as tok from public.orders where number = 1 \gset
set role anon;
select tt.must_fail($$select * from public.orders$$, 'anon não lê a tabela de O.S.');
select tt.must_fail($$select * from public.customers$$, 'anon não lê clientes');
select tt.must_fail($$select public.create_order('{}'::jsonb)$$, 'anon não chama create_order');
select tt.must_fail($$select public.register_payment(gen_random_uuid(),'pix',1,gen_random_uuid())$$, 'anon não chama register_payment');
select tt.val_eq($$select public.public_order_status('$$ || :'tok' || $$')->>'plate_hint'$$, 'D23', 'anon consulta por token e vê só o final da placa');
select tt.val_eq($$select (public.public_order_status('$$ || :'tok' || $$') ? 'customer')::text$$, 'false', 'página pública não expõe nome do cliente');
select tt.val_eq($$select coalesce(public.public_order_status(gen_random_uuid())::text,'nulo')$$, 'nulo', 'token inexistente retorna vazio');
reset role;

\echo '=== RESUMO'
select count(*) filter (where ok) as passaram, count(*) filter (where not ok) as falharam, count(*) as total from tt.results;
select label as "FALHOU" from tt.results where not ok;
\echo '=== Verificação final: nenhum intruso foi gravado'
reset role;
select count(*) as intrusos_gravados from public.profiles where id = '55555555-5555-5555-5555-555555555555';
